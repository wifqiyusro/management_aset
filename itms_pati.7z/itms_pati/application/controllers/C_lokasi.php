<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_lokasi extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(array('m_lokasi'));
    }

	function index(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('lokasi/v_master_lokasi');
        $this->load->view('_template/footer');
    }

    function get_master_lokasi(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_lokasi->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->nama_lokasi;
            $row[] = $field->label;
            $row[] = $field->created_at;
            $row[] = $field->updated_at;
            if($this->session->userdata('level_a') == '1' || $this->session->userdata('level_a') == '2'){
                $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="Edit" onclick="edit_lokasi('."'".$field->id_lokasi."'".')"><span class="fe fe-edit fe-16"><span></a>';
            }else{
                $row[] = '';
            }
            
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_lokasi->count_all(),
            "recordsFiltered" => $this->m_lokasi->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function add_lokasi_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_lokasi = 'hwp'.uniqid();
        $nama_lokasi = $this->input->post('nama_lokasi');
        $label = $this->input->post('label');
        $updated_at = date('Y-m-d H:i:s');

        $add = $this->m_lokasi->add_lokasi($id_lokasi,$nama_lokasi,$label,$updated_at);
        echo json_encode(array("status" => TRUE));
    }

    function edit_lokasi_($id_lokasi){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_lokasi->get_lokasi($id_lokasi)->row();
        echo json_encode($data);
    }

    function update_lokasi_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_lokasi = $this->input->post('id_lokasi');
        $nama_lokasi = $this->input->post('nama_lokasi');
        $label = $this->input->post('label');
        $updated_at = date('Y-m-d H:i:s');

        $update = $this->m_lokasi->update_lokasi($id_lokasi,$nama_lokasi,$label,$updated_at);
        echo json_encode(array("status"=>TRUE));
    }

    function cek_lokasi($id_lokasi){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_lokasi->get_lokasi($id_lokasi);
        header('Content-Type: application/json');
        if($data->num_rows() > '0'){
            echo json_encode(array('status'=>'ok', 'data'=>($data->row())));
        }else{
            echo json_encode(array('status'=>'error', 'msg'=>'Lokasi tidak ditemukan'));
        }
    }

}