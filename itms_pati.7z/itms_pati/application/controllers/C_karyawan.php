<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_karyawan extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(array('m_karyawan','m_log'));
    }

	function karyawan_resign(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('karyawan/v_karyawan_resign');
        $this->load->view('_template/footer');
    }

    function get_data_karyawan_resign(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $where = "f.TERMINATION <> ''";
        $list = $this->m_karyawan->get_datatables($where);
        $data = array();
        $no = @$_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->nik;
            $row[] = $field->NAME;
            $row[] = $field->DEPARTEMENT;
            $row[] = $field->NAMA_GEDUNG;
            $row[] = $field->id_stok;
            $row[] = $field->nama_jenis_barang;
            $row[] = $field->sn;
            $row[] = $field->nama_lokasi;
            if($this->session->userdata('level_a') == '1' || $this->session->userdata('level_a') == '2'){
                $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="Ganti User" onclick="change_user('."'".$field->id_stok."'".')"><span class="fe fe-edit fe-16"><span></a>';
            }else{
                $row[] = '';
            }
            $data[] = $row;
        }
        
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $this->m_karyawan->count_all($where),
            "recordsFiltered" => $this->m_karyawan->count_filtered($where),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function get_row_aset($id_stok){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        header('Content-Type: application/json');

        $data = $this->m_karyawan->get_data_aset($id_stok)->row();
        echo json_encode($data);
    }

    function change_user_proses(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_stok    = $this->input->post('id_stok');
        $tipe_user  = $this->input->post('tipe_user');
        $nik        = $this->input->post('nik');
        $nama_user  = $this->input->post('nama_user');

        $id_log = 'hwp'.uniqid();
        if($tipe_user == 'nik'){
            $temp       = $this->m_karyawan->get_row_karyawan($nik)->row();
            $karyawan   = $temp->NAME;
            $keterangan = "Device diganti dengan nama ".$karyawan.", karena user lama resign";
        }else{
            $keterangan = "Device diganti dengan nama ".$nama_user.", karena user lama resign";
        }
        $id_aset            = '';
        $status_keterangan  = '1';
        $tgl                = date('Y-m-d');
        $vendor             = '';
        $surat_jalan        = '';
        $id_user            = $this->session->userdata('username_a');
        $updated_at         = date('Y-m-d H:i:s');

        $this->m_karyawan->update_pengguna($id_stok,$nik,$nama_user,$updated_at,$id_user);
        $this->m_log->insert_log($id_log,$id_stok,$id_aset,$status_keterangan,$vendor,$tgl,$surat_jalan,$keterangan,$updated_at,$id_user);
        echo json_encode(array("status"=>TRUE));
    }
}
