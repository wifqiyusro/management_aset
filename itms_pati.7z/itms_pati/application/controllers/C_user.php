<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_user extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(array('m_user'));
    }

	function login(){
		$this->load->view('auth/v_login');
	}

	function proses_login(){
		$username = $this->input->post('username');
    	$password = $this->input->post('password');

    	$user_a = $this->m_user->get_user($username);
    	if($user_a->num_rows()>0){
    		$user_data_a = $user_a->result()[0];
    		$pass = $user_data_a->password;

    		if(password_verify($password, $pass)){
    			$this->session->set_userdata(array(
                    'id_user_a'		=> $user_data_a->id_user,
                    'username_a'	=> $user_data_a->username,
                    'level_a'		=> $user_data_a->level,
                    'logged_in_a'	=> true
                ));
                if($this->session->userdata('level_a') == '1'){
                	redirect('welcome');
                	//Level Administrator
                }elseif($this->session->userdata('level_a') == '2'){
                	redirect('welcome');
                	//Level PIC Aset
                }elseif($this->session->userdata('level_a') == '3'){
                	redirect('welcome');
                	//level User
                }elseif($this->session->userdata('level_a') == '4'){
                    redirect('welcome');
                    //level Report
                }else{  
                	$this->session->set_flashdata(array('error_msg'=>"User dinonaktifkan !"
                    ));
                    redirect('c_user/login');
                }
    		}else{
    			$this->session->set_flashdata(array('error_msg'=>"Password salah !"
                ));
                redirect('c_user/login');
    		}
    	}else{
    		$this->session->set_flashdata(array('error_msg'=>"Username tidak terdaftar !"
            ));
            redirect('c_user/login');
    	}
	}

	function logout(){
		$this->session->set_userdata(array('user_id_a'=>null, 'level_a'=>null, 'username_a'=>null, 'logged_in_a'=>false));
		$this->session->sess_destroy();
		redirect('c_user/login');
	}

    function add_user(){
        if($this->session->userdata('level_a') != '1'){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('auth/v_add_user');
        $this->load->view('_template/footer');
    }

    function get_data_user(){
         if($this->session->userdata('level_a') != '1'){
            redirect('c_user/logout');
        }

        $list = $this->m_user->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->id_user;
            $row[] = $field->nama_user;
            $row[] = $field->username;
            if($field->level == '1'){
                $row[] = 'Administrator';
            }elseif($field->level == '2'){
                $row[] = 'PIC Aset';
            }elseif($field->level == '3'){
                $row[] = 'User';
            }elseif($field->level == '4'){
                $row[] = 'Report';
            }else{
                $row[] = '<span class="badge badge-pill badge-danger">Nonaktif</span>';
            }
            $row[] = $field->created_at;
            $row[] = $field->updated_at;
            $row[] = '<a class="btn mb-2 btn-warning btn-sm" href="javascript:void(0)" title="Edit" onclick="edit_user('."'".$field->id_user."'".')"><span class="fe fe-edit fe-16"></span></a>
                  <a class="btn mb-2 btn-info btn-sm" href="javascript:void(0)" title="Reset Password" onclick="reset_pass('."'".$field->id_user."'".')"><span class="fe fe-refresh-ccw fe-16"><span></a>';

            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_user->count_all(),
            "recordsFiltered" => $this->m_user->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function add_user_process(){
        if($this->session->userdata('level_a') != '1'){
            redirect('c_user/logout');
        }

        $id_user    = 'hwp'.uniqid();
        $nama_user  = $this->input->post('nama_user');
        $username   = $this->input->post('username');
        $password   = $this->input->post('password');
        $level      = $this->input->post('level');
        $updated_at = date('Y-m-d H:i:s');
        if($level == ''){
            echo "<script>alert('Level user kosong');window.location='add_user'</script>";
        }else{
            $check = $this->m_user->check_username($username)->num_rows();
            if($check > 0){
                echo "<script>alert('Username sudah terdaftar');window.location='add_user'</script>";
            }else{
                $password_hash  = password_hash($password, PASSWORD_DEFAULT);
                $this->m_user->add_user($id_user,$nama_user,$username,$password_hash,$level,$updated_at);
                echo json_encode(array("status" => TRUE));
            }
        }
    }

    function edit_user_($id_user){
        if($this->session->userdata('level_a') != '1'){
            redirect('c_user/logout');
        }

        $data = $this->m_user->get_data_user($id_user)->row();
        echo json_encode($data);
    }

    function update_user_process(){
        if($this->session->userdata('level_a') != '1'){
            redirect('c_user/logout');
        }

        $id_user = $this->input->post('id_user');
        $nama_user = $this->input->post('nama_user');
        $level = $this->input->post('level');
        $updated_at = date('Y-m-d H:i:s');

        if($level == ''){
            echo "<script>alert('Level user kosong');window.location='add_user'</script>";
        }else{
            $this->m_user->update_user_process($id_user,$nama_user,$level,$updated_at);
            echo json_encode(array("status"=>TRUE));
        }      
    }

    function reset_password($id_user){
        if($this->session->userdata('level_a') != '1'){
            redirect('c_user/logout');
        }

        $data = $this->m_user->reset_password($id_user)->row();
        echo json_encode($data);
    }

    function reset_pass_process(){
        if($this->session->userdata('level_a') != '1'){
            redirect('c_user/logout');
        }

        $id_user    = $this->input->post('id_user');
        $password   = $this->input->post('password');
        $updated_at =  date('Y-m-d H:i:s');

        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        $this->m_user->update_password($id_user,$password_hash,$updated_at);
        echo json_encode(array("status"=>TRUE));
    }

    function delete_user_process($id_user){
        if($this->session->userdata('level_a') != '1'){
            redirect('c_user/logout');
        }

        $data = $this->m_user->delete_user($id_user);
        echo json_encode($data);        
    }
}
