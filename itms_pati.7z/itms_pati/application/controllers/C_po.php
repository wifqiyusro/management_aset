<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_po extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(array('m_po','m_supplier','m_lokasi'));
    }

	function index(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $supplier = $this->m_supplier->get_data_supplier()->result();
        $this->load->view('_template/header');
        $this->load->view('po/v_master_po',array('supplier'=>$supplier));
        $this->load->view('_template/footer');
    }

    function get_master_po(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_po->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->no_po;
            $row[] = $field->tanggal_po;
            $row[] = $field->nama_supplier;
            $row[] = $field->dept;
            $row[] = $field->keperluan;
            $row[] = $field->created_at;
            $row[] = $field->updated_at;
            if($this->session->userdata('level_a') == '1' || $this->session->userdata('level_a') == '2'){
                $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="Edit" onclick="edit_po_aset('."'".$field->id_po."'".')"><span class="fe fe-edit fe-16"><span></a>';
            }else{
                $row[] = '';
            }
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_po->count_all(),
            "recordsFiltered" => $this->m_po->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function add_po_aset(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $supplier = $this->m_supplier->get_data_supplier()->result();
        $departemen = $this->m_lokasi->get_all_lokasi()->result();
        $this->load->view('_template/header');
        $this->load->view('po/v_add_po_aset',array('supplier'=>$supplier,'departemen'=>$departemen));
        $this->load->view('_template/footer');
    }

    function add_po_aset_proses(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_po = 'hwp'.uniqid();
        $no_po = $this->input->post('no_po');
        $tanggal_po = $this->input->post('tanggal_po');
        $id_supplier = $this->input->post('id_supplier');
        $jenis_po = '1';
        $dept = $this->input->post('dept');
        $departemen = implode(",",$dept);
        $tgl_approval= $this->input->post('tgl_approval');
        $keperluan = $this->input->post('keperluan');
        $updated_at = date('Y-m-d H:i:s');

        $insert = $this->m_po->insert_po_aset($id_po,$no_po,$tanggal_po,$id_supplier,$jenis_po,$departemen,$tgl_approval,$keperluan,$updated_at);
        if($insert){
            $this->session->set_flashdata(array('status'=>'success','msg'=>'PO berhasil ditambahkan'));
        }
        redirect('c_po');
    }

    function edit_po_aset_($id_po){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_po->get_data_po($id_po)->row();
        echo json_encode($data);
    }

    function update_po_aset_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_po = $this->input->post('id_po');
        $no_po = $this->input->post('no_po');
        $tanggal_po = $this->input->post('tanggal_po');
        $id_supplier = $this->input->post('id_supplier');
        $keperluan = $this->input->post('keperluan');
        $updated_at = date('Y-m-d H:i:s');

        $update = $this->m_po->update_po_aset($id_po,$no_po,$tanggal_po,$id_supplier,$keperluan,$updated_at);
        echo json_encode(array("status"=>TRUE));
    }

    function cek_po($id_po){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_po->get_po_row($id_po);
        header('Content-Type: application/json');
        if($data->num_rows() > '0'){
            echo json_encode(array('status'=>'ok', 'data'=>($data->row())));
        }else{
            echo json_encode(array('status'=>'error', 'msg'=>'PO tidak ditemukan'));
        }
    }

    function po_cms(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $supplier = $this->m_supplier->get_data_supplier()->result();
        $this->load->view('_template/header');
        $this->load->view('po/v_master_po_cms',array('supplier'=>$supplier));
        $this->load->view('_template/footer');
    }

    function get_master_po_cms(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_po->get_datatables_cms();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->no_po;
            $row[] = $field->tanggal_po;
            $row[] = $field->nama_supplier;
            $row[] = $field->keperluan;
            $row[] = $field->created_at;
            $row[] = $field->updated_at;
            if($this->session->userdata('level_a') == '1' || $this->session->userdata('level_a') == '2'){
                $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="Edit" onclick="edit_po_cms('."'".$field->id_po."'".')"><span class="fe fe-edit fe-16"><span></a>';
            }else{
                $row[] = '';
            }
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_po->count_all_cms(),
            "recordsFiltered" => $this->m_po->count_filtered_cms(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function add_po_cms_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_po = 'hwp'.uniqid();
        $no_po = $this->input->post('no_po');
        $jenis_po = $this->input->post('jenis_po');
        $tanggal_po = $this->input->post('tanggal_po');
        $id_supplier = $this->input->post('id_supplier');
        $keperluan = $this->input->post('keperluan');
        $updated_at =  date('Y-m-d H:i:s');

        $this->m_po->add_po_cms($id_po,$no_po,$jenis_po,$tanggal_po,$id_supplier,$keperluan,$updated_at);
        echo json_encode(array("status" => TRUE));
    }

    function edit_po_cms_($id_po){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_po->get_data_po_cms($id_po)->row();
        echo json_encode($data);
    }

    function update_po_cms_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_po = $this->input->post('id_po');
        $no_po = $this->input->post('no_po');
        $tanggal_po = $this->input->post('tanggal_po');
        $id_supplier = $this->input->post('id_supplier');
        $keperluan = $this->input->post('keperluan');
        $updated_at = date('Y-m-d H:i:s');

        $this->m_po->update_po_cms($id_po,$no_po,$tanggal_po,$id_supplier,$keperluan,$updated_at);
        echo json_encode(array("status" => TRUE));
    }

    function cek_po_cms($id_po){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_po->get_po_cms_2($id_po);
        header('Content-Type: application/json');
        if($data->num_rows() > '0'){
            echo json_encode(array('status'=>'ok', 'data'=>($data->row())));
        }else{
            echo json_encode(array('status'=>'error', 'msg'=>'PO tidak ditemukan'));
        }
    }

    function po_service(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $supplier = $this->m_supplier->get_data_supplier()->result();
        $this->load->view('_template/header');
        $this->load->view('po/v_master_po_service',array('supplier'=>$supplier));
        $this->load->view('_template/footer');
    }

    function get_master_po_service(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_po->get_datatables_service();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->no_po;
            $row[] = $field->tanggal_po;
            $row[] = $field->nama_supplier;
            $row[] = $field->keperluan;
            $row[] = $field->created_at;
            $row[] = $field->updated_at;
            if($this->session->userdata('level_a') == '1' || $this->session->userdata('level_a') == '2'){
                $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="Edit" onclick="edit_po_service('."'".$field->id_po."'".')"><span class="fe fe-edit fe-16"><span></a>';
            }else{
                $row[] = '';
            }
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_po->count_all_service(),
            "recordsFiltered" => $this->m_po->count_filtered_service(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function add_po_service_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_po = 'hwp'.uniqid();
        $no_po = $this->input->post('no_po');
        $jenis_po = $this->input->post('jenis_po');
        $tanggal_po = $this->input->post('tanggal_po');
        $id_supplier = $this->input->post('id_supplier');
        $keperluan = $this->input->post('keperluan');
        $updated_at =  date('Y-m-d H:i:s');

        $this->m_po->add_po_service($id_po,$no_po,$jenis_po,$tanggal_po,$id_supplier,$keperluan,$updated_at);
        echo json_encode(array("status" => TRUE));
    }

    function edit_po_service_($id_po){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_po->get_data_po_service($id_po)->row();
        echo json_encode($data);
    }

    function update_po_service_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_po = $this->input->post('id_po');
        $no_po = $this->input->post('no_po');
        $tanggal_po = $this->input->post('tanggal_po');
        $id_supplier = $this->input->post('id_supplier');
        $keperluan = $this->input->post('keperluan');
        $updated_at = date('Y-m-d H:i:s');

        $this->m_po->update_po_service($id_po,$no_po,$tanggal_po,$id_supplier,$keperluan,$updated_at);
        echo json_encode(array("status" => TRUE));
    }

    function cek_po_service($id_po){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_po->get_po_service_2($id_po);
        header('Content-Type: application/json');
        if($data->num_rows() > '0'){
            echo json_encode(array('status'=>'ok', 'data'=>($data->row())));
        }else{
            echo json_encode(array('status'=>'error', 'msg'=>'PO tidak ditemukan'));
        }
    }

}