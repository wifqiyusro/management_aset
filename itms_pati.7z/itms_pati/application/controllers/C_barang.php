<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_barang extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(array('m_jenis_barang','m_barang'));
    }

	function index(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $jenis_barang = $this->m_jenis_barang->get_all()->result();
        $this->load->view('_template/header');
        $this->load->view('barang/v_barang',array('jenis_barang'=>$jenis_barang));
        $this->load->view('_template/footer');
    }

    function get_master_barang(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_barang->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            // $row[] = $field->kode_sap;
            $row[] = $field->nama_model;
            $row[] = $field->nama_jenis_barang;
            $row[] = $field->label_jenis_barang;
            $row[] = $field->created_at;
            $row[] = $field->updated_at;
            if($this->session->userdata('level_a') == '1' || $this->session->userdata('level_a') == '2'){
                $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="Edit" onclick="edit_barang('."'".$field->id_barang."'".')"><span class="fe fe-edit fe-16"><span></a>';
            }else{
                $row[] = '';
            }
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_barang->count_all(),
            "recordsFiltered" => $this->m_barang->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function add_barang_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_barang = 'hwp'.uniqid();
        // $kode_sap = $this->input->post('kode_sap');
        $nama_model = $this->input->post('nama_model');
        $id_jenis_barang = $this->input->post('id_jenis_barang');
        $updated_at = date('Y-m-d H:i:s');
        $label = $this->m_jenis_barang->get_label($id_jenis_barang)->row();
        $label_jenis_barang = $label->label_jns_barang;

        $add = $this->m_barang->add_barang($id_barang,$nama_model,$id_jenis_barang,$label_jenis_barang,$updated_at);
        echo json_encode(array("status" => TRUE));
    }

    function edit_barang_($id_barang){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_barang->get_data_barang($id_barang)->row();
        echo json_encode($data);
    }

    function update_barang_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_barang = $this->input->post('id_barang');
        // $kode_sap = $this->input->post('kode_sap');
        $nama_model = $this->input->post('nama_model');
        $id_jenis_barang = $this->input->post('id_jenis_barang');
        $temp_label = $this->m_jenis_barang->get_label($id_jenis_barang)->row();
        $label_barang = $temp_label->label_jns_barang;
        $updated_at = date('Y-m-d H:i:s');

        $update = $this->m_barang->update_barang($id_barang,$nama_model,$id_jenis_barang,$label_barang,$updated_at);
        echo json_encode(array("status"=>TRUE));
    }

}