<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_jenis_barang extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(array('m_jenis_barang'));
    }

	function index(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $kel_aset = $this->m_jenis_barang->get_kel_aset()->result();
        $this->load->view('_template/header');
        $this->load->view('jenis_barang/v_jenis_barang',array('kel_aset'=>$kel_aset));
        $this->load->view('_template/footer');
    }

    function get_master_jenis_barang(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_jenis_barang->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->nama_jenis_barang;
            if($field->jenis_aset == '0'){
                $row[] = '<span class="badge badge-pill badge-primary">Po</span>';
            }elseif($field->jenis_aset == '1'){
                $row[] = '<span class="badge badge-pill badge-success">Rental</span>';
            }else{
                $row[] = '<span class="badge badge-pill badge-danger">Projek</span>';
            }
            $row[] = $field->label_jns_barang;
            $row[] = $field->created_at;
            $row[] = $field->updated_at;
            if($this->session->userdata('level_a') == '1' || $this->session->userdata('level_a') == '2'){
                $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="Edit" onclick="edit_jenis_barang('."'".$field->id_jenis_barang."'".')"><span class="fe fe-edit fe-16"><span></a>';
            }else{
                $row[] = '';
            }
            
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_jenis_barang->count_all(),
            "recordsFiltered" => $this->m_jenis_barang->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function add_jenis_barang_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_jenis_barang = 'hwp'.uniqid();
        $nama_jenis_barang = $this->input->post('nama_jenis_barang');
        $jenis_aset = $this->input->post('jenis_aset');
        $label_jns_barang = $this->input->post('label_jns_barang');
        $kel_aset = $this->input->post('kel_aset');
        $updated_at = date('Y-m-d H:i:s');

        $add = $this->m_jenis_barang->add_jenis_barang($id_jenis_barang,$nama_jenis_barang,$jenis_aset,$label_jns_barang,$kel_aset,$updated_at);
        echo json_encode(array("status" => TRUE));
    }

    function edit_jenis_barang_($id_jenis_barang){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_jenis_barang->get_label($id_jenis_barang)->row();
        echo json_encode($data);
    }

    function update_jenis_barang_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_jenis_barang = $this->input->post('id_jenis_barang');
        $nama_jenis_barang = $this->input->post('nama_jenis_barang');
        $jenis_aset = $this->input->post('jenis_aset');
        $label_jns_barang = $this->input->post('label_jns_barang');
        $kel_aset = $this->input->post('kel_aset');
        $updated_at = date('Y-m-d H:i:s');

        $update = $this->m_jenis_barang->update_jenis_barang($id_jenis_barang,$nama_jenis_barang,$jenis_aset,$label_jns_barang,$kel_aset,$updated_at);
        $update_barang = $this->m_jenis_barang->update_label_barang($id_jenis_barang,$label_jns_barang,$updated_at);
        echo json_encode(array("status"=>TRUE));
    }

    function kelompok_aset(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('jenis_barang/v_kelompok_aset');
        $this->load->view('_template/footer');
    }

    function get_master_kelompok_aset(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_jenis_barang->get_datatables_aset();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->kode;
            $row[] = $field->nama_aset;
            $row[] = $field->created_at;
            $row[] = $field->updated_at;
            if($this->session->userdata('level_a') == '1' || $this->session->userdata('level_a') == '2'){
                $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="Edit" onclick="edit_kelompok_aset('."'".$field->kode."'".')"><span class="fe fe-edit fe-16"><span></a>';
            }else{
                $row[] = '';
            }
            
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_jenis_barang->count_all_aset(),
            "recordsFiltered" => $this->m_jenis_barang->count_filtered_aset(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function add_kelompok_aset_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $cek_kode= $this->m_jenis_barang->get_data_kel_aset();
        if(($cek_kode->num_rows()) == 0){
            $kode = 'AS001';
        }else{
            $temp_kode = $cek_kode->row();
            $temp = substr($temp_kode->kode,2,3);
            $tambah = $temp+1;

            if($tambah<10){
                $kode = 'AS00'.$tambah;
            }elseif($tambah<100){
                $kode = 'AS0'.$tambah;
            }else{
                $kode = 'AS'.$tambah;
            }
        }
        $nama_aset = $this->input->post('nama_aset');
        $updated_at = date('Y-m-d H:i:s');

        $add = $this->m_jenis_barang->add_kelompok_aset($kode,$nama_aset,$updated_at);
        echo json_encode(array("status" => TRUE));
    }

    function edit_kelompok_aset_($kode){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_jenis_barang->get_kelompok_aset($kode)->row();
        echo json_encode($data);
    }

    function update_kelompok_aset_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $kode = $this->input->post('kode');
        $nama_aset = $this->input->post('nama_aset');
        $updated_at = date('Y-m-d H:i:s');

        $update = $this->m_jenis_barang->update_kelompok_aset($kode,$nama_aset,$updated_at);
        echo json_encode(array("status"=>TRUE));
    }

}