<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(array('m_log','m_aset','m_stok_barang','m_karyawan'));
    }

	function index(){
		if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        //informasi log
        $data = $this->m_log->get_info_log()->result();

        //informasi aset & user
        $data_stok = $this->m_aset->get_data_stok()->row();
        $stok = $data_stok->jumlah;
        $data_pasang = $this->m_aset->get_data_pasang()->row();
        $pasang = $data_pasang->jumlah;
        $data_rusak_it = $this->m_aset->get_data_rusak_it()->row();
        $rusak_it = $data_rusak_it->jumlah;
        $data_rusak_vendor = $this->m_aset->get_data_rusak_vendor()->row();
        $rusak_vendor = $data_rusak_vendor->jumlah;
        $data_all = $this->m_aset->get_data_all()->row();
        $all = $data_all->jumlah;
        $data_user = $this->m_aset->get_data_user()->row();
        $user = $data_user->jumlah;

        //informasi kedatangan barang
        $po = $this->m_stok_barang->count_konfirm_po()->num_rows();
        $rental = $this->m_stok_barang->count_konfirm_rental()->num_rows();
        $cms = $this->m_stok_barang->count_konfirm_cms()->num_rows();
        
        $dt = $this->m_karyawan->get_data_resign();
        $karyawan = $dt->result();
        $jml_resign = $dt->num_rows();
		$this->load->view('_template/header.php');
		$this->load->view('v_home.php',array('data'=>$data,'stok'=>$stok,'pasang'=>$pasang,'rusak_it'=>$rusak_it,'rusak_vendor'=>$rusak_vendor,
        'all'=>$all,'user'=>$user, 'po'=>$po,'rental'=>$rental, 'cms'=>$cms, 'karyawan'=>$karyawan,'jml_resign'=>$jml_resign));	
		$this->load->view('_template/footer.php');

	}
}
