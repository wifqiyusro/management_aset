<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_report extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(array('m_report','m_surat_jalan','m_proyek'));
        $this->load->library(array('PHPExcel'));
    }

    function summary_aset(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $data = $this->m_report->get_summary_aset1()->result();
        $this->load->view('_template/header');
        $this->load->view('report/v_summary_aset', array('data'=>$data));
        $this->load->view('_template/footer');
    }

    function export_summary_aset1(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $data = $this->m_report->get_summary_aset1();

        $objPHPExcel = new PHPExcel();
                            // mengatur center
        $style = array(  
            'font' => array(
                'size' => 12,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_left = array(  
            'font' => array(
                'size' => 11
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                ),
                'borders' => array(    
                    'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                    'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                    'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                    'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
                )
        );

        $style_center = array(  
            'font' => array(
                'size' => 11,
                
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_col = array(  
            'font' => array(
                'bold' => false,
                'size' => 11), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
                ),          
            'borders' => array(    
                'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
            )   
        );

        $style_header = array(  
            'font' => array(
                'size' => 14,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $objPHPExcel->getActiveSheet()->mergeCells('A1:H1');
        $objPHPExcel->getActiveSheet()->setCellValue('A1','SUMMARY REPORT ASET HWI PATI');
                
        $heading=array('JENIS BARANG','MODEL BARANG','TERPASANG','STOK','RUSAK DI IT','RUSAK DI VENDOR','RETURN / HIDDEN','TOTAL');
        $rowNumberH = 4;
        $colH = 'A';
        foreach($heading as $h){
            $objPHPExcel->getActiveSheet()->setCellValue($colH.$rowNumberH,$h);
            $colH++;
        }

        $totn=$data->num_rows();
        $maxRow= $totn+1;
        $q = $data->result();
        $row = 5;
        $nomor = 1;
        $awal = 5;
        $jumlah = 1;

        foreach($q as $hasil){
            if($jumlah <= 1) {
                $akhir = $awal+$hasil->kode-1;
                $objPHPExcel->getActiveSheet()->mergeCells('A'.$awal.':A'.$akhir);  
                $objPHPExcel->getActiveSheet()->setCellValue('A'.$awal,$hasil->NAMA_JENIS_BARANG);
                $jumlah = $hasil->kode;     
                $awal = $akhir+1;                      
            } else {
                $jumlah = $jumlah - 1;
            }
            // $objPHPExcel->getActiveSheet()->setCellValue('B'.$row,$hasil->kode_sap);
            $objPHPExcel->getActiveSheet()->setCellValue('B'.$row,$hasil->nama_model);
            $objPHPExcel->getActiveSheet()->setCellValue('C'.$row,$hasil->TERPASANG);
            $objPHPExcel->getActiveSheet()->setCellValue('D'.$row,$hasil->STOCK);
            $objPHPExcel->getActiveSheet()->setCellValue('E'.$row,$hasil->BROKEN_IT);
            $objPHPExcel->getActiveSheet()->setCellValue('F'.$row,$hasil->BROKEN_VENDOR);
            $objPHPExcel->getActiveSheet()->setCellValue('G'.$row,$hasil->RETURN_HIDDEN);
            $objPHPExcel->getActiveSheet()->setCellValue('H'.$row,$hasil->TOTAL);
            $row++;
            $nomor++;
        }

        for($i=4; $i<$row; $i++){
            $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray($style_col);
            // $objPHPExcel->getActiveSheet()->getStyle('B'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('B'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('C'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('C'.$i)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('24c31b');
            $objPHPExcel->getActiveSheet()->getStyle('D'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('D'.$i)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('efdf21');
            $objPHPExcel->getActiveSheet()->getStyle('E'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('E'.$i)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('e2240c');
            $objPHPExcel->getActiveSheet()->getStyle('F'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('F'.$i)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('FFA500');
            $objPHPExcel->getActiveSheet()->getStyle('G'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('G'.$i)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('67afda'); 
            $objPHPExcel->getActiveSheet()->getStyle('H'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('H'.$i)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('03b7e0');          
        }

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(18);
        // $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);

        $objPHPExcel->getActiveSheet()->getStyle('A4:H4')->applyFromArray($style_center);
        $objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray($style_header);

        $objPHPExcel->getActiveSheet()->setTitle('SUMMARY REPORT ASET HWI PATI');
        $objPHPExcel->getDefaultStyle()->applyFromArray($style);
                        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
                        //Header

        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        //Nama File
        header('Content-Disposition: attachment;filename="SUMMARY REPORT ASET HWI PATI.xlsx"');
                        //Download
        $objWriter->save("php://output");
    }

	function report_po(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $po = $this->m_report->get_po_aset()->result();
        $this->load->view('_template/header');
        $this->load->view('report/v_report_po', array('po'=>$po));
        $this->load->view('_template/footer');
    }

    function get_data_po_aset(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_report->get_datatables_po_aset();
        $data = array();
        $no = @$_POST['start'];
        if(is_array($list) || is_object($list)){
            foreach($list as $field){
                $no++;
                $row = array();
                $row[] = $no;
                $row[] = $field->id_stok;
                $row[] = $field->id_aset;
                $row[] = $field->nama_jenis_barang;
                $row[] = $field->nama_model;
                if($field->jenis_aset == '0'){
                    $row[] = '<span class="badge badge-pill badge-primary">Po</span>';
                }elseif($field->jenis_aset == '1'){
                    $row[] = '<span class="badge badge-pill badge-success">Rental</span>';
                }else{
                    $row[] = '<span class="badge badge-pill badge-danger">Proyek</span>';
                }
                if($field->status_keterangan == '0'){
                    $row[] = 'STOCK';
                }elseif($field->status_keterangan == '1'){
                    $row[] = 'INSTALLED';
                }elseif($field->status_keterangan == '3'){
                    $row[] = 'BROKEN ON IT';
                }else{
                    $row[] = 'BROKEN ON VENDOR';
                }
                $row[] = $field->kurs;
                $row[] = number_format($field->harga);
                $row[] = $field->nama_lokasi;
                $row[] = $field->detail_lokasi;
                if($field->nik == ''){
                    $row[] = $field->nama_user;
                }else{
                    $row[] = $field->nik.' - '.$field->NAME;
                }                
                $row[] = $field->sn;
                $row[] = $field->remark;
                $data[] = $row;
            }
        }
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $this->m_report->count_all_po_aset(),
            "recordsFiltered" => $this->m_report->count_filtered_po_aset(),
            "data" => $data,
        );
        //output dalam format JSON
        echo json_encode($output);
    }

    function export_report_po_aset($id_trs){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $a = array("~","_");
        $b = array("'",",");
        $id = str_replace($a,$b,$id_trs);
        $id_transaksi = '('.$id.')';
        
        $objPHPExcel = new PHPExcel();
                            // mengatur center
        $style = array(  
            'font' => array(
                'size' => 12,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_left = array(  
            'font' => array(
                'size' => 11
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                ),
                'borders' => array(    
                    'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                    'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                    'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                    'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
                )
        );

        $style_center = array(  
            'font' => array(
                'size' => 11,
                
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_col = array(  
            'font' => array(
                'bold' => false,
                'size' => 11), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
                ),          
            'borders' => array(    
                'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
            )   
        );

        $style_header = array(  
            'font' => array(
                'size' => 14,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        if($id_trs == '-'){
            $data = $this->m_report->get_data_po_aset_1();
        }else{
            $data = $this->m_report->get_data_po_aset_2($id_transaksi);
        }

        $objPHPExcel->getActiveSheet()->mergeCells('A1:T1');
        $objPHPExcel->getActiveSheet()->setCellValue('A1','REPORT PO ASET HWI PATI');
                
        $heading=array('NO','NO PO','NAMA SUPPLIER','QR','KODE ASET','JENIS BARANG','MODEL BARANG','KODE EPTE','KODE FA','JENIS ASET','KURS','HARGA','HARGA + PPN','LOKASI','DETAIL LOKASI','NIK','USER','SN','STATUS','REMARK');
        $rowNumberH = 4;
        $colH = 'A';
        foreach($heading as $h){
            $objPHPExcel->getActiveSheet()->setCellValue($colH.$rowNumberH,$h);
            $colH++;
        }

        $totn=$data->num_rows();
        $maxRow= $totn+1;
        $q = $data->result();
        $row = 5;
        $nomor = 1;
        foreach ($q as $dt){
            $objPHPExcel->getActiveSheet()->setCellValue('A'.$row,$nomor);
            $objPHPExcel->getActiveSheet()->setCellValue('B'.$row,$dt->no_po);
            $objPHPExcel->getActiveSheet()->setCellValue('C'.$row,$dt->nama_supplier);
            $objPHPExcel->getActiveSheet()->setCellValue('D'.$row,$dt->id_stok);
            $objPHPExcel->getActiveSheet()->setCellValue('E'.$row,$dt->id_aset);
            $objPHPExcel->getActiveSheet()->setCellValue('F'.$row,$dt->nama_jenis_barang);
            $objPHPExcel->getActiveSheet()->setCellValue('G'.$row,$dt->nama_model);
            $objPHPExcel->getActiveSheet()->setCellValue('H'.$row,$dt->epte_code);
            $objPHPExcel->getActiveSheet()->setCellValue('I'.$row,$dt->FA_code);
            if($dt->jenis_aset == '0'){
                $objPHPExcel->getActiveSheet()->setCellValue('J'.$row,'PO');
            }else{
                $objPHPExcel->getActiveSheet()->setCellValue('J'.$row,'RENTAL');
            }
            $objPHPExcel->getActiveSheet()->setCellValue('K'.$row,$dt->kurs);
            
            if($dt->kurs == 'IDR'){
                $format = '_("Rp"* #,##0.00_)';
            }elseif($dt->kurs == 'USD'){
                $format = '_("$"* #,##0.00_)';
            }else{
                $format = '_("₩"* #,##0.00_)';
            }
            $objPHPExcel->getActiveSheet()->getStyle('L'.$row)->getNumberFormat()->setFormatCode($format);
            $objPHPExcel->getActiveSheet()->getStyle('M'.$row)->getNumberFormat()->setFormatCode($format);
            $objPHPExcel->getActiveSheet()->setCellValue('L'.$row,$dt->harga);
            $objPHPExcel->getActiveSheet()->setCellValue('M'.$row,$dt->harga_ppn);
            $objPHPExcel->getActiveSheet()->setCellValue('N'.$row,$dt->nama_lokasi);
            $objPHPExcel->getActiveSheet()->setCellValue('O'.$row,$dt->detail_lokasi);
            if($dt->nik == ''){
                $objPHPExcel->getActiveSheet()->setCellValue('P'.$row,'-');
                $objPHPExcel->getActiveSheet()->setCellValue('Q'.$row,$dt->nama_user);
            }else{
                $objPHPExcel->getActiveSheet()->setCellValue('P'.$row,$dt->nik);
                $objPHPExcel->getActiveSheet()->setCellValue('Q'.$row,$dt->NAME);
            }            
            $objPHPExcel->getActiveSheet()->setCellValue('R'.$row,$dt->sn);
            $objPHPExcel->getActiveSheet()->setCellValue('S'.$row,$dt->keterangan);
            $objPHPExcel->getActiveSheet()->setCellValue('T'.$row,$dt->remark);
            $row++;
            $nomor++;
        }

        for($i=4; $i<$row; $i++){
            $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('B'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('C'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('D'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('E'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('F'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('G'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('H'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('I'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('J'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('K'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('L'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('M'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('N'.$i)->applyFromArray($style_col); 
            $objPHPExcel->getActiveSheet()->getStyle('O'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('P'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('Q'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('R'.$i)->applyFromArray($style_col); 
            $objPHPExcel->getActiveSheet()->getStyle('S'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('T'.$i)->applyFromArray($style_left);           
        }

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(30);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(6);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(30);
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(13);
        $objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(18);
        $objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(14);
        $objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(30);

        $objPHPExcel->getActiveSheet()->getStyle('A4:T4')->applyFromArray($style_center);
        $objPHPExcel->getActiveSheet()->getStyle('A1:T1')->applyFromArray($style_header);

        $objPHPExcel->getActiveSheet()->setTitle('REPORT PO ASET HWI PATI');
        $objPHPExcel->getDefaultStyle()->applyFromArray($style);
                        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
                        //Header

        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        //Nama File
        header('Content-Disposition: attachment;filename="REPORT PO ASET HWI PATI.xlsx"');
                        //Download
        $objWriter->save("php://output");
    }

    function report_cms(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $cms = $this->m_report->get_po_cms()->result();
        $this->load->view('_template/header');
        $this->load->view('report/v_report_cms', array('cms'=>$cms));
        $this->load->view('_template/footer');
    }

    function get_data_po_cms(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_report->get_datatables_po_cms();
        $data = array();
        $no = @$_POST['start'];
        if(is_array($list) || is_object($list)){
            foreach($list as $field){
                $no++;
                $row = array();
                $row[] = $no;
                $row[] = $field->no_po;
                $row[] = $field->nama_barang;
                $row[] = $field->jumlah;
                $row[] = $field->jumlah_done;
                $row[] = $field->jumlah_waiting;
                $row[] = $field->satuan;
                $row[] = $field->kurs;
                $row[] = number_format($field->harga);
                $row[] = number_format($field->ppn);
                if($field->status == 0){
                    $row[] = '<span class="badge badge-pill badge-warning">Waiting</span>';
                }else{
                    $row[] = '<span class="badge badge-pill badge-success">Done</span>';
                }
                $row[] = $field->updated_at;
                $data[] = $row;
            }
        }
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $this->m_report->count_all_po_cms(),
            "recordsFiltered" => $this->m_report->count_filtered_po_cms(),
            "data" => $data,
        );
        //output dalam format JSON
        echo json_encode($output);
    }

    function export_report_po_cms($id_po){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $objPHPExcel = new PHPExcel();
                            // mengatur center
        $style = array(  
            'font' => array(
                'size' => 12,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_left = array(  
            'font' => array(
                'size' => 11
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                ),
                'borders' => array(    
                    'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                    'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                    'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                    'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
                )
        );

        $style_center = array(  
            'font' => array(
                'size' => 11,
                
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_col = array(  
            'font' => array(
                'bold' => false,
                'size' => 11), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
                ),          
            'borders' => array(    
                'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
            )   
        );

        $style_header = array(  
            'font' => array(
                'size' => 14,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        if($id_po == '-'){
            $data = $this->m_report->get_data_po_cms_1();
        }else{
            $data = $this->m_report->get_data_po_cms_2($id_po);
        }

        $objPHPExcel->getActiveSheet()->mergeCells('A1:M1');
        $objPHPExcel->getActiveSheet()->setCellValue('A1','REPORT PO CONSUMABLE HWI PATI');
                
        $heading=array('NO','NO PO','BARANG','QTY PO','QTY DONE','QTY WAITING','SATUAN','KURS','HARGA','HARGA + PPN','SURAT JALAN','STATUS','DIUPDATE');
        $rowNumberH = 4;
        $colH = 'A';
        foreach($heading as $h){
            $objPHPExcel->getActiveSheet()->setCellValue($colH.$rowNumberH,$h);
            $colH++;
        }

        $totn=$data->num_rows();
        $maxRow= $totn+1;
        $q = $data->result();
        $row = 5;
        $nomor = 1;
        foreach ($q as $dt){
            $objPHPExcel->getActiveSheet()->setCellValue('A'.$row,$nomor);
            $objPHPExcel->getActiveSheet()->setCellValue('B'.$row,$dt->no_po);
            $objPHPExcel->getActiveSheet()->setCellValue('C'.$row,$dt->nama_barang);
            $objPHPExcel->getActiveSheet()->setCellValue('D'.$row,$dt->jumlah);
            $objPHPExcel->getActiveSheet()->setCellValue('E'.$row,$dt->jumlah_done);
            $objPHPExcel->getActiveSheet()->setCellValue('F'.$row,$dt->jumlah_waiting);
            $objPHPExcel->getActiveSheet()->setCellValue('G'.$row,$dt->satuan);
            $objPHPExcel->getActiveSheet()->setCellValue('H'.$row,$dt->kurs);
            if($dt->kurs == 'IDR'){
                $format = '_("Rp"* #,##0.00_)';
            }elseif($dt->kurs == 'USD'){
                $format = '_("$"* #,##0.00_)';
            }else{
                $format = '_("₩"* #,##0.00_)';
            }
            $objPHPExcel->getActiveSheet()->getStyle('I'.$row)->getNumberFormat()->setFormatCode($format);
            $objPHPExcel->getActiveSheet()->getStyle('J'.$row)->getNumberFormat()->setFormatCode($format);
            $objPHPExcel->getActiveSheet()->setCellValue('I'.$row,$dt->harga);
            $objPHPExcel->getActiveSheet()->setCellValue('J'.$row,$dt->ppn);
            $objPHPExcel->getActiveSheet()->setCellValue('K'.$row,$dt->no_surat_jalan);
            if($dt->status == 1){
                $objPHPExcel->getActiveSheet()->setCellValue('L'.$row,'Done');
            }else{
                $objPHPExcel->getActiveSheet()->setCellValue('L'.$row,'Waiting');
            }
            $objPHPExcel->getActiveSheet()->setCellValue('M'.$row,$dt->updated_at);            
            $row++;
            $nomor++;
        }

        for($i=4; $i<$row; $i++){
            $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('B'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('C'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('D'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('E'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('F'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('G'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('H'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('I'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('J'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('K'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('L'.$i)->applyFromArray($style_col); 
            $objPHPExcel->getActiveSheet()->getStyle('M'.$i)->applyFromArray($style_col);     
        }

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(8);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(8);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(8);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(8);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(6);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(30);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(8);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(20);

        $objPHPExcel->getActiveSheet()->getStyle('A4:M4')->applyFromArray($style_center);
        $objPHPExcel->getActiveSheet()->getStyle('A1:M1')->applyFromArray($style_header);

        $objPHPExcel->getActiveSheet()->setTitle('REPORT PO CONSUMABLE HWI PATI');
        $objPHPExcel->getDefaultStyle()->applyFromArray($style);
                        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
                        //Header

        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        //Nama File
        header('Content-Disposition: attachment;filename="REPORT PO CONSUMABLE HWI PATI.xlsx"');
                        //Download
        $objWriter->save("php://output");
    }

    function report_service(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $service = $this->m_report->get_po_service()->result();
        $this->load->view('_template/header');
        $this->load->view('report/v_report_service', array('service'=>$service));
        $this->load->view('_template/footer');
    }

    function get_data_po_service(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_report->get_datatables_po_service();
        $data = array();
        $no = @$_POST['start'];
        if(is_array($list) || is_object($list)){
            foreach($list as $field){
                $no++;
                $row = array();
                $row[] = $no;
                $row[] = $field->no_po;
                $row[] = $field->nama_supplier;
                $row[] = $field->id_stok;
                $row[] = $field->nama_model;
                $row[] = $field->sn;
                $row[] = $field->ppn;
                $row[] = $field->keterangan;
                if($field->status == 0){
                    $row[] = '<span class="badge badge-pill badge-warning">Waiting</span>';
                }else{
                    $row[] = '<span class="badge badge-pill badge-success">Done</span>';
                }
                $row[] = $field->updated_at;
                $data[] = $row;
            }
        }
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $this->m_report->count_all_po_service(),
            "recordsFiltered" => $this->m_report->count_filtered_po_service(),
            "data" => $data,
        );
        //output dalam format JSON
        echo json_encode($output);
    }

    function surat_jalan(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $surat_jalan = $this->m_surat_jalan->get_sj_close()->result();
        $this->load->view('_template/header');
        $this->load->view('report/v_report_sj',array('surat_jalan'=>$surat_jalan));
        $this->load->view('_template/footer');
    }

    function get_data_sj(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_report->get_datatables_sj();
        $data = array();
        $no = @$_POST['start'];
        if(is_array($list) || is_object($list)){
            foreach($list as $field){
                $no++;
                $row = array();
                $row[] = $no;
                $row[] = $field->surat_jalan;
                $row[] = $field->tanggal;
                $row[] = $field->nama_supplier;
                $row[] = $field->qr;
                $row[] = $field->nama_jenis_barang;
                $row[] = $field->nama_model;
                $row[] = $field->unit;
                $row[] = $field->qty;
                $row[] = $field->sn;
                $row[] = $field->no_po;
                $row[] = $field->keterangan;
                $data[] = $row;
            }
        }
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $this->m_report->count_all_sj(),
            "recordsFiltered" => $this->m_report->count_filtered_sj(),
            "data" => $data,
        );
        //output dalam format JSON
        echo json_encode($output);
    }

    function export_report_sj($id_surat_jalan){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $data = $this->m_surat_jalan->get_detail_sj($id_surat_jalan);
        $sj = $this->m_surat_jalan->get_data_surat_jalan($id_surat_jalan);
        
        $objPHPExcel = new PHPExcel();

        $style_center = array(  
            'font' => array(
                'size' => 12,                
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
                )  
        );

        $style_col = array(  
            'font' => array(
                'bold' => false,
                'size' => 12), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
                ),          
            'borders' => array(    
                'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
            )   
        );

        $style_left = array(  
            'font' => array(
                'size' => 12
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                ),
                'borders' => array(    
                    'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                    'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                    'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                    'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
                )
        );

        $style_header = array(  
            'font' => array(
                'size' => 14,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );       
        

        // Sheet Surat Jalan
        $objPHPExcel->setActiveSheetIndex(0);
        $objPHPExcel->getActiveSheet()->mergeCells('A1:I1');
        $objPHPExcel->getActiveSheet()->mergeCells('A2:I2');
        $objPHPExcel->getActiveSheet()->mergeCells('A3:I3');
        $objPHPExcel->getActiveSheet()->setCellValue('A1','PT HWASEUNG INDONESIA');
        $objPHPExcel->getActiveSheet()->getStyle('A1:I1')->applyFromArray($style_header);
        $objPHPExcel->getActiveSheet()->setCellValue('A2','Jl. Krasak Banyuputih RT. 09/III Kec. Kalinyamatan Kab. Jepara, Jawa Tengah');
        $objPHPExcel->getActiveSheet()->getStyle('A2:I2')->applyFromArray($style_center);
        $objPHPExcel->getActiveSheet()->setCellValue('A3','Kode pos 59462 Telp. (0291)7512198 Fax. (0291)7512191');
        $objPHPExcel->getActiveSheet()->getStyle('A3:I3')->applyFromArray($style_center);

        $objPHPExcel->getActiveSheet()->mergeCells('A5:I5');
        $objPHPExcel->getActiveSheet()->setCellValue('A5','SURAT JALAN');
        $objPHPExcel->getActiveSheet()->getStyle('A5:I5')->applyFromArray($style_header);

        $a = $sj->row(); 
        $row_j = 7;
        $objPHPExcel->getActiveSheet()->mergeCells('A'.$row_j.':'.'B'.$row_j);        
        $objPHPExcel->getActiveSheet()->setCellValue('A'.$row_j,'Tanggal');
        $objPHPExcel->getActiveSheet()->setCellValue('C'.$row_j,$a->tanggal);
        $objPHPExcel->getActiveSheet()->setCellValue('F'.$row_j,'Kepada');
        $objPHPExcel->getActiveSheet()->mergeCells('G'.$row_j.':'.'I'.$row_j);
        $objPHPExcel->getActiveSheet()->setCellValue('G'.$row_j,$a->nama_supplier);

        $row_j2 = $row_j+1;
        $objPHPExcel->getActiveSheet()->mergeCells('A'.$row_j2.':'.'B'.$row_j2);       
        $objPHPExcel->getActiveSheet()->setCellValue('A'.$row_j2,'No');
        $objPHPExcel->getActiveSheet()->setCellValue('C'.$row_j2,$a->surat_jalan);
        $objPHPExcel->getActiveSheet()->setCellValue('F'.$row_j2,'Tel / fax');
        $objPHPExcel->getActiveSheet()->mergeCells('G'.$row_j2.':'.'I'.$row_j2);
        $objPHPExcel->getActiveSheet()->setCellValue('G'.$row_j2,$a->phone);

        $row_j3 = $row_j2+1;
        $objPHPExcel->getActiveSheet()->mergeCells('A'.$row_j3.':'.'B'.$row_j3); 
        $objPHPExcel->getActiveSheet()->setCellValue('A'.$row_j3,'Tentang');
        $objPHPExcel->getActiveSheet()->setCellValue('C'.$row_j3,$a->keterangan);
        $objPHPExcel->getActiveSheet()->setCellValue('F'.$row_j3,'Alamat');
        $objPHPExcel->getActiveSheet()->setCellValue('G'.$row_j3,$a->alamat_supplier);
        $objPHPExcel->getActiveSheet()->mergeCells('G'.$row_j3.':'.'I'.$row_j3);

        for($a=$row_j; $a<=$row_j3; $a++){
            $objPHPExcel->getActiveSheet()->getStyle('A'.$a)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('B'.$a)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('C'.$a)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('F'.$a)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('G'.$a)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('H'.$a)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('I'.$a)->applyFromArray($style_left);
        }
        $objPHPExcel->getActiveSheet()->getRowDimension('9')->setRowHeight(50);

        $objDrawing = new PHPExcel_Worksheet_Drawing();
        $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
        $objDrawing->setCoordinates('A1');
        $objDrawing->setOffsetX(15);                            // set x position 
        $objDrawing->setOffsetY(4);
        $objDrawing->setPath('assets/images/hwi.png');
        $objDrawing->setWidth(90)->setHeight(50);
        $objPHPExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(15);
        $objPHPExcel->getActiveSheet()->getRowDimension('8')->setRowHeight(29.25);
        $heading=array('NO','BARANG','SPESIFIKASI','UNIT','QTY','QR','SN','NO PO','KETERANGAN');
        $rowNumberH = 11;
        $colH = 'A';
        foreach($heading as $h){
            $objPHPExcel->getActiveSheet()->setCellValue($colH.$rowNumberH,$h);
            $colH++;
        }

        $row = $rowNumberH+1;
        $no =1;
        $b = $data->result();
        foreach ($b as $c){
            $objPHPExcel->getActiveSheet()->setCellValue('A'.$row,$no);
            $objPHPExcel->getActiveSheet()->setCellValue('B'.$row,$c->nama_jenis_barang);
            $objPHPExcel->getActiveSheet()->setCellValue('C'.$row,$c->nama_model);
            $objPHPExcel->getActiveSheet()->setCellValue('D'.$row,$c->unit);
            $objPHPExcel->getActiveSheet()->setCellValue('E'.$row,$c->qty);
            $objPHPExcel->getActiveSheet()->setCellValue('F'.$row,$c->qr);
            $objPHPExcel->getActiveSheet()->setCellValue('G'.$row,$c->sn);
            $objPHPExcel->getActiveSheet()->setCellValue('H'.$row,$c->no_po);
            $objPHPExcel->getActiveSheet()->setCellValue('I'.$row,$c->keterangan);
            $row++;
            $no++;
        }

        $nextrow = $row;
        $rowmin = $row - 1;
        
        $objPHPExcel->getActiveSheet()->setCellValue('A'.$nextrow,'JUMLAH BARANG');
        $objPHPExcel->getActiveSheet()->setCellValue('E'.$nextrow,'=SUM(E12:E'.$rowmin.')');
        $objPHPExcel->getActiveSheet()->mergeCells('A'.$nextrow.':D'.$nextrow);
        $objPHPExcel->getActiveSheet()->mergeCells('F'.$nextrow.':I'.$nextrow);

        $nextrow2 = $nextrow+2;
        $objPHPExcel->getActiveSheet()->setCellValue('H'.$nextrow2,'PENERIMA');
        $objPHPExcel->getActiveSheet()->setCellValue('I'.$nextrow2,'IT DEPT');

        $nextrow3 = $nextrow2+1;
        $nextrow4 = $nextrow3+3;
        $objPHPExcel->getActiveSheet()->mergeCells('H'.$nextrow3.':H'.$nextrow4);
        $objPHPExcel->getActiveSheet()->mergeCells('I'.$nextrow3.':I'.$nextrow4);

        $nextrow5 = $nextrow4+1;
        $objPHPExcel->getActiveSheet()->setCellValue('I'.$nextrow5,$a->pengirim);

        for($z=$nextrow2; $z<=$nextrow5; $z++){
            $objPHPExcel->getActiveSheet()->getStyle('H'.$z)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('I'.$z)->applyFromArray($style_col);
        }

        for($i=11; $i<=$row; $i++){
            $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('B'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('C'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('D'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('E'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('F'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('G'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('H'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('I'.$i)->applyFromArray($style_left);   
        }

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(4);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(6);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(5);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(19);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(18);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);

        $objPHPExcel->getActiveSheet()->setTitle('SURAT JALAN');

        // Sheet Packing List
        $objPHPExcel->createSheet();        
        $objPHPExcel->setActiveSheetIndex(1);
        $objPHPExcel->getActiveSheet()->mergeCells('A1:H1');
        $objPHPExcel->getActiveSheet()->mergeCells('A2:H2');
        $objPHPExcel->getActiveSheet()->mergeCells('A3:H3');
        $objPHPExcel->getActiveSheet()->setCellValue('A1','PT HWASEUNG INDONESIA');
        $objPHPExcel->getActiveSheet()->getStyle('A1:H1')->applyFromArray($style_header);
        $objPHPExcel->getActiveSheet()->setCellValue('A2','Jl. Krasak Banyuputih RT. 09/III Kec. Kalinyamatan Kab. Jepara, Jawa Tengah');
        $objPHPExcel->getActiveSheet()->getStyle('A2:H2')->applyFromArray($style_center);
        $objPHPExcel->getActiveSheet()->setCellValue('A3','Kode pos 59462 Telp. (0291)7512198 Fax. (0291)7512191');
        $objPHPExcel->getActiveSheet()->getStyle('A3:H3')->applyFromArray($style_center);

        $objPHPExcel->getActiveSheet()->mergeCells('A5:H5');
        $objPHPExcel->getActiveSheet()->setCellValue('A5','PACKING LIST');
        $objPHPExcel->getActiveSheet()->getStyle('A5:H5')->applyFromArray($style_header);

        $pl = $sj->row(); 
        $row_k = 7;
        $objPHPExcel->getActiveSheet()->mergeCells('A'.$row_k.':'.'B'.$row_k);        
        $objPHPExcel->getActiveSheet()->setCellValue('A'.$row_k,'Tanggal');
        $objPHPExcel->getActiveSheet()->setCellValue('C'.$row_k,$pl->tanggal);
        $objPHPExcel->getActiveSheet()->setCellValue('F'.$row_k,'Kepada');
        $objPHPExcel->getActiveSheet()->mergeCells('G'.$row_k.':'.'H'.$row_k);
        $objPHPExcel->getActiveSheet()->setCellValue('G'.$row_k,$pl->nama_supplier);

        $row_k2 = $row_k+1;
        $objPHPExcel->getActiveSheet()->mergeCells('A'.$row_k2.':'.'B'.$row_k2);       
        $objPHPExcel->getActiveSheet()->setCellValue('A'.$row_k2,'No');
        $objPHPExcel->getActiveSheet()->setCellValue('C'.$row_k2,$pl->packing_list);
        $objPHPExcel->getActiveSheet()->setCellValue('F'.$row_k2,'Tel / fax');
        $objPHPExcel->getActiveSheet()->mergeCells('G'.$row_k2.':'.'H'.$row_k2);
        $objPHPExcel->getActiveSheet()->setCellValue('G'.$row_k2,$pl->phone);

        $row_k3 = $row_k2+1;
        $objPHPExcel->getActiveSheet()->mergeCells('A'.$row_k3.':'.'B'.$row_k3); 
        $objPHPExcel->getActiveSheet()->setCellValue('A'.$row_k3,'Tentang');
        $objPHPExcel->getActiveSheet()->setCellValue('C'.$row_k3,$pl->keterangan);
        $objPHPExcel->getActiveSheet()->setCellValue('F'.$row_k3,'Alamat');
        $objPHPExcel->getActiveSheet()->setCellValue('G'.$row_k3,$pl->alamat_supplier);
        $objPHPExcel->getActiveSheet()->mergeCells('G'.$row_k3.':'.'H'.$row_k3);

        for($a=$row_k; $a<=$row_k3; $a++){
            $objPHPExcel->getActiveSheet()->getStyle('A'.$a)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('B'.$a)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('C'.$a)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('F'.$a)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('G'.$a)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('H'.$a)->applyFromArray($style_left);
        }
        $objPHPExcel->getActiveSheet()->getRowDimension('9')->setRowHeight(50);

        $objDrawing = new PHPExcel_Worksheet_Drawing();
        $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
        $objDrawing->setCoordinates('A1');
        $objDrawing->setOffsetX(15);                            // set x position 
        $objDrawing->setOffsetY(4);
        $objDrawing->setPath('assets/images/hwi.png');
        $objDrawing->setWidth(90)->setHeight(50);
        $objPHPExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(15);
        $objPHPExcel->getActiveSheet()->getRowDimension('8')->setRowHeight(29.25);
        $heading=array('NO','BARANG','SPESIFIKASI','UNIT','QTY','NETTO (KG)','GROSS (KG)','VOLUME (M3)');
        $rowNumberH = 11;
        $colH = 'A';
        foreach($heading as $h){
            $objPHPExcel->getActiveSheet()->setCellValue($colH.$rowNumberH,$h);
            $colH++;
        }

        $row = $rowNumberH+1;
        $no =1;
        $b = $data->result();
        foreach ($b as $c){
            $objPHPExcel->getActiveSheet()->setCellValue('A'.$row,$no);
            $objPHPExcel->getActiveSheet()->setCellValue('B'.$row,$c->nama_jenis_barang);
            $objPHPExcel->getActiveSheet()->setCellValue('C'.$row,$c->nama_model);
            $objPHPExcel->getActiveSheet()->setCellValue('D'.$row,$c->unit);
            $objPHPExcel->getActiveSheet()->setCellValue('E'.$row,$c->qty);
            $objPHPExcel->getActiveSheet()->setCellValue('F'.$row,$c->netto);
            $objPHPExcel->getActiveSheet()->setCellValue('G'.$row,$c->gross);
            $objPHPExcel->getActiveSheet()->setCellValue('H'.$row,$c->volume);
            $row++;
            $no++;
        }

        $nextrow_pl = $row;
        $rowmin_pl = $row - 1;
        
        $objPHPExcel->getActiveSheet()->setCellValue('A'.$nextrow_pl,'JUMLAH BARANG');
        $objPHPExcel->getActiveSheet()->setCellValue('E'.$nextrow_pl,'=SUM(E12:E'.$rowmin_pl.')');
        $objPHPExcel->getActiveSheet()->mergeCells('A'.$nextrow_pl.':D'.$nextrow_pl);
        $objPHPExcel->getActiveSheet()->mergeCells('F'.$nextrow_pl.':H'.$nextrow_pl);

        $nextrow2_pl = $nextrow_pl+2;
        $objPHPExcel->getActiveSheet()->setCellValue('G'.$nextrow2_pl,'PENGIRIM');
        $objPHPExcel->getActiveSheet()->setCellValue('H'.$nextrow2_pl,'PENERIMA');

        $nextrow3_pl = $nextrow2_pl+1;
        $nextrow4_pl = $nextrow3_pl+3;
        $objPHPExcel->getActiveSheet()->mergeCells('G'.$nextrow3_pl.':G'.$nextrow4_pl);
        $objPHPExcel->getActiveSheet()->mergeCells('H'.$nextrow3_pl.':H'.$nextrow4_pl);

        $nextrow5_pl = $nextrow4_pl+1;
        $objPHPExcel->getActiveSheet()->setCellValue('G'.$nextrow5_pl,$pl->pengirim);

        for($z=$nextrow2_pl; $z<=$nextrow5_pl; $z++){
            $objPHPExcel->getActiveSheet()->getStyle('G'.$z)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('H'.$z)->applyFromArray($style_col);
        }

        for($i=11; $i<=$row; $i++){
            $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('B'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('C'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('D'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('E'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('F'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('G'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('H'.$i)->applyFromArray($style_col);   
        }

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(4);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(35);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(6);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(5);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(18);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(18);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(20);
        
        $objPHPExcel->getActiveSheet()->setTitle('PACKING LIST');
        
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="SURAT JALAN & PACKING LIST IT.xlsx"');
        $objWriter->save("php://output");
    }

    function report_proyek(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $proyek = $this->m_proyek->get_proyek()->result();
        $this->load->view('_template/header');
        $this->load->view('report/v_report_proyek', array('proyek'=>$proyek));
        $this->load->view('_template/footer');
    }

    function get_data_report_proyek(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_report->get_datatables_proyek();
        $data = array();
        $no = @$_POST['start'];
        if(is_array($list) || is_object($list)){
            foreach($list as $field){
                $no++;
                $row = array();
                $row[] = $no;
                $row[] = $field->id_stok;
                $row[] = $field->id_aset;
                $row[] = $field->nama_jenis_barang;
                $row[] = $field->nama_model;
                if($field->status_keterangan == '0'){
                    $row[] = 'STOCK';
                }elseif($field->status_keterangan == '1'){
                    $row[] = 'INSTALLED';
                }elseif($field->status_keterangan == '3'){
                    $row[] = 'BROKEN ON IT';
                }else{
                    $row[] = 'BROKEN ON VENDOR';
                }
                $row[] = $field->nama_lokasi;
                $row[] = $field->detail_lokasi;
                if($field->nik == ''){
                    $row[] = $field->nama_user;
                }else{
                    $row[] = $field->nik.' - '.$field->NAME;
                }                
                $row[] = $field->sn;
                $row[] = $field->remark;
                $data[] = $row;
            }
        }
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $this->m_report->count_all_proyek(),
            "recordsFiltered" => $this->m_report->count_filtered_proyek(),
            "data" => $data,
        );
        //output dalam format JSON
        echo json_encode($output);
    }

    function export_report_proyek($id_proyek){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }
        
        $objPHPExcel = new PHPExcel();
                            // mengatur center
        $style = array(  
            'font' => array(
                'size' => 12,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_left = array(  
            'font' => array(
                'size' => 11
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                ),
                'borders' => array(    
                    'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                    'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                    'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                    'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
                )
        );

        $style_center = array(  
            'font' => array(
                'size' => 11,
                
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_col = array(  
            'font' => array(
                'bold' => false,
                'size' => 11), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
                ),          
            'borders' => array(    
                'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
            )   
        );

        $style_header = array(  
            'font' => array(
                'size' => 14,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        if($id_proyek == '-'){
            $data = $this->m_report->get_data_proyek_1();
        }else{
            $data = $this->m_report->get_data_proyek_2($id_proyek);
        }

        $objPHPExcel->getActiveSheet()->mergeCells('A1:P1');
        $objPHPExcel->getActiveSheet()->setCellValue('A1','REPORT PROYEK ASET HWI PATI');
                
        $heading=array('NO','NAMA PROYEK','NAMA SUPPLIER','QR','KODE ASET','JENIS BARANG','MODEL BARANG','KODE EPTE','KODE FA','LOKASI','DETAIL LOKASI','NIK','USER','SN','STATUS','REMARK');
        $rowNumberH = 4;
        $colH = 'A';
        foreach($heading as $h){
            $objPHPExcel->getActiveSheet()->setCellValue($colH.$rowNumberH,$h);
            $colH++;
        }

        $totn=$data->num_rows();
        $maxRow= $totn+1;
        $q = $data->result();
        $row = 5;
        $nomor = 1;
        foreach ($q as $dt){
            $objPHPExcel->getActiveSheet()->setCellValue('A'.$row,$nomor);
            $objPHPExcel->getActiveSheet()->setCellValue('B'.$row,$dt->nama_proyek);
            $objPHPExcel->getActiveSheet()->setCellValue('C'.$row,$dt->nama_supplier);
            $objPHPExcel->getActiveSheet()->setCellValue('D'.$row,$dt->id_stok);
            $objPHPExcel->getActiveSheet()->setCellValue('E'.$row,$dt->id_aset);
            $objPHPExcel->getActiveSheet()->setCellValue('F'.$row,$dt->nama_jenis_barang);
            $objPHPExcel->getActiveSheet()->setCellValue('G'.$row,$dt->nama_model);
            $objPHPExcel->getActiveSheet()->setCellValue('H'.$row,$dt->epte_code);
            $objPHPExcel->getActiveSheet()->setCellValue('I'.$row,$dt->FA_code);
            $objPHPExcel->getActiveSheet()->setCellValue('J'.$row,$dt->nama_lokasi);
            $objPHPExcel->getActiveSheet()->setCellValue('K'.$row,$dt->detail_lokasi);
            if($dt->nik == ''){
                $objPHPExcel->getActiveSheet()->setCellValue('L'.$row,'-');
                $objPHPExcel->getActiveSheet()->setCellValue('M'.$row,$dt->nama_user);
            }else{
                $objPHPExcel->getActiveSheet()->setCellValue('L'.$row,$dt->nik);
                $objPHPExcel->getActiveSheet()->setCellValue('M'.$row,$dt->NAME);
            }            
            $objPHPExcel->getActiveSheet()->setCellValue('N'.$row,$dt->sn);
            if($dt->status_keterangan == '0'){
                $objPHPExcel->getActiveSheet()->setCellValue('O'.$row,'STOCK');
            }elseif($dt->status_keterangan == '1'){
                $objPHPExcel->getActiveSheet()->setCellValue('O'.$row,'INSTALLED');
            }elseif($dt->status_keterangan == '3'){
                $objPHPExcel->getActiveSheet()->setCellValue('O'.$row,'BROKEN ON IT');
            }else{
                $objPHPExcel->getActiveSheet()->setCellValue('O'.$row,'BROKEN ON VENDOR');
            }
            $objPHPExcel->getActiveSheet()->setCellValue('P'.$row,$dt->remark);
            $row++;
            $nomor++;
        }

        for($i=4; $i<$row; $i++){
            $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('B'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('C'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('D'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('E'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('F'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('G'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('H'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('I'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('J'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('K'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('L'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('M'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('N'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('O'.$i)->applyFromArray($style_col); 
            $objPHPExcel->getActiveSheet()->getStyle('P'.$i)->applyFromArray($style_left);           
        }

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(30);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(30);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(13);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(30);

        $objPHPExcel->getActiveSheet()->getStyle('A4:P4')->applyFromArray($style_center);
        $objPHPExcel->getActiveSheet()->getStyle('A1:P1')->applyFromArray($style_header);

        $objPHPExcel->getActiveSheet()->setTitle('REPORT PROYEK ASET HWI PATI');
        $objPHPExcel->getDefaultStyle()->applyFromArray($style);
                        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
                        //Header

        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        //Nama File
        header('Content-Disposition: attachment;filename="REPORT PROYEK ASET HWI PATI.xlsx"');
                        //Download
        $objWriter->save("php://output");
    }

    function barang_transfer(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('report/v_report_hwi1');
        $this->load->view('_template/footer');
    }

    function get_data_hwi1(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $where = "SUBSTRING(id_stok,1,3)<>'hwp'";

        $list = $this->m_report->get_datatables_hwi1($where);
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->id_stok;
            if($field->no_po == ''){
                $row[] = $field->nama_proyek;
            }else{
                $row[] = $field->no_po;
            }
            $row[] = $field->id_aset;
            $row[] = $field->nama_jenis_barang;
            $row[] = $field->nama_model;
            if($field->jenis_aset == '0'){
                $row[] = '<span class="badge badge-pill badge-primary">Po</span>';
            }elseif($field->jenis_aset == '1'){
                $row[] = '<span class="badge badge-pill badge-success">Rental</span>';
            }else{
                $row[] = '<span class="badge badge-pill badge-danger">Projek</span>';
            }
            if($field->status_keterangan == '0'){
                $row[] = 'STOCK';
            }elseif($field->status_keterangan == '1'){
                $row[] = 'INSTALLED';
            }elseif($field->status_keterangan == '3'){
                $row[] = 'BROKEN ON IT';
            }else{
                $row[] = 'BROKEN ON VENDOR';
            }
            $row[] = $field->kurs;
            $row[] = $field->harga;
            $row[] = $field->nama_lokasi;
            $row[] = $field->detail_lokasi;
            if($field->nik == ''){
                $row[] = $field->nama_user;
            }else{
                $row[] = $field->NAME;
            }            
            $row[] = $field->sn;
            $row[] = $field->remark;
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_report->count_all_hwi1($where),
            "recordsFiltered" => $this->m_report->count_filtered_hwi1($where),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function export_report_hwi1(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $data = $this->m_report->export_data_hwi1();

        $objPHPExcel = new PHPExcel();
                            // mengatur center
        $style = array(  
            'font' => array(
                'size' => 12,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_left = array(  
            'font' => array(
                'size' => 11
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                ),
                'borders' => array(    
                    'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                    'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                    'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                    'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
                )
        );

        $style_center = array(  
            'font' => array(
                'size' => 11,
                
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_col = array(  
            'font' => array(
                'bold' => false,
                'size' => 11), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
                ),          
            'borders' => array(    
                'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
            )   
        );

        $style_header = array(  
            'font' => array(
                'size' => 14,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $objPHPExcel->getActiveSheet()->mergeCells('A1:P1');
        $objPHPExcel->getActiveSheet()->setCellValue('A1','REPORT ASET HWI 1');
                
        $heading=array('NO','QR','PO / PROYEK','KODE ASET','JENIS BARANG','MODEL BARANG','JENIS ASET','STATUS','KURS','HARGA','LOKASI','DETAIL LOKASI','NIK','USER','SN','REMARK');
        $rowNumberH = 4;
        $colH = 'A';
        foreach($heading as $h){
            $objPHPExcel->getActiveSheet()->setCellValue($colH.$rowNumberH,$h);
            $colH++;
        }

        $totn=$data->num_rows();
        $maxRow= $totn+1;
        $q = $data->result();
        $row = 5;
        $nomor = 1;
        foreach ($q as $dt){
            $objPHPExcel->getActiveSheet()->setCellValue('A'.$row,$nomor);
            $objPHPExcel->getActiveSheet()->setCellValue('B'.$row,$dt->id_stok);
            if($dt->no_po == ''){
                $objPHPExcel->getActiveSheet()->setCellValue('C'.$row,$dt->nama_proyek);
            }else{
                $objPHPExcel->getActiveSheet()->setCellValue('C'.$row,$dt->no_po);
            }
            $objPHPExcel->getActiveSheet()->setCellValue('D'.$row,$dt->id_aset);
            $objPHPExcel->getActiveSheet()->setCellValue('E'.$row,$dt->nama_jenis_barang);
            $objPHPExcel->getActiveSheet()->setCellValue('F'.$row,$dt->nama_model);
            if($dt->jenis_aset == '0'){
                $objPHPExcel->getActiveSheet()->setCellValue('G'.$row,'PO');
            }elseif($dt->jenis_aset == '1'){
                $objPHPExcel->getActiveSheet()->setCellValue('G'.$row,'RENTAL');
            }else{
                $objPHPExcel->getActiveSheet()->setCellValue('G'.$row,'PROYEK');
            }

            $objPHPExcel->getActiveSheet()->setCellValue('H'.$row,$dt->status);
            $objPHPExcel->getActiveSheet()->setCellValue('I'.$row,$dt->kurs);
            
            if($dt->kurs == 'IDR'){
                $format = '_("Rp"* #,##0.00_)';
            }elseif($dt->kurs == 'USD'){
                $format = '_("$"* #,##0.00_)';
            }else{
                $format = '_("₩"* #,##0.00_)';
            }

            $objPHPExcel->getActiveSheet()->getStyle('J'.$row)->getNumberFormat()->setFormatCode($format);
            
            $objPHPExcel->getActiveSheet()->setCellValue('J'.$row,$dt->harga);
            
            $objPHPExcel->getActiveSheet()->setCellValue('K'.$row,$dt->nama_lokasi);
            $objPHPExcel->getActiveSheet()->setCellValue('L'.$row,$dt->detail_lokasi);
            if($dt->nik == ''){
                $objPHPExcel->getActiveSheet()->setCellValue('M'.$row,'-');
                $objPHPExcel->getActiveSheet()->setCellValue('N'.$row,$dt->nama_user);
            }else{
                $objPHPExcel->getActiveSheet()->setCellValue('M'.$row,$dt->nik);
                $objPHPExcel->getActiveSheet()->setCellValue('N'.$row,$dt->NAME);
            }            
            $objPHPExcel->getActiveSheet()->setCellValue('O'.$row,$dt->sn);
            $objPHPExcel->getActiveSheet()->setCellValue('P'.$row,$dt->remark);
            $row++;
            $nomor++;
        }

        for($i=4; $i<$row; $i++){
            $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('B'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('C'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('D'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('E'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('F'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('G'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('H'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('I'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('J'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('K'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('L'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('M'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('N'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('O'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('P'.$i)->applyFromArray($style_left);      
        }

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(6);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(30);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(13);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(30);

        $objPHPExcel->getActiveSheet()->getStyle('A4:P4')->applyFromArray($style_center);
        $objPHPExcel->getActiveSheet()->getStyle('A1:P1')->applyFromArray($style_header);

        $objPHPExcel->getActiveSheet()->setTitle('REPORT ASET HWI 1');
        $objPHPExcel->getDefaultStyle()->applyFromArray($style);
                        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
                        //Header

        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        //Nama File
        header('Content-Disposition: attachment;filename="REPORT ASET HWI 1.xlsx"');
                        //Download
        $objWriter->save("php://output");
    }
}
