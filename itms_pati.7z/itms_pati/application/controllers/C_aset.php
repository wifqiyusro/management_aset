<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_aset extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(array('m_aset','m_jenis_barang','m_stok_barang','m_lokasi','m_log','m_barang','m_supplier','m_proyek','m_tb_bantu','m_supplier','m_po','m_cms','m_surat_jalan'));
        $this->load->library(array('ciqrcode','PHPExcel'));
    }

	function index(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $aset = $this->m_aset->get_total_aset()->result();
        $this->load->view('_template/header');
        $this->load->view('aset/v_aset', array('aset'=>$aset));
        $this->load->view('_template/footer');
    }

    function detail_aset($kode){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $aset = $this->m_aset->get_total_aset()->result();

        $data = $this->m_jenis_barang->get_nama($kode)->row();
        $nama_jenis_barang = $data->nama_aset;
        
        $id_jenis_barang = $this->m_jenis_barang->get_jenis_barang($kode)->result();
        foreach($id_jenis_barang as $id){
            $jenis_barang[] = $id->id_jenis_barang;
        }
        $sambung = '';

        for($i=0; $i<count($id_jenis_barang); $i++){
            if($i<count($id_jenis_barang)-1){
                $id_jns_brg = "'".$jenis_barang[$i]."',"; 
            }else{
                $id_jns_brg = "'".$jenis_barang[$i]."'";
            }
            $sambung .= $id_jns_brg;
        }

        $stok           = $this->m_stok_barang->get_stok($sambung)->row();
        $terpasang      = $this->m_stok_barang->get_terpasang($sambung)->row();
        $rusak_it       = $this->m_stok_barang->get_rusak_it($sambung)->row();
        $rusak_vendor   = $this->m_stok_barang->get_rusak_vendor($sambung)->row();
        $total          = $stok->jumlah+$terpasang->jumlah+$rusak_it->jumlah+$rusak_vendor->jumlah;

        if($kode == 'AS030'){
            $data = $this->m_stok_barang->aset_pc_non_cell($sambung)->result();
            //cell
            $fa = $this->m_stok_barang->get_pc_prod_a($sambung)->row();
            $fb = $this->m_stok_barang->get_pc_prod_b($sambung)->row();
            $fc = $this->m_stok_barang->get_pc_prod_c($sambung)->row();
            $fd = $this->m_stok_barang->get_pc_prod_d($sambung)->row();
            $fe = $this->m_stok_barang->get_pc_prod_e($sambung)->row();
            $ff = $this->m_stok_barang->get_pc_prod_f($sambung)->row();

            $this->load->view('_template/header');
            $this->load->view('aset/v_detail_aset_pc', array('data'=>$data,'aset'=>$aset,'stok'=>$stok,'terpasang'=>$terpasang,'rusak_it'=>$rusak_it,'rusak_vendor'=>$rusak_vendor,'total'=>$total,'nama_jenis_barang'=>$nama_jenis_barang,'kode'=>$kode,'fa'=>$fa,'fb'=>$fb,'fc'=>$fc,'fd'=>$fd,'fe'=>$fe,'ff'=>$ff));
            $this->load->view('_template/footer');
        }else{
            $data = $this->m_stok_barang->aset_non_pc($sambung)->result();

            $this->load->view('_template/header');
            $this->load->view('aset/v_detail_aset', array('data'=>$data,'aset'=>$aset,'stok'=>$stok,'terpasang'=>$terpasang,'rusak_it'=>$rusak_it,'rusak_vendor'=>$rusak_vendor,'total'=>$total,'nama_jenis_barang'=>$nama_jenis_barang,'kode'=>$kode));
            $this->load->view('_template/footer');
        }
    }

    function detail_lokasi($kode,$lokasi){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $aset   = $this->m_aset->get_total_aset()->result();
        $data   = $this->m_jenis_barang->get_nama($kode)->row();
        $nama_jenis_barang = $data->nama_aset;
        $data2  = $this->m_lokasi->get_lokasi($lokasi)->row();
        $nama_lokasi = $data2->nama_lokasi;

        $id_jenis_barang = $this->m_jenis_barang->get_jenis_barang($kode)->result();
        foreach($id_jenis_barang as $id){
            $jenis_barang[] = $id->id_jenis_barang;
        }
        $sambung = '';

        for($i=0; $i<count($id_jenis_barang); $i++){
            if($i<count($id_jenis_barang)-1){
                $id_jns_brg = "'".$jenis_barang[$i]."',"; 
            }else{
                $id_jns_brg = "'".$jenis_barang[$i]."'";
            }
            $sambung .= $id_jns_brg;
        }

        $stok           = $this->m_stok_barang->get_stok($sambung)->row();
        $terpasang      = $this->m_stok_barang->get_terpasang($sambung)->row();
        $rusak_it       = $this->m_stok_barang->get_rusak_it($sambung)->row();
        $rusak_vendor   = $this->m_stok_barang->get_rusak_vendor($sambung)->row();
        $total          = $stok->jumlah+$terpasang->jumlah+$rusak_it->jumlah+$rusak_vendor->jumlah;

        $barang         = $this->m_barang->get_barang($sambung,$lokasi)->result();
        //$karyawan       = $this->m_aset->get_karyawan()->result();

        $this->load->view('_template/header');
        $this->load->view('aset/v_detail_lokasi',array('aset'=>$aset,'stok'=>$stok,'terpasang'=>$terpasang,'rusak_it'=>$rusak_it,'rusak_vendor'=>$rusak_vendor,
        'total'=>$total,'nama_jenis_barang'=>$nama_jenis_barang,'kode'=>$kode,'lokasi'=>$lokasi,'nama_lokasi'=>$nama_lokasi,'barang'=>$barang));
        $this->load->view('_template/footer');
    }

    function get_detail_aset($kode,$lokasi){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $id_jenis_barang = $this->m_jenis_barang->get_jenis_barang($kode)->result();
        foreach($id_jenis_barang as $id){
            $jenis_barang[] = $id->id_jenis_barang;
        }
        $sambung = '';

        for($i=0; $i<count($id_jenis_barang); $i++){
            if($i<count($id_jenis_barang)-1){
                $id_jns_brg = "'".$jenis_barang[$i]."',"; 
            }else{
                $id_jns_brg = "'".$jenis_barang[$i]."'";
            }
            $sambung .= $id_jns_brg;
        }

        $where = "s.status_keterangan = 1 AND j.id_jenis_barang IN (".$sambung.") AND s.jenis_aset NOT IN ('7','8')";

        $list = $this->m_stok_barang->get_datatables($where,$lokasi);
        $data = array();
        $no = @$_POST['start'];
        if(is_array($list) || is_object($list)){
            foreach($list as $field){
                $no++;
                $row = array();
                $row[] = $no;
                if($kode == 'AS030'){
                    $row[] = $field->id_stok;
                    $row[] = $field->id_aset;
                }else{
                    $row[] = $field->id_stok;
                }
                // $row[] = $field->kode_sap;                
                $row[] = $field->nama_model;
                if($field->jenis_aset == '0'){
                    $row[] = '<span class="badge badge-pill badge-primary">Po</span>';
                }elseif($field->jenis_aset == '1'){
                    $row[] = '<span class="badge badge-pill badge-success">Rental</span>';
                }else{
                    $row[] = '<span class="badge badge-pill badge-danger">Projek</span>';
                }
                $row[] = $field->kurs;
                $row[] = number_format($field->harga);
                $row[] = $field->detail_lokasi;
                if($field->nik == ''){
                    $row[] = $field->nama_user;
                }else{
                    $row[] = $field->nik.' - '.$field->NAME;
                }                
                $row[] = $field->sn;
                $row[] = $field->remark;
                if($field->qr == ''){
                    $row[] = '';
                }else{
                    $row[] = '<img style="width: 40px;" src="'.base_url().'assets/qr_barang/'.$field->id_stok.'.png">';
                }
                if($this->session->userdata('level_a') == '4'){
                    $row[] = '<a class="btn mb-1 btn-secondary btn-sm" href="'.base_url().'index.php/c_log/log/'.$field->id_stok.'/'.$field->jenis_aset.'" title="History"><i class="fe fe-clock fe-12" aria-hidden="true"></i></a>';
                }else{
                    if($field->qr != ''){
                        $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="edit" onclick="edit_barang('."'".$field->id_stok."'".')"><i class="fe fe-edit fe-12" aria-hidden="true"></i></a>
                      <a class="btn mb-1 btn-secondary btn-sm" href="'.base_url().'index.php/c_log/log/'.$field->id_stok.'/'.$field->jenis_aset.'" title="History"><i class="fe fe-clock fe-12" aria-hidden="true"></i></a>';
                    }else{
                        $row[] = '<a class="btn mb-1 btn-info btn-sm" href="javascript:void(0)" title="Generate" onclick="generate_barang('."'".$field->id_stok."'".')"><i class="fe fe-grid fe-12" aria-hidden="true"></i></a>
                      <a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="edit" onclick="edit_barang('."'".$field->id_stok."'".')"><i class="fe fe-edit fe-12" aria-hidden="true"></i></a>
                      <a class="btn mb-1 btn-secondary btn-sm" href="'.base_url().'index.php/c_log/log/'.$field->id_stok.'/'.$field->jenis_aset.'" title="History"><i class="fe fe-clock fe-12" aria-hidden="true"></i></a>';
                    }
                }
                $data[] = $row;
            }
        }
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $this->m_stok_barang->count_all($where,$lokasi),
            "recordsFiltered" => $this->m_stok_barang->count_filtered($where,$lokasi),
            "data" => $data,
        );
        //output dalam format JSON
        echo json_encode($output);
    }

    function get_karyawan_2(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $searchTerm = $this->input->post('searchTerm');

        $response = $this->m_aset->get_karyawan_2($searchTerm);
        echo json_encode($response);
    }

    function edit_barang($id_stok){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        header('Content-Type: application/json');

        $data = $this->m_stok_barang->edit_barang($id_stok)->row();
        echo json_encode($data);
    }

    function edit_barang_proses(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $id_stok = $this->input->post('id_stok');
        $id_aset = $this->input->post('id_aset');
        $windows_ori = $this->input->post('windows_ori');
        $office_ori = $this->input->post('office_ori');
        $serial_number = $this->input->post('serial_number');
        $serial_number_office = $this->input->post('serial_number_office');
        $os = $this->input->post('os');
        $ram = $this->input->post('ram');
        $koneksi = $this->input->post('koneksi');
        $tipe_koneksi = $this->input->post('tipe_koneksi');
        $mac_adress = $this->input->post('mac_adress');
        $detail_lokasi = $this->input->post('detail_lokasi');
        $tipe_user = $this->input->post('tipe_user');
        if($tipe_user == 'nik'){
            $nik = $this->input->post('nik');
            $nama_user = '';
        }else{
            $nik = '';
            $nama_user =  $this->input->post('nama_user');
        }        
        $sn = $this->input->post('sn');
        $remark = $this->input->post('remark');
        $status_keterangan = $this->input->post('status_keterangan');
        $updated_at = date('Y-m-d H:i:s');
        $id_user = $this->session->userdata('username_a');
        $id_log = 'hwp'.uniqid();
        $keterangan = 'User '.$id_user.' melakukan update data';
        $tgl = date('Y-m-d');
        $vendor = '';
        $surat_jalan = '';

        $update = $this->m_stok_barang->update_barang($id_stok,$id_aset,$windows_ori,$office_ori,$serial_number,$serial_number_office,$os,$ram,$koneksi,$tipe_koneksi,$mac_adress,$detail_lokasi,$nama_user,$nik,$sn,$remark,$updated_at,$id_user);
        if($update){            
            $this->m_log->insert_log($id_log,$id_stok,$id_aset,$status_keterangan,$vendor,$tgl,$surat_jalan,$keterangan,$updated_at,$id_user);
        }
        echo json_encode(array("status"=>TRUE));
    }

    function generate_qr($id_stok){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $updated_at = date('Y-m-d H:i:s');
        $id_user = $this->session->userdata('username_a');

        $config['cacheable']    = true; //boolean, the default is true
        $config['cachedir']     = './assets/'; //string, the default is application/cache/
        $config['errorlog']     = './assets/'; //string, the default is application/logs/
        $config['imagedir']     = './assets/qr_barang/'; //direktori penyimpanan qr code
        $config['quality']      = true; //boolean, the default is true
        $config['size']         = '1024'; //interger, the default is 1024
        $config['black']        = array(224,255,255); // array, default is array(255,255,255)
        $config['white']        = array(70,130,180); // array, default is array(0,0,0)
        $this->ciqrcode->initialize($config);

        $image_name=$id_stok.'.png';

        $params['data'] = $id_stok; //data yang akan di jadikan QR CODE
        $params['level'] = 'H'; //H=High
        $params['size'] = 10;
        $params['savename'] = FCPATH.$config['imagedir'].$image_name; //simpan image QR CODE ke folder assets/images/
        $this->ciqrcode->generate($params);

        $this->m_aset->generate_qr($id_stok,$image_name,$updated_at,$id_user);
        echo json_encode(array("status" => TRUE));
    }

    function export_detail_lokasi($jenis_aset,$id_barang,$lokasi,$kode){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $id_jenis_barang = $this->m_jenis_barang->get_jenis_barang($kode)->result();
        $nama_aset = $this->m_jenis_barang->get_nama_aset($kode)->row();
        foreach($id_jenis_barang as $id){
            $jenis_barang[] = $id->id_jenis_barang;
        }
        $sambung = '';

        for($i=0; $i<count($id_jenis_barang); $i++){
            if($i<count($id_jenis_barang)-1){
                $id_jns_brg = "'".$jenis_barang[$i]."',"; 
            }else{
                $id_jns_brg = "'".$jenis_barang[$i]."'";
            }
            $sambung .= $id_jns_brg;
        }

        $temp_lokasi = $this->m_lokasi->get_lokasi($lokasi)->row();
        $nama_lokasi = $temp_lokasi->nama_lokasi;

        $objPHPExcel = new PHPExcel();
                            // mengatur center
        $style = array(  
            'font' => array(
                'size' => 12,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_left = array(  
            'font' => array(
                'size' => 11
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                ),
                'borders' => array(    
                    'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                    'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                    'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                    'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
                )
        );

        $style_center = array(  
            'font' => array(
                'size' => 11,
                
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_col = array(  
            'font' => array(
                'bold' => false,
                'size' => 11), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
                ),          
            'borders' => array(    
                'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
            )   
        );

        $style_header = array(  
            'font' => array(
                'size' => 14,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        if($jenis_aset == '-' && $id_barang == '-'){
            $data = $this->m_aset->export_detail_lokasi1($sambung,$lokasi);            
        }elseif($jenis_aset != '-' && $id_barang == '-'){
            $jenis_aset2 = str_replace('3','0',$jenis_aset);
            $data = $this->m_aset->export_detail_lokasi2($jenis_aset2,$sambung,$lokasi);
        }elseif($jenis_aset == '-' && $id_barang != '-'){
            $data = $this->m_aset->export_detail_lokasi3($id_barang,$sambung,$lokasi);
        }else{
            $jenis_aset2 = str_replace('3','0',$jenis_aset);
            $data = $this->m_aset->export_detail_lokasi4($jenis_aset2,$id_barang,$sambung,$lokasi);
        }

        $objPHPExcel->getActiveSheet()->mergeCells('A1:N1');
        $objPHPExcel->getActiveSheet()->setCellValue('A1',$nama_aset->nama_aset.' - '.$nama_lokasi);
                
        $heading=array('NO','QR','KODE ASET','JENIS BARANG','NAMA MODEL','KODE EPTE','KODE FA','DETAIL LOKASI','NAMA USER','SN','KURS','HARGA','HARGA + PPN','KETERANGAN');
        $rowNumberH = 4;
        $colH = 'A';
        foreach($heading as $h){
            $objPHPExcel->getActiveSheet()->setCellValue($colH.$rowNumberH,$h);
            $colH++;
        }

        $totn=$data->num_rows();
        $maxRow= $totn+1;
        $q = $data->result();
        $row = 5;
        $nomor = 1;
        foreach ($q as $dt){
            $objPHPExcel->getActiveSheet()->setCellValue('A'.$row,$nomor);
            $objPHPExcel->getActiveSheet()->setCellValue('B'.$row,$dt->id_stok);
            $objPHPExcel->getActiveSheet()->setCellValue('C'.$row,$dt->id_aset);
            $objPHPExcel->getActiveSheet()->setCellValue('D'.$row,$dt->nama_jenis_barang);
            $objPHPExcel->getActiveSheet()->setCellValue('E'.$row,$dt->nama_model);
            $objPHPExcel->getActiveSheet()->setCellValue('F'.$row,$dt->epte_code);
            $objPHPExcel->getActiveSheet()->setCellValue('G'.$row,$dt->FA_code);
            $objPHPExcel->getActiveSheet()->setCellValue('H'.$row,$dt->detail_lokasi);
            $objPHPExcel->getActiveSheet()->setCellValue('I'.$row,$dt->nama_user);
            $objPHPExcel->getActiveSheet()->setCellValue('J'.$row,$dt->sn);
            $objPHPExcel->getActiveSheet()->setCellValue('K'.$row,$dt->kurs);
            if($dt->kurs == 'IDR'){
                $format = '_("Rp"* #,##0.00_)';
            }elseif($dt->kurs == 'USD'){
                $format = '_("$"* #,##0.00_)';
            }else{
                $format = '_("₩"* #,##0.00_)';
            }
            $objPHPExcel->getActiveSheet()->getStyle('L'.$row)->getNumberFormat()->setFormatCode($format);
            $objPHPExcel->getActiveSheet()->getStyle('M'.$row)->getNumberFormat()->setFormatCode($format);
            $objPHPExcel->getActiveSheet()->setCellValue('L'.$row,$dt->harga);
            $objPHPExcel->getActiveSheet()->setCellValue('M'.$row,$dt->harga_ppn);
            $objPHPExcel->getActiveSheet()->setCellValue('N'.$row,$dt->remark);
            $row++;
            $nomor++;
        }

        for($i=4; $i<$row; $i++){
            $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('B'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('C'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('D'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('E'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('F'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('G'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('H'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('I'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('J'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('K'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('L'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('M'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('N'.$i)->applyFromArray($style_left);           
        }

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(18);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(35);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(28);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(28);

        $objPHPExcel->getActiveSheet()->getStyle('A4:N4')->applyFromArray($style_center);
        $objPHPExcel->getActiveSheet()->getStyle('A1:N1')->applyFromArray($style_header);

        $objPHPExcel->getActiveSheet()->setTitle($nama_aset->nama_aset.' - '.$nama_lokasi);
        $objPHPExcel->getDefaultStyle()->applyFromArray($style);
                        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
                        //Header

        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        //Nama File
        header('Content-Disposition: attachment;filename="'.$nama_aset->nama_aset.' - '.$nama_lokasi.'.xlsx"');
                        //Download
        $objWriter->save("php://output");        
    }

    function status_aset(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('aset/v_status_aset');
        $this->load->view('_template/footer');
    }

    function proses_cek_status($qr){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $cek_jenis = $this->m_aset->proses_cek_jenis($qr);
        header('Content-Type: application/json');
        if($cek_jenis->num_rows() != '0'){
            $jenis_aset = ($cek_jenis->row())->jenis_aset;
            if($jenis_aset == '2'){
                $data = $this->m_aset->proses_cek_status_proyek($qr);                
                if($data->num_rows() > 0){
                    echo json_encode(array('status'=>'ok', 'hasil'=>($data->row())));
                }else{
                    echo json_encode(array('status'=>'error', 'msg'=>'Data tidak ditemukan'));
                }
            }else{
                $data = $this->m_aset->proses_cek_status($qr);                
                if($data->num_rows() > 0){
                    echo json_encode(array('status'=>'ok', 'hasil'=>($data->row())));
                }else{
                    echo json_encode(array('status'=>'error', 'msg'=>'Data tidak ditemukan'));
                }
            }
        }else{            
            echo json_encode(array('status'=>'error', 'msg'=>'Data tidak ditemukan'));
        }
    }

    function barang_keluar(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $lokasi = $this->m_lokasi->get_all_lokasi()->result();
        $this->load->view('_template/header');
        $this->load->view('aset/v_barang_keluar',array('lokasi'=>$lokasi));
        $this->load->view('_template/footer');
    }

    function cek_status_out($id_stok){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $data = $this->m_aset->cek_data_aset($id_stok);
        header('Content-Type: application/json');
        if($data->num_rows() > '0'){
            if(($data->row())->status_keterangan == '0'){
                echo json_encode(array('status'=>'ok', 'data'=>($data->row())));
            }else{
                echo json_encode(array('status'=>'error', 'msg'=>'Status aset tidak stok'));
            }
        }else{
            echo json_encode(array('status'=>'error', 'msg'=>'Aset tidak ditemukan'));
        }
    }

    function proses_barang_keluar(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $id_stok = $this->input->post('id_stok');
        $id_jenis_barang = $this->input->post('id_jenis_barang');
        $label_jns_barang = $this->input->post('label_jns_barang');
        $lokasi = $this->input->post('lokasi');
        $detail_lokasi = $this->input->post('detail_lokasi');       
        $nik = $this->input->post('nik');
        $nama_user = $this->input->post('nama_user');
        $tanggal_pasang = $this->input->post('tanggal_pasang');
        $pemasang = $this->input->post('pemasang');
        $remark = $this->input->post('remark');
        $kode = $this->input->post('kode');

        if($kode == 'AS030'){
            $windows_ori = $this->input->post('windows_ori');
            $serial_number = $this->input->post('serial_number');
            $office_ori = $this->input->post('office_ori');
            $serial_number_office = $this->input->post('serial_number_office');
            $os = $this->input->post('os');
            $ram = $this->input->post('ram');
            $koneksi = $this->input->post('koneksi');
            $tipe_koneksi = $this->input->post('tipe_koneksi');
        }else{
            $windows_ori = '';
            $serial_number = '';
            $office_ori = '';
            $serial_number_office = '';
            $os = '';
            $ram = '';
            $koneksi = '';
            $tipe_koneksi = '';
        }
        $cek_label = $this->m_lokasi->get_lokasi($lokasi)->row();
        $label = $cek_label->label;

        $cek_aset_terakhir = $this->m_aset->cek_aset_terakhir($id_jenis_barang,$lokasi);
        if(($cek_aset_terakhir->num_rows()) == '0'){
            $id = 'HWP-'.$label.'-'.$label_jns_barang.'-'.'0001';
        }else{
            $oo = $cek_aset_terakhir->row();
            if(strlen(substr($label,4)) == 2 and strlen($label_jns_barang)==2){
                $kode_auto=substr($oo->id_aset,14,4);
            }elseif(strlen(substr($label,4)) == 2 and strlen($label_jns_barang)==3){
                $kode_auto=substr($oo->id_aset,15,4);
            }elseif(strlen(substr($label,4)) == 2 and strlen($label_jns_barang)==4){
                $kode_auto=substr($oo->id_aset,16,4);
            }elseif(strlen(substr($label,4)) == 2 and strlen($label_jns_barang)==5){
                $kode_auto=substr($oo->id_aset,17,4);
            }elseif(strlen(substr($label,4)) == 2 and strlen($label_jns_barang)==6){
                $kode_auto=substr($oo->id_aset,18,4);
            }

            elseif(strlen(substr($label,4)) == 3 and strlen($label_jns_barang)==2){
                $kode_auto=substr($oo->id_aset,15,4);
            }elseif(strlen(substr($label,4)) == 3 and strlen($label_jns_barang)==3){
                $kode_auto=substr($oo->id_aset,16,4);
            }elseif(strlen(substr($label,4)) == 3 and strlen($label_jns_barang)==4){
                $kode_auto=substr($oo->id_aset,17,4);
            }elseif(strlen(substr($label,4)) == 3 and strlen($label_jns_barang)==5){
                $kode_auto=substr($oo->id_aset,18,4);
            }elseif(strlen(substr($label,4)) == 3 and strlen($label_jns_barang)==6){
                $kode_auto=substr($oo->id_aset,19,4);
            }

            elseif(strlen(substr($label,4)) == 4 and strlen($label_jns_barang)==2){
                $kode_auto=substr($oo->id_aset,16,4);
            }elseif(strlen(substr($label,4)) == 4 and strlen($label_jns_barang)==3){
                $kode_auto=substr($oo->id_aset,17,4);
            }elseif(strlen(substr($label,4)) == 4 and strlen($label_jns_barang)==4){
                $kode_auto=substr($oo->id_aset,18,4);
            }elseif(strlen(substr($label,4)) == 4 and strlen($label_jns_barang)==5){
                $kode_auto=substr($oo->id_aset,19,4);
            }elseif(strlen(substr($label,4)) == 4 and strlen($label_jns_barang)==6){
                $kode_auto=substr($oo->id_aset,20,4);
            }

            elseif(strlen(substr($label,4)) == 5 and strlen($label_jns_barang)==2){
                $kode_auto=substr($oo->id_aset,17,4);
            }elseif(strlen(substr($label,4)) == 5 and strlen($label_jns_barang)==3){
                $kode_auto=substr($oo->id_aset,18,4);
            }elseif(strlen(substr($label,4)) == 5 and strlen($label_jns_barang)==4){
                $kode_auto=substr($oo->id_aset,19,4);
            }elseif(strlen(substr($label,4)) == 5 and strlen($label_jns_barang)==5){
                $kode_auto=substr($oo->id_aset,20,4);
            }elseif(strlen(substr($label,4)) == 5 and strlen($label_jns_barang)==6){
                $kode_auto=substr($oo->id_aset,21,4);
            }

            elseif(strlen(substr($label,4)) == 6 and strlen($label_jns_barang)==2){
                $kode_auto=substr($oo->id_aset,18,4);
            }elseif(strlen(substr($label,4)) == 6 and strlen($label_jns_barang)==3){
                $kode_auto=substr($oo->id_aset,19,4);
            }elseif(strlen(substr($label,4)) == 6 and strlen($label_jns_barang)==4){
                $kode_auto=substr($oo->id_aset,20,4);
            }elseif(strlen(substr($label,4)) == 6 and strlen($label_jns_barang)==5){
                $kode_auto=substr($oo->id_aset,21,4);
            }elseif(strlen(substr($label,4)) == 6 and strlen($label_jns_barang)==6){
                $kode_auto=substr($oo->id_aset,22,4);
            }

            $tambah1=$kode_auto+1;
            if($tambah1<10){
                $id= 'HWP-'.$label.'-'.$label_jns_barang.'-'.'000'.$tambah1;
            }elseif($tambah1<100){
                $id= 'HWP-'.$label.'-'.$label_jns_barang.'-'.'00'.$tambah1;
            }elseif($tambah1<1000){
                $id= 'HWP-'.$label.'-'.$label_jns_barang.'-'.'0'.$tambah1;
            }
        }

        $cek_nama_lokasi = $this->m_lokasi->get_lokasi($lokasi)->row();
        $get_row_karyawan = $this->m_aset->get_row_karyawan($nik)->row();
        $NAME = $get_row_karyawan->NAME;
        $nama_lokasi = $cek_nama_lokasi->nama_lokasi;
        $updated_at = date('Y-m-d H:i:s');
        $id_user = $this->session->userdata('username_a');
        $surat_jalan = '';
        $vendor = '';

        $id_log = 'hwp'.uniqid();
        $status_keterangan = '1';
        if($tipe_user == 'nik'){
            $keterangan = 'Dipasang oleh '.$pemasang.', di '.$nama_lokasi.', detail lokasi '.$detail_lokasi.' dengan nama user '.$NAME;
        }else{
            $keterangan = 'Dipasang oleh '.$pemasang.', di '.$nama_lokasi.', detail lokasi '.$detail_lokasi.' dengan nama user '.$nama_user;
        }

        echo $nik;

        // $update = $this->m_aset->update_aset_out($id_stok,$id,$lokasi,$detail_lokasi,$nama_user,$nik,$windows_ori,$office_ori,$serial_number,$serial_number_office,$os,$ram,$koneksi,$tipe_koneksi,$status_keterangan,$remark,$updated_at,$id_user);
        // if($update){
        //     $this->m_log->insert_log($id_log,$id_stok,$id,$status_keterangan,$vendor,$tanggal_pasang,$surat_jalan,$keterangan,$updated_at,$id_user);
        //     $this->session->set_flashdata(array('status'=>'success','msg'=>'Transaksi aset berhasil disimpan'));
        // }
        // redirect('c_aset/barang_keluar');
    }

    function barang_kembali(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('aset/v_barang_kembali');
        $this->load->view('_template/footer');
    }

    function cek_status_in($id_stok){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $data = $this->m_aset->cek_data_aset($id_stok);
        header('Content-Type: application/json');
        if($data->num_rows() > '0'){
            if(($data->row())->status_keterangan != '0'){
                echo json_encode(array('status'=>'ok', 'data'=>($data->row())));
            }else{
                echo json_encode(array('status'=>'error', 'msg'=>'Aset dalam status stok'));
            }
        }else{
            echo json_encode(array('status'=>'error', 'msg'=>'Aset tidak ditemukan'));
        }
    }

    function proses_barang_kembali(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $id_stok = $this->input->post('id_stok');
        $status = $this->input->post('status');
        $tanggal_kembali = $this->input->post('tanggal_kembali');
        $pengambil = $this->input->post('pengambil');
        $keterangan = $this->input->post('keterangan');
        $id_aset = '';
        $lokasi = '';
        $detail_lokasi = '';
        $nik = '';
        $nama_user = '';
        $surat_jalan = '';
        $vendor = '';

        $id_log = 'hwp'.uniqid();
        $status_keterangan = '0';
        $keterangan_log = 'Menjadi stok IT setelah '.$keterangan.', pengambil '.$pengambil;
        $updated_at = date('Y-m-d H:i:s');
        $id_user = $this->session->userdata('username_a');

        $update = $this->m_aset->update_aset($id_stok,$id_aset,$lokasi,$detail_lokasi,$nama_user,$nik,$status_keterangan,$updated_at,$id_user);        
        if($update){
            $this->m_log->insert_log($id_log,$id_stok,$id_aset,$status_keterangan,$vendor,$tanggal_kembali,$surat_jalan,$keterangan_log,$updated_at,$id_user);
            $this->m_aset->delete_tb_vendor($id_stok);
            $this->session->set_flashdata(array('status'=>'success','msg'=>'Transaksi aset berhasil disimpan'));
        }
         redirect('c_aset/barang_kembali');
    }

    function pindah_lokasi(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $lokasi = $this->m_lokasi->get_all_lokasi()->result();
        $this->load->view('_template/header');
        $this->load->view('aset/v_pindah_lokasi', array('lokasi'=>$lokasi));
        $this->load->view('_template/footer');
    }

    function cek_status_pl($id_stok){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }
        
        $data = $this->m_aset->cek_data_aset($id_stok);
        header('Content-Type: application/json');
        if($data->num_rows() > '0'){
            if(($data->row())->status_keterangan == '1'){
                echo json_encode(array('status'=>'ok', 'data'=>($data->row())));
            }else{
                echo json_encode(array('status'=>'error', 'msg'=>'Aset tidak dalam status terpasang'));
            }
        }else{
            echo json_encode(array('status'=>'error', 'msg'=>'Aset tidak ditemukan'));
        }
    }

    function proses_pindah_lokasi(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $id_stok = $this->input->post('id_stok');
        $id_jenis_barang = $this->input->post('id_jenis_barang');
        $label_jns_barang = $this->input->post('label_jns_barang');
        $lokasi = $this->input->post('lokasi');
        $detail_lokasi = $this->input->post('detail_lokasi');       
        $nik = $this->input->post('nik'); 
        $nama_user = $this->input->post('nama_user');
        $tanggal_pindah = $this->input->post('tanggal_pindah');
        $pemindah = $this->input->post('pemindah');
        $keterangan = $this->input->post('keterangan');

        $cek_label = $this->m_lokasi->get_lokasi($lokasi)->row();
        $label = $cek_label->label;

        $cek_aset_terakhir = $this->m_aset->cek_aset_terakhir($id_jenis_barang,$lokasi);
        if(($cek_aset_terakhir->num_rows()) == '0'){
            $id_aset = 'HWP-'.$label.'-'.$label_jns_barang.'-'.'0001';
        }else{
            $oo = $cek_aset_terakhir->row();
            if(strlen(substr($label,4)) == 2 and strlen($label_jns_barang)==2){
                $kode_auto=substr($oo->id_aset,14,4);
            }elseif(strlen(substr($label,4)) == 2 and strlen($label_jns_barang)==3){
                $kode_auto=substr($oo->id_aset,15,4);
            }elseif(strlen(substr($label,4)) == 2 and strlen($label_jns_barang)==4){
                $kode_auto=substr($oo->id_aset,16,4);
            }elseif(strlen(substr($label,4)) == 2 and strlen($label_jns_barang)==5){
                $kode_auto=substr($oo->id_aset,17,4);
            }elseif(strlen(substr($label,4)) == 2 and strlen($label_jns_barang)==6){
                $kode_auto=substr($oo->id_aset,18,4);
            }

            elseif(strlen(substr($label,4)) == 3 and strlen($label_jns_barang)==2){
                $kode_auto=substr($oo->id_aset,15,4);
            }elseif(strlen(substr($label,4)) == 3 and strlen($label_jns_barang)==3){
                $kode_auto=substr($oo->id_aset,16,4);
            }elseif(strlen(substr($label,4)) == 3 and strlen($label_jns_barang)==4){
                $kode_auto=substr($oo->id_aset,17,4);
            }elseif(strlen(substr($label,4)) == 3 and strlen($label_jns_barang)==5){
                $kode_auto=substr($oo->id_aset,18,4);
            }elseif(strlen(substr($label,4)) == 3 and strlen($label_jns_barang)==6){
                $kode_auto=substr($oo->id_aset,19,4);
            }

            elseif(strlen(substr($label,4)) == 4 and strlen($label_jns_barang)==2){
                $kode_auto=substr($oo->id_aset,16,4);
            }elseif(strlen(substr($label,4)) == 4 and strlen($label_jns_barang)==3){
                $kode_auto=substr($oo->id_aset,17,4);
            }elseif(strlen(substr($label,4)) == 4 and strlen($label_jns_barang)==4){
                $kode_auto=substr($oo->id_aset,18,4);
            }elseif(strlen(substr($label,4)) == 4 and strlen($label_jns_barang)==5){
                $kode_auto=substr($oo->id_aset,19,4);
            }elseif(strlen(substr($label,4)) == 4 and strlen($label_jns_barang)==6){
                $kode_auto=substr($oo->id_aset,20,4);
            }

            elseif(strlen(substr($label,4)) == 5 and strlen($label_jns_barang)==2){
                $kode_auto=substr($oo->id_aset,17,4);
            }elseif(strlen(substr($label,4)) == 5 and strlen($label_jns_barang)==3){
                $kode_auto=substr($oo->id_aset,18,4);
            }elseif(strlen(substr($label,4)) == 5 and strlen($label_jns_barang)==4){
                $kode_auto=substr($oo->id_aset,19,4);
            }elseif(strlen(substr($label,4)) == 5 and strlen($label_jns_barang)==5){
                $kode_auto=substr($oo->id_aset,20,4);
            }elseif(strlen(substr($label,4)) == 5 and strlen($label_jns_barang)==6){
                $kode_auto=substr($oo->id_aset,21,4);
            }

            elseif(strlen(substr($label,4)) == 6 and strlen($label_jns_barang)==2){
                $kode_auto=substr($oo->id_aset,18,4);
            }elseif(strlen(substr($label,4)) == 6 and strlen($label_jns_barang)==3){
                $kode_auto=substr($oo->id_aset,19,4);
            }elseif(strlen(substr($label,4)) == 6 and strlen($label_jns_barang)==4){
                $kode_auto=substr($oo->id_aset,20,4);
            }elseif(strlen(substr($label,4)) == 6 and strlen($label_jns_barang)==5){
                $kode_auto=substr($oo->id_aset,21,4);
            }elseif(strlen(substr($label,4)) == 6 and strlen($label_jns_barang)==6){
                $kode_auto=substr($oo->id_aset,22,4);
            }

            $tambah1=$kode_auto+1;
            if($tambah1<10){
                $id_aset= 'HWP-'.$label.'-'.$label_jns_barang.'-'.'000'.$tambah1;
            }elseif($tambah1<100){
                $id_aset= 'HWP-'.$label.'-'.$label_jns_barang.'-'.'00'.$tambah1;
            }elseif($tambah1<1000){
                $id_aset= 'HWP-'.$label.'-'.$label_jns_barang.'-'.'0'.$tambah1;
            }
        }

        $cek_nama_lokasi = $this->m_lokasi->get_lokasi($lokasi)->row();

        $nama_lokasi = $cek_nama_lokasi->nama_lokasi;
        $get_row_karyawan = $this->m_aset->get_row_karyawan($nik)->row();
        $NAME = $get_row_karyawan->NAME;
        $updated_at = date('Y-m-d H:i:s');
        $id_user = $this->session->userdata('username_a');
        $surat_jalan = '';
        $vendor = '';

        $id_log = 'hwp'.uniqid();
        $status_keterangan = '1';
        if($tipe_user == 'nik'){
            $keterangan_log = 'Dipindah oleh '.$pemindah.', di '.$nama_lokasi.', detail lokasi '.$detail_lokasi.' dengan nama user '.$NAME.', keterangan '.$keterangan;
        }else{
            $keterangan_log = 'Dipindah oleh '.$pemindah.', di '.$nama_lokasi.', detail lokasi '.$detail_lokasi.' dengan nama user '.$nama_user.', keterangan '.$keterangan;
        }

        $update = $this->m_aset->update_aset_pindah($id_stok,$id_aset,$lokasi,$detail_lokasi,$nama_user,$nik,$updated_at,$id_user);
        if($update){
            $this->m_log->insert_log($id_log,$id_stok,$id_aset,$status_keterangan,$vendor,$tanggal_pindah,$surat_jalan,$keterangan_log,$updated_at,$id_user);
            $this->session->set_flashdata(array('status'=>'success','msg'=>'Transaksi aset berhasil disimpan'));
        }
        redirect('c_aset/pindah_lokasi');
    }

    function barang_rusak_it(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('aset/v_barang_rusak_it');
        $this->load->view('_template/footer');
    }

    function cek_status_bi($id_stok){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $data = $this->m_aset->cek_data_aset($id_stok);
        header('Content-Type: application/json');
        if($data->num_rows() > '0'){
            if(($data->row())->status_keterangan != '3'){
                echo json_encode(array('status'=>'ok', 'data'=>($data->row())));
            }else{
                echo json_encode(array('status'=>'error', 'msg'=>'Aset dalam status rusak di IT'));
            }
        }else{
            echo json_encode(array('status'=>'error', 'msg'=>'Aset tidak ditemukan'));
        }
    }

    function proses_barang_rusak_it(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $id_stok = $this->input->post('id_stok');
        $tanggal_kembali = $this->input->post('tanggal_kembali');
        $pengambil = $this->input->post('pengambil');
        $keterangan = $this->input->post('keterangan');
        $id_aset = '';
        $lokasi = '';
        $detail_lokasi = '';
        $nama_user = '';
        $surat_jalan = '';
        $vendor = '';

        $id_log = 'hwp'.uniqid();
        $status_keterangan = '3';
        $keterangan_log = 'Rusak di IT setelah '.$keterangan.', pengambil '.$pengambil;
        $updated_at = date('Y-m-d H:i:s');
        $id_user = $this->session->userdata('username_a');

        $update = $this->m_aset->update_aset($id_stok,$id_aset,$lokasi,$detail_lokasi,$nama_user,$status_keterangan,$updated_at,$id_user);
        if($update){
            $this->m_log->insert_log($id_log,$id_stok,$id_aset,$status_keterangan,$vendor,$tanggal_kembali,$surat_jalan,$keterangan_log,$updated_at,$id_user);
            $this->m_aset->delete_tb_vendor($id_stok);
            $this->session->set_flashdata(array('status'=>'success','msg'=>'Transaksi aset berhasil disimpan'));
        }
        redirect('c_aset/barang_rusak_it');
    }

    function barang_rusak_vendor(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $data = $this->m_supplier->get_data_supplier()->result();
        $surat_jalan = $this->m_surat_jalan->get_sj_close()->result();
        $this->load->view('_template/header');
        $this->load->view('aset/v_barang_rusak_vendor',array('data'=>$data,'surat_jalan'=>$surat_jalan));
        $this->load->view('_template/footer');
    }

    function cek_status_bv($id_stok){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $data = $this->m_aset->cek_data_aset($id_stok);
        header('Content-Type: application/json');
        if($data->num_rows() > '0'){
            if(($data->row())->status_keterangan == '0' || ($data->row())->status_keterangan == '3'){
                echo json_encode(array('status'=>'ok', 'data'=>($data->row())));
            }else{
                echo json_encode(array('status'=>'error', 'msg'=>'Aset dalam status terpasang atau sudah di vendor'));
            }
        }else{
            echo json_encode(array('status'=>'error', 'msg'=>'Aset tidak ditemukan'));
        }
    }

    function proses_barang_rusak_vendor(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $id_stok = $this->input->post('id_stok');
        $tanggal_kirim = $this->input->post('tanggal_kirim');
        $vendor = $this->input->post('vendor');
        $surat_jalan = $this->input->post('surat_jalan');
        $keterangan = $this->input->post('keterangan');
        $id_aset = '';
        $lokasi = '';
        $detail_lokasi = '';
        $nama_user = '';

        $id_log = 'hwp'.uniqid();
        $status_keterangan = '4';
        $keterangan_log = 'Rusak dikirim ke vendor setelah '.$keterangan;
        $updated_at = date('Y-m-d H:i:s');
        $id_user = $this->session->userdata('username_a');

        $update = $this->m_aset->update_aset($id_stok,$id_aset,$lokasi,$detail_lokasi,$nama_user,$status_keterangan,$updated_at,$id_user);
        $this->m_aset->insert_tb_vendor($id_stok,$vendor);
        if($update){
            $this->m_log->insert_log($id_log,$id_stok,$id_aset,$status_keterangan,$vendor,$tanggal_kirim,$surat_jalan,$keterangan_log,$updated_at,$id_user);
            $this->session->set_flashdata(array('status'=>'success','msg'=>'Transaksi aset berhasil disimpan'));
        }
        redirect('c_aset/barang_rusak_vendor');
    }

    function stok($kode,$status_keterangan){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $aset = $this->m_aset->get_total_aset()->result();

        $data = $this->m_jenis_barang->get_nama($kode)->row();
        $nama_jenis_barang = $data->nama_aset;
        
        $this->load->view('_template/header');
        $this->load->view('aset/v_stok',array('aset'=>$aset,'nama_jenis_barang'=>$nama_jenis_barang, 'kode'=>$kode, 'status_keterangan'=>$status_keterangan));
        $this->load->view('_template/footer');
    }

    function get_aset_selain_terpasang($kode,$status_keterangan){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $id_jenis_barang = $this->m_jenis_barang->get_jenis_barang($kode)->result();
        foreach($id_jenis_barang as $id){
            $jenis_barang[] = $id->id_jenis_barang;
        }
        $sambung = '';

        for($i=0; $i<count($id_jenis_barang); $i++){
            if($i<count($id_jenis_barang)-1){
                $id_jns_brg = "'".$jenis_barang[$i]."',"; 
            }else{
                $id_jns_brg = "'".$jenis_barang[$i]."'";
            }
            $sambung .= $id_jns_brg;
        }

        $where1 = "j.id_jenis_barang IN (".$sambung.")";
        $where2 = "s.status_keterangan = ".$status_keterangan." AND s.jenis_aset NOT IN ('7','8')";

        $list = $this->m_aset->get_datatables($where1,$where2);
        $data = array();
        $no = @$_POST['start'];        
            foreach($list as $field){
                $no++;
                $row = array();
                $row[] = $no;
                $row[] = $field->id_stok;
                $row[] = $field->nama_model;
                if($field->jenis_aset == '0'){
                    $row[] = '<span class="badge badge-pill badge-primary">Po</span>';
                }elseif($field->jenis_aset == '1'){
                    $row[] = '<span class="badge badge-pill badge-success">Rental</span>';
                }else{
                    $row[] = '<span class="badge badge-pill badge-danger">Projek</span>';
                }
                $row[] = $field->sn;
                $row[] = $field->alokasi;
                $row[] = $field->remark;
                if($field->qr == ''){
                    $row[] = '';
                }else{
                    $row[] = '<img style="width: 40px;" src="'.base_url().'assets/qr_barang/'.$field->id_stok.'.png">';
                }
                if($this->session->userdata('level_a') == '4'){
                    $row[] = '<a class="btn mb-1 btn-secondary btn-sm" href="'.base_url().'index.php/c_log/log/'.$field->id_stok.'/'.$field->jenis_aset.'" title="History"><i class="fe fe-clock fe-12" aria-hidden="true"></i></a>';
                }else{
                    if($status_keterangan == '4'){
                        if($field->qr != ''){
                            $row[] = '<a class="btn mb-1 btn-secondary btn-sm" href="'.base_url().'index.php/c_log/log/'.$field->id_stok.'/'.$field->jenis_aset.'" title="History"><i class="fe fe-clock fe-12" aria-hidden="true"></i></a>';
                        }else{
                            $row[] = '<a class="btn mb-1 btn-info btn-sm" href="javascript:void(0)" title="Generate" onclick="generate_barang('."'".$field->id_stok."'".')"><i class="fe fe-grid fe-12" aria-hidden="true"></i></a>
                        <a class="btn mb-1 btn-secondary btn-sm" href="'.base_url().'index.php/c_log/log/'.$field->id_stok.'/'.$field->jenis_aset.'" title="History"><i class="fe fe-clock fe-12" aria-hidden="true"></i></a>';
                        }
                    }else{ 
                        if($field->qr != ''){
                            $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="edit" onclick="edit_barang('."'".$field->id_stok."'".')"><i class="fe fe-edit fe-12" aria-hidden="true"></i></a>
                        <a class="btn mb-1 btn-secondary btn-sm" href="'.base_url().'index.php/c_log/log/'.$field->id_stok.'/'.$field->jenis_aset.'" title="History"><i class="fe fe-clock fe-12" aria-hidden="true"></i></a>';
                        }else{
                            $row[] = '<a class="btn mb-1 btn-info btn-sm" href="javascript:void(0)" title="Generate" onclick="generate_barang('."'".$field->id_stok."'".')"><i class="fe fe-grid fe-12" aria-hidden="true"></i></a>
                        <a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="edit" onclick="edit_barang('."'".$field->id_stok."'".')"><i class="fe fe-edit fe-12" aria-hidden="true"></i></a>
                        <a class="btn mb-1 btn-secondary btn-sm" href="'.base_url().'index.php/c_log/log/'.$field->id_stok.'/'.$field->jenis_aset.'" title="History"><i class="fe fe-clock fe-12" aria-hidden="true"></i></a>';
                        }
                    }
                }
                $data[] = $row;
            }        
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $this->m_aset->count_all($where1,$where2),
            "recordsFiltered" => $this->m_aset->count_filtered($where1,$where2),
            "data" => $data,
        );
        //output dalam format JSON
        echo json_encode($output);
    }

    function edit_barang_non_terpasang_proses(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }        

        $id_stok = $this->input->post('id_stok');
        $sn = $this->input->post('sn');
        $remark = $this->input->post('remark');
        $status_keterangan = $this->input->post('status_keterangan');
        $id_aset = '';
        $vendor = '';
        $tgl = date('Y-m-d');
        $surat_jalan = '';
        $updated_at = date('Y-m-d H:i:s');
        $id_user = $this->session->userdata('username_a');

        $id_log = 'hwp'.uniqid();
        $keterangan = 'User '.$id_user.' melakukan update data';

        $update = $this->m_aset->update_aset_non_terpasang($id_stok,$sn,$remark,$updated_at,$id_user);
        if($update){            
            $this->m_log->insert_log($id_log,$id_stok,$id_aset,$status_keterangan,$vendor,$tgl,$surat_jalan,$keterangan,$updated_at,$id_user);
        }
        echo json_encode(array("status"=>TRUE));
    }

    function rusak_it($kode,$status_keterangan){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $aset = $this->m_aset->get_total_aset()->result();

        $data = $this->m_jenis_barang->get_nama($kode)->row();
        $nama_jenis_barang = $data->nama_aset;
        
        $this->load->view('_template/header');
        $this->load->view('aset/v_rusak_it',array('aset'=>$aset,'nama_jenis_barang'=>$nama_jenis_barang, 'kode'=>$kode, 'status_keterangan'=>$status_keterangan));
        $this->load->view('_template/footer');
    }

    function rusak_vendor($kode,$status_keterangan){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $aset = $this->m_aset->get_total_aset()->result();

        $data = $this->m_jenis_barang->get_nama($kode)->row();
        $nama_jenis_barang = $data->nama_aset;
        
        $this->load->view('_template/header');
        $this->load->view('aset/v_rusak_vendor',array('aset'=>$aset,'nama_jenis_barang'=>$nama_jenis_barang, 'kode'=>$kode, 'status_keterangan'=>$status_keterangan));
        $this->load->view('_template/footer');
    }

    function transfer_hwi_jepara(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('aset/v_transfer_hwi_jepara');
        $this->load->view('_template/footer');
    }

    function cek_status_tf($id_stok){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $data = $this->m_aset->cek_aset_tf($id_stok);
        header('Content-Type: application/json');
        if($data->num_rows() > '0'){
            echo json_encode(array('status'=>'ok', 'data'=>($data->row())));           
        }else{
            echo json_encode(array('status'=>'error', 'msg'=>'Aset tidak ditemukan'));
        }
    }

    function proses_transfer_hwi_jepara(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $id_stok = $this->input->post('id_stok');
        $id_jenis_barang = $this->input->post('id_jenis_barang');
        $label_jns_barang = $this->input->post('label_jns_barang');
        $id_lokasi = $this->input->post('id_lokasi');
        $label = $this->input->post('label_lokasi');
        $status_keterangan = $this->input->post('status_keterangan');
        $surat_jalan = $this->input->post('no_srt_jln');
        $tanggal_pindah = $this->input->post('tanggal_pindah');
        $pemindah = $this->input->post('pemindah');
        $plan = '1';

        if($status_keterangan != '1'){
            $id_aset = '';
        }else{
            $cek_data_jepara = $this->m_stok_barang->cek_data_jepara($id_jenis_barang,$id_lokasi);
            if(($cek_data_jepara->num_rows()) == 0){
                $id_aset = 'HWI-'.$label.'-'.$label_jns_barang.'-'.'0001';
            }else{
                $oo = $cek_data_jepara->row();
                if(strlen(substr($label,4)) == 2 and strlen($label_jns_barang)==2){
                    $kode_auto=substr($oo->id_aset,14,4);
                }elseif(strlen(substr($label,4)) == 2 and strlen($label_jns_barang)==3){
                    $kode_auto=substr($oo->id_aset,15,4);
                }elseif(strlen(substr($label,4)) == 2 and strlen($label_jns_barang)==4){
                    $kode_auto=substr($oo->id_aset,16,4);
                }elseif(strlen(substr($label,4)) == 2 and strlen($label_jns_barang)==5){
                    $kode_auto=substr($oo->id_aset,17,4);
                }elseif(strlen(substr($label,4)) == 2 and strlen($label_jns_barang)==6){
                    $kode_auto=substr($oo->id_aset,18,4);
                }

                elseif(strlen(substr($label,4)) == 3 and strlen($label_jns_barang)==2){
                    $kode_auto=substr($oo->id_aset,15,4);
                }elseif(strlen(substr($label,4)) == 3 and strlen($label_jns_barang)==3){
                    $kode_auto=substr($oo->id_aset,16,4);
                }elseif(strlen(substr($label,4)) == 3 and strlen($label_jns_barang)==4){
                    $kode_auto=substr($oo->id_aset,17,4);
                }elseif(strlen(substr($label,4)) == 3 and strlen($label_jns_barang)==5){
                    $kode_auto=substr($oo->id_aset,18,4);
                }elseif(strlen(substr($label,4)) == 3 and strlen($label_jns_barang)==6){
                    $kode_auto=substr($oo->id_aset,19,4);
                }

                elseif(strlen(substr($label,4)) == 4 and strlen($label_jns_barang)==2){
                    $kode_auto=substr($oo->id_aset,16,4);
                }elseif(strlen(substr($label,4)) == 4 and strlen($label_jns_barang)==3){
                    $kode_auto=substr($oo->id_aset,17,4);
                }elseif(strlen(substr($label,4)) == 4 and strlen($label_jns_barang)==4){
                    $kode_auto=substr($oo->id_aset,18,4);
                }elseif(strlen(substr($label,4)) == 4 and strlen($label_jns_barang)==5){
                    $kode_auto=substr($oo->id_aset,19,4);
                }elseif(strlen(substr($label,4)) == 4 and strlen($label_jns_barang)==6){
                    $kode_auto=substr($oo->id_aset,20,4);
                }

                elseif(strlen(substr($label,4)) == 5 and strlen($label_jns_barang)==2){
                    $kode_auto=substr($oo->id_aset,17,4);
                }elseif(strlen(substr($label,4)) == 5 and strlen($label_jns_barang)==3){
                    $kode_auto=substr($oo->id_aset,18,4);
                }elseif(strlen(substr($label,4)) == 5 and strlen($label_jns_barang)==4){
                    $kode_auto=substr($oo->id_aset,19,4);
                }elseif(strlen(substr($label,4)) == 5 and strlen($label_jns_barang)==5){
                    $kode_auto=substr($oo->id_aset,20,4);
                }elseif(strlen(substr($label,4)) == 5 and strlen($label_jns_barang)==6){
                    $kode_auto=substr($oo->id_aset,21,4);
                }

                elseif(strlen(substr($label,4)) == 6 and strlen($label_jns_barang)==2){
                    $kode_auto=substr($oo->id_aset,18,4);
                }elseif(strlen(substr($label,4)) == 6 and strlen($label_jns_barang)==3){
                    $kode_auto=substr($oo->id_aset,19,4);
                }elseif(strlen(substr($label,4)) == 6 and strlen($label_jns_barang)==4){
                    $kode_auto=substr($oo->id_aset,20,4);
                }elseif(strlen(substr($label,4)) == 6 and strlen($label_jns_barang)==5){
                    $kode_auto=substr($oo->id_aset,21,4);
                }elseif(strlen(substr($label,4)) == 6 and strlen($label_jns_barang)==6){
                    $kode_auto=substr($oo->id_aset,22,4);
                }

                $tambah1=$kode_auto+1;
                if($tambah1<10){
                    $id_aset= 'HWI-'.$label.'-'.$label_jns_barang.'-'.'000'.$tambah1;
                }elseif($tambah1<100){
                    $id_aset= 'HWI-'.$label.'-'.$label_jns_barang.'-'.'00'.$tambah1;
                }elseif($tambah1<1000){
                    $id_aset= 'HWI-'.$label.'-'.$label_jns_barang.'-'.'0'.$tambah1;
                }
            }
        }

        $id_log = 'hwp'.uniqid();
        $vendor = '';
        //$tgl = date('Y-m-d');
        $keterangan = 'Device di transfer ke HWI Jepara oleh '.$pemindah;
        $updated_at = date('Y-m-d H:i:s');
        $id_user = $this->session->userdata('username_a');

        $transfer = $this->m_aset->transfer_hwi_jepara($id_stok);

        if($transfer){
            $this->m_aset->update_tambahan($id_stok,$id_aset,$plan);
            $this->m_log->insert_log($id_log,$id_stok,$id_aset,$status_keterangan,$vendor,$tanggal_pindah,$surat_jalan,$keterangan,$updated_at,$id_user);
            $this->m_aset->hapus_barang_pati($id_stok);
            $this->session->set_flashdata(array('status'=>'success','msg'=>'Transaksi aset berhasil ditransfer'));
        }
        redirect('c_aset/transfer_hwi_jepara');
    }

    function konfirmasi_rental(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('aset/v_konfirmasi_rental');
        $this->load->view('_template/footer');
    }

    function get_data_konfirm_rental(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $list = $this->m_stok_barang->get_datatables_rental();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" name="select_all[]" value="'.$field->id_temp.';'.$field->id_transaksi.';'.$field->id_barang.';'.$field->id_supplier.';'.$field->kurs.';'.$field->harga.';'.$field->ppn.';'.$field->pph.';'.$field->jenis_aset.'">';
            $row[] = $no;
            $row[] = $field->id_po;
            $row[] = $field->nama_jenis_barang;
            $row[] = $field->nama_model;
            $row[] = $field->estimasi_dtg;
            $row[] = $field->kurs;
            $row[] = number_format($field->harga);
            $row[] = $field->ppn;
            $row[] = $field->pph;
            $row[] = $field->created_at;
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_stok_barang->count_all_rental(),
            "recordsFiltered" => $this->m_stok_barang->count_filtered_rental(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function proses_terima_rental(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $select_all = $this->input->post('select_all');
        $status_keterangan = '0';
        $plan = '2';
        $tgl_dtg = $this->input->post('tgl_dtg');
        $remark = $this->input->post('keterangan');
        $updated_at = date('Y-m-d H:i:s');
        $id_user = $this->session->userdata('username_a');

        $id_aset = '';
        $alokasi = '';
        $surat_jalan = $this->input->post('surat_jalan');
        $keterangan_log = "Barang masuk dari sewa supplier";        

        if (is_array($select_all) || is_object($select_all)){
            foreach ($select_all as $key){
                $pecah = explode(";", $key);
                for($i=0; $i<count(array($key)); $i++){
                    $id_temp        = $pecah[$i];
                    $id_transaksi   = $pecah[$i+1];
                    $id_barang      = $pecah[$i+2];
                    $id_supplier    = $pecah[$i+3];
                    $kurs           = $pecah[$i+4];
                    $harga          = $pecah[$i+5];
                    $harga_ppn      = $pecah[$i+6];
                    $harga_pph      = $pecah[$i+7]; 
                    $jenis_aset     = $pecah[$i+8];

                    $insert = $this->m_stok_barang->insert_stok($id_temp,$id_transaksi,$id_barang,$id_supplier,$kurs,$harga,$harga_ppn,$harga_pph,$status_keterangan,$remark,$jenis_aset,$tgl_dtg,$alokasi,$updated_at,$id_user,$plan);
                    if($insert){
                        $id_log = 'hwp'.uniqid();                   

                        $this->m_log->insert_log($id_log,$id_temp,$id_aset,$status_keterangan,$id_supplier,$tgl_dtg,$surat_jalan,$keterangan_log,$updated_at,$id_user);
                        $this->m_stok_barang->hapus_konfirm($id_temp,$jenis_aset);
                        $status = "success";
                        $msg = "Barang berhasil diterima";
                    }else{
                        $status = "danger";
                        $msg = "Barang gagal diterima";
                    }
                }
            }
        }
        $this->session->set_flashdata(array('status'=>$status,'msg'=>$msg));
        redirect('c_aset/konfirmasi_rental');
    }

    function konfirmasi_po(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_stok_barang->get_konfirm_po()->result();
        $this->load->view('_template/header');
        $this->load->view('aset/v_konfirmasi_po', array('data'=>$data));
        $this->load->view('_template/footer');
    }

    function konfirmasi_po_detail($id_po){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('aset/v_konfirmasi_po_detail', array('id_po'=>$id_po));
        $this->load->view('_template/footer');
    }

    function get_data_konfirm_po($id_po){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $list = $this->m_stok_barang->get_datatables_po($id_po);
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" name="select_all[]" value="'.$field->id_temp.';'.$field->id_transaksi.';'.$field->id_barang.';'.$field->epte_code.';'.$field->FA_code.';'.$field->id_supplier.';'.$field->kurs.';'.$field->harga.';'.$field->ppn.';'.$field->pph.';'.$field->alokasi.';'.$field->jenis_aset.'">';
            $row[] = $no;
            $row[] = $field->no_po;
            $row[] = $field->tgl_po;
            $row[] = $field->nama_jenis_barang;
            $row[] = $field->nama_model;
            $row[] = $field->epte_code;
            $row[] = $field->FA_code;
            $row[] = $field->kurs;
            $row[] = number_format($field->harga);
            $row[] = number_format($field->ppn);
            // $row[] = $field->pph;
            $row[] = $field->alokasi;
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_stok_barang->count_all_po($id_po),
            "recordsFiltered" => $this->m_stok_barang->count_filtered_po($id_po),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function proses_terima_po(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $select_all = $this->input->post('select_all');
        $status_keterangan = '0';
        $plan = '2';
        $tgl_dtg = $this->input->post('tgl_dtg');
        $remark = $this->input->post('keterangan');
        $updated_at = date('Y-m-d H:i:s');
        $id_user = $this->session->userdata('username_a');

        $id_aset = '';
        $surat_jalan = $this->input->post('surat_jalan');
        $keterangan_log = "Barang masuk dari pembelian supplier";
        $id_po = $this->input->post('id_po');

        if (is_array($select_all) || is_object($select_all)){
            foreach ($select_all as $key){
                $pecah = explode(";", $key);
                for($i=0; $i<count(array($key)); $i++){
                    $id_temp        = $pecah[$i];
                    $id_transaksi   = $pecah[$i+1];
                    $id_barang      = $pecah[$i+2];
                    $kode_epte      = $pecah[$i+3];
                    $kode_fa        = $pecah[$i+4];
                    $id_supplier    = $pecah[$i+5];
                    $kurs           = $pecah[$i+6];
                    $harga          = $pecah[$i+7];
                    $harga_ppn      = $pecah[$i+8];
                    $harga_pph      = $pecah[$i+9];
                    $alokasi        = $pecah[$i+10]; 
                    $jenis_aset     = $pecah[$i+11];

                    $insert = $this->m_stok_barang->insert_stok($id_temp,$id_transaksi,$id_barang,$kode_epte,$kode_fa,$id_supplier,$kurs,$harga,$harga_ppn,$harga_pph,$status_keterangan,$remark,$jenis_aset,$tgl_dtg,$alokasi,$updated_at,$id_user,$plan);
                    if($insert){
                        $id_log = 'hwp'.uniqid();                   

                        $this->m_log->insert_log($id_log,$id_temp,$id_aset,$status_keterangan,$id_supplier,$tgl_dtg,$surat_jalan,$keterangan_log,$updated_at,$id_user);
                        $this->m_stok_barang->hapus_konfirm($id_temp,$jenis_aset);
                        $status = "success";
                        $msg = "Barang berhasil diterima";
                    }else{
                        $status = "danger";
                        $msg = "Barang gagal diterima";
                    }
                }
            }
        }
        $this->session->set_flashdata(array('status'=>$status,'msg'=>$msg));
        redirect('c_aset/konfirmasi_po_detail/'.$id_po);
    }

    function input_barang_proyek(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $proyek = $this->m_proyek->get_proyek()->result();
        $jenis_barang = $this->m_jenis_barang->get_jenis_barang_proyek()->result();
        $this->load->view('_template/header');
        $this->load->view('proyek/v_input_barang_proyek', array('proyek'=>$proyek,'jenis_barang'=>$jenis_barang));
        $this->load->view('_template/footer');
    }

    function cek_proyek($id_proyek){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_proyek->get_proyek2($id_proyek);
        header('Content-Type: application/json');
        if($data->num_rows() > '0'){
            echo json_encode(array('status'=>'ok', 'data'=>($data->row())));
        }else{
            echo json_encode(array('status'=>'error', 'msg'=>'Projek tidak ditemukan'));
        }
    }

    function cari_barang(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id = $this->input->post('id');
        echo $this->m_barang->cari_barang($id);
    }

    function tambah_barang_proyek(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_barang = $this->input->post('id_barang');
        $kode_epte = $this->input->post('epte_code');
        $kode_fa = $this->input->post('fa_code');
        $id_supplier = $this->input->post('id_supplier');
        $jumlah = $this->input->post('jumlah');
        $alokasi = $this->input->post('alokasi');
        $keterangan = $this->input->post('keterangan');
        $ip = $this->input->post('ip');
        $updated_at = date('Y-m-d H:i:s');

        $cek_data = $this->m_tb_bantu->cek_data_proyek($id_barang,$kode_epte,$kode_fa,$alokasi,$ip);
        header('Content-Type: application/json');
        if($cek_data->num_rows()>0){
            echo json_encode(array('status'=>'error','msg'=>'Data sudah ditambahkan'));
        }else{
            $this->m_tb_bantu->tambah_barang_proyek($id_barang,$kode_epte,$kode_fa,$id_supplier,$jumlah,$alokasi,$keterangan,$ip,$updated_at);
            echo json_encode(array('status'=>'ok'));
        }            
    }

    function datatabel_proyek(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $ip = $_SERVER['REMOTE_ADDR'];
        $data = $this->m_tb_bantu->get_datatabel_proyek($ip)->result();
        echo json_encode($data);
    }

    function hapus_barang_proyek(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $ip = $_SERVER['REMOTE_ADDR'];
        $id_barang = $this->input->post('id_barang');
        $kode_epte = $this->input->post('kode_epte');
        $kode_fa = $this->input->post('kode_fa');
        $alokasi = $this->input->post('alokasi');
        $data = $this->m_tb_bantu->hapus_barang_proyek($id_barang,$kode_epte,$kode_fa,$alokasi,$ip);
        echo json_encode($data);
    }

    function input_barang_rental(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $supplier = $this->m_supplier->get_data_supplier()->result();
        $jenis_barang = $this->m_jenis_barang->get_jenis_barang_rental()->result();
        $this->load->view('_template/header');
        $this->load->view('pembelian/v_input_barang_rental', array('supplier'=>$supplier,'jenis_barang'=>$jenis_barang));
        $this->load->view('_template/footer');
    }

    function tambah_barang_rental(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $no_rental = $this->input->post('no_rental');
        $id_barang = $this->input->post('id_barang');
        $id_supplier = $this->input->post('id_supplier');
        $jumlah = $this->input->post('jumlah');
        $kurs = $this->input->post('kurs');
        $ppn = $this->input->post('ppn');
        $pph = $this->input->post('pph');
        $harga = $this->input->post('harga');
        $harga_total = $jumlah * $harga;
        $ip = $this->input->post('ip');
        $updated_at = date('Y-m-d H:i:s');

       
        $cek_data = $this->m_tb_bantu->cek_data_rental($no_rental,$id_barang,$ip);
        header('Content-Type: application/json');
        if($cek_data->num_rows()>0){
            echo json_encode(array('status'=>'error','msg'=>'Data sudah ditambahkan'));
        }else{
            $this->m_tb_bantu->tambah_barang_rental($no_rental,$id_barang,$id_supplier,$jumlah,$kurs,$ppn,$pph,$harga_total,$ip,$updated_at);
            echo json_encode(array('status'=>'ok'));
        }            
    }

    function datatabel_rental(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $ip = $_SERVER['REMOTE_ADDR'];
        $data = $this->m_tb_bantu->get_datatabel_rental($ip)->result();
        echo json_encode($data);
    }

    function hapus_barang_rental(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $ip = $_SERVER['REMOTE_ADDR'];
        $no_rental = $this->input->post('no_rental');
        $id_barang = $this->input->post('id_barang');
        $data = $this->m_tb_bantu->hapus_barang_rental($no_rental,$id_barang,$ip);
        echo json_encode($data);
    }

    function simpan_transaksi_rental(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $cek_data = $this->m_tb_bantu->get_data_terakhir()->num_rows();        
        if($cek_data = 0 ){
            $id = "TRSPMB0000000001";
        }else{
            $cek_pati = $this->m_tb_bantu->get_data_terakhir()->row();
            $cek_jepara = $this->m_tb_bantu->get_data_terakhir_jepara()->row();
            $kode_pati = substr($cek_pati->id_transaksi,6,10);
            $kode_jepara = substr($cek_jepara->id_transaksi,6,10);
            if($kode_pati<$kode_jepara){
                $kode = $kode_jepara;
            }else{
                $kode = $kode_pati;
            }
            $tambah = $kode+1;
            if($tambah<10){
                $id = "TRSPMB000000000".$tambah;
            }elseif($tambah<100){
                $id = "TRSPMB00000000".$tambah;
            }elseif($tambah<1000){
                $id = "TRSPMB0000000".$tambah;
            }elseif($tambah<10000){
                $id = "TRSPMB000000".$tambah;
            }elseif($tambah<100000){
                $id = "TRSPMB00000".$tambah;
            }elseif($tambah<1000000){
                $id = "TRSPMB0000".$tambah;
            }elseif($tambah<10000000){
                $id = "TRSPMB000".$tambah;
            }elseif($tambah<100000000){
                $id = "TRSPMB00".$tambah;
            }elseif($tambah<1000000000){
                $id = "TRSPMB0".$tambah;
            }else{
                $id = "TRSPMB".$tambah;
            }

            $id_trs = $id;
            $tanggal_rental = $this->input->post('tanggal_rental');
            $no_rental = $this->input->post('no_rental');
            $no_surat_jalan = $this->input->post('no_surat_jalan');
            $ip = $_SERVER['REMOTE_ADDR'];

            $data = $this->m_tb_bantu->ambil_total_harga($ip,$no_rental)->row();
            header('Content-Type: application/json');

            $kurs = $data->kurs;

            if($data->total_harga == null){
                $total_harga = 0;
            }else{
                $total_harga = $data->total_harga;
            }

            if($data->total_harga_ppn == null){
                $total_harga_ppn = 0;
            }else{
                $total_harga_ppn = $data->total_harga_ppn;
            }

            if($data->total_harga_pph == null){
                $total_harga_pph = 0;
            }else{
                $total_harga_pph = $data->total_harga_pph;
            }

            // print_r($id);
            $this->m_tb_bantu->insert_transaksi_pembelian($id_trs,$no_rental,$tanggal_rental,$no_surat_jalan,$kurs,$total_harga,$total_harga_ppn,$total_harga_pph);
            echo json_encode(array('status'=>'ok','id_trs'=>$id_trs));
        }
    }

    function update_tb_bantu_rental($id_trs,$no_rental,$ip){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $update = $this->m_tb_bantu->update_tb_bantu_rental($id_trs,$no_rental,$ip);
        header('Content-Type: application/json');
        echo json_encode(array('status'=>'ok'));
    }

    function proses_simpan_rental($no_rental,$jenis_aset,$tanggal_po,$ip){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }
        
        
        $data = $this->m_tb_bantu->get_tb_rental($ip,$no_rental)->result();
        header('Content-Type: application/json');
        foreach ($data as $dt){
            for($i=1;$i<=$dt->jumlah;$i++){
                $id_temp = 'hwp'.uniqid();
                $id_transaksi = $dt->id_transaksi;
                $id_barang = $dt->id_barang;
                $id_supplier = $dt->id_supplier;
                $id_po = $no_rental;
                $kurs = $dt->kurs;
                $harga = $dt->harga;
                $jumlah = $dt->jumlah;

                $harga_satuan = $harga/$jumlah;

                if($dt->ppn == 'yes' && $dt->pph == 'yes'){
                    $ppn = ($harga_satuan*0.11)+$harga_satuan;
                    $pph = ($harga_satuan*0.02)+$harga_satuan;
                }elseif($dt->ppn == 'yes' && $dt->pph == 'no'){
                    $ppn = ($harga_satuan*0.11)+$harga_satuan;
                    $pph = $harga_satuan;
                }elseif($dt->ppn == 'no' && $dt->pph == 'yes'){
                    $ppn = $harga_satuan;
                    $pph = ($harga_satuan*0.02)+$harga_satuan;
                }else{
                    $ppn = $harga_satuan;
                    $pph = $harga_satuan;
                }  
                
                $estimasi_dtg = $tanggal_po;
                $updated_at = date('Y-m-d H:i:s');

                $this->m_tb_bantu->insert_detail_po($id_temp,$id_transaksi,$id_po,$id_barang,$id_supplier,$kurs,$ppn,$pph,$harga_satuan,$estimasi_dtg,$jenis_aset,$updated_at);
            }
        }
    }

    function hapus_tb_bantu_rental($id_trs,$no_rental,$ip){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }
        
        $insert = $this->m_tb_bantu->copy_isi_rental($id_trs,$no_rental,$ip);
        header('Content-Type: application/json');
        if($insert){
            $this->m_tb_bantu->delete_transaksi_rental($id_trs,$no_rental,$ip);
        }
        echo json_encode(array('status'=>'ok'));
    }

    function input_barang_po(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $po = $this->m_po->get_po()->result();
        $jenis_barang = $this->m_jenis_barang->get_jenis_barang_po()->result();
        $this->load->view('_template/header');
        $this->load->view('pembelian/v_input_barang_po', array('po'=>$po,'jenis_barang'=>$jenis_barang));
        $this->load->view('_template/footer');
    }

    function tambah_barang_po_aset(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_po = $this->input->post('id_po');
        $tanggal_po = $this->input->post('tanggal_po');
        $id_barang = $this->input->post('id_barang');
        $epte_code = $this->input->post('epte_code');
        $fa_code = $this->input->post('fa_code');
        $id_supplier = $this->input->post('id_supplier');
        $jumlah = $this->input->post('jumlah');
        $kurs = $this->input->post('kurs');
        $harga = $this->input->post("harga");
        $harga_total = $jumlah * $harga;
        $estimasi_dtg = $this->input->post('estimasi_dtg');
        $biaya_kirim = $this->input->post('biaya_kirim');
        $ppn = $this->input->post('ppn');
        $pph = $this->input->post('pph');
        $alokasi = $this->input->post('alokasi');
        $ip = $this->input->post('ip');
        $updated_at = date('Y-m-d H:i:s');
        
        $cek_po_aset = $this->m_tb_bantu->cek_po_aset($id_po,$id_barang,$epte_code,$fa_code,$alokasi,$ip);        
        header('Content-Type: application/json');
        if($cek_po_aset->num_rows()>0){
            echo json_encode(array('status'=>'error','msg'=>'Data Sudah Ditambahkan'));
        }else{
            $this->m_tb_bantu->tambah_barang_po_aset($id_po,$tanggal_po,$id_barang,$epte_code,$fa_code,$id_supplier,$jumlah,$kurs,$harga_total,$estimasi_dtg,$biaya_kirim,$ppn,$pph,$alokasi,$ip,$updated_at);
            echo json_encode(array('status'=>'ok'));
        }
    }

    function datatabel_po_aset(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $ip = $_SERVER['REMOTE_ADDR'];
        $data = $this->m_tb_bantu->get_datatabel_po_aset($ip)->result();
        echo json_encode($data);
    }

    function hapus_barang_po_aset(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_po = $this->input->post('id_po');
        $id_barang = $this->input->post('id_barang');
        $kode_epte = $this->input->post('epte_code');
        $kode_fa = $this->input->post('fa_code');
        $alokasi = $this->input->post('alokasi');
        $ip = $this->input->post('ip');

        $data = $this->m_tb_bantu->hapus_barang_po_aset($id_po,$id_barang,$kode_epte,$kode_fa,$alokasi,$ip);
        echo json_encode($data);
    }

    function simpan_transaksi_po_aset(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $cek_data = $this->m_tb_bantu->get_data_terakhir()->num_rows();        
        if($cek_data = 0 ){
            $id = "TRSPMB0000000001";
        }else{
            $cek_pati = $this->m_tb_bantu->get_data_terakhir()->row();
            $cek_jepara = $this->m_tb_bantu->get_data_terakhir_jepara()->row();
            $kode_pati = substr($cek_pati->id_transaksi,6,10);
            $kode_jepara = substr($cek_jepara->id_transaksi,6,10);
            if($kode_pati<$kode_jepara){
                $kode = $kode_jepara;
            }else{
                $kode = $kode_pati;
            }
            $tambah = $kode+1;
            if($tambah<10){
                $id = "TRSPMB000000000".$tambah;
            }elseif($tambah<100){
                $id = "TRSPMB00000000".$tambah;
            }elseif($tambah<1000){
                $id = "TRSPMB0000000".$tambah;
            }elseif($tambah<10000){
                $id = "TRSPMB000000".$tambah;
            }elseif($tambah<100000){
                $id = "TRSPMB00000".$tambah;
            }elseif($tambah<1000000){
                $id = "TRSPMB0000".$tambah;
            }elseif($tambah<10000000){
                $id = "TRSPMB000".$tambah;
            }elseif($tambah<100000000){
                $id = "TRSPMB00".$tambah;
            }elseif($tambah<1000000000){
                $id = "TRSPMB0".$tambah;
            }else{
                $id = "TRSPMB".$tambah;
            }

            $id_trs = $id;
            $id_po = $this->input->post('id_po_2');
            $tanggal_po = $this->input->post('tanggal_po_2');
            $estimasi_dtg = $this->input->post('estimasi_dtg_2');
            $ip = $this->input->post('ip');

            $data = $this->m_tb_bantu->ambil_total_harga($ip,$id_po)->row();
            header('Content-Type: application/json');           
                
            $kurs = $data->kurs;

            if($data->total_harga == null){
                $total_harga = 0;
            }else{
                $total_harga = $data->total_harga;
            }

            if($data->total_harga_ppn == null){
                $total_harga_ppn = 0;
            }else{
                $total_harga_ppn = $data->total_harga_ppn;
            }

            if($data->total_harga_pph == null){
                $total_harga_pph = 0;
            }else{
                $total_harga_pph = $data->total_harga_pph;
            }            

            $dt = $this->m_po->get_data_po($id_po)->row();
            $no_po = $dt->no_po;

            $this->m_tb_bantu->insert_transaksi_pembelian_po_aset($id_trs,$no_po,$tanggal_po,$estimasi_dtg,$kurs,$total_harga,$total_harga_ppn,$total_harga_pph);
            echo json_encode(array('status'=>'ok','id_trs'=>$id_trs));
        }
    }

    function update_tb_bantu_po_aset($id_trs,$id_po,$ip){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $update = $this->m_tb_bantu->update_tb_bantu_po_aset($id_trs,$id_po,$ip);
        header('Content-Type: application/json');
        echo json_encode(array('status'=>'ok'));
    }

    function proses_simpan_po_aset($id_po,$jenis_aset,$tanggal_po,$ip){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_tb_bantu->get_tb_po_aset($ip,$id_po)->result();
        header('Content-Type: application/json');
        foreach ($data as $dt){
            for($i=1;$i<=$dt->jumlah;$i++){
                $id_temp = 'hwp'.uniqid();
                $id_transaksi = $dt->id_transaksi;
                $id_barang = $dt->id_barang;
                $kode_epte = $dt->epte_code;
                $kode_fa = $dt->FA_code;
                $id_supplier = $dt->id_supplier;
                $kurs = $dt->kurs;
                $harga = $dt->harga;
                $estimasi_dtg = $dt->estimasi_dtg;
                $alokasi = $dt->alokasi;
                $jumlah = $dt->jumlah;

                $harga_satuan = $harga/$jumlah;
                if($dt->ppn == 'yes' && $dt->pph == 'yes'){
                    $ppn = ($harga_satuan*0.11)+$harga_satuan;
                    $pph = ($harga_satuan*0.02)+$harga_satuan;
                }elseif($dt->ppn == 'yes' && $dt->pph == 'no'){
                    $ppn = ($harga_satuan*0.11)+$harga_satuan;
                    $pph = $harga_satuan;
                }elseif($dt->ppn == 'no' && $dt->pph == 'yes'){
                    $ppn = $harga_satuan;
                    $pph = ($harga_satuan*0.02)+$harga_satuan;
                }else{
                    $ppn = $harga_satuan;
                    $pph = $harga_satuan;
                }                
               
                $updated_at = date('Y-m-d H:i:s');
                $this->m_tb_bantu->insert_detail_po_aset($id_temp,$id_transaksi,$id_po,$tanggal_po,$id_barang,$kode_epte,$kode_fa,$id_supplier,$kurs,$ppn,$pph,$harga_satuan,$estimasi_dtg,$jenis_aset,$alokasi,$updated_at);
            }
        }
    }

    function hapus_tb_bantu_po_aset($id_trs,$id_po,$ip){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }
        
        $insert = $this->m_tb_bantu->copy_isi_po_aset($id_trs,$id_po,$ip);
        header('Content-Type: application/json');
        if($insert){
            $this->m_tb_bantu->delete_transaksi_po_aset($id_trs,$id_po,$ip);
        }
        echo json_encode(array('status'=>'ok'));
    }

    function input_barang_cms(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $po = $this->m_po->get_po_cms()->result();
        $kategori = $this->m_cms->get_all_kategori()->result();
        $this->load->view('_template/header');
        $this->load->view('pembelian/v_input_barang_cms', array('po'=>$po,'kategori'=>$kategori));
        $this->load->view('_template/footer');
    }

    function input_barang_service(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $po = $this->m_po->get_po_service()->result();
        $this->load->view('_template/header');
        $this->load->view('pembelian/v_input_barang_service', array('po'=>$po));
        $this->load->view('_template/footer');
    }

    function cek_data_bv($id_stok,$id_supplier){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $cek_tb_vendor = $this->m_aset->cek_tb_vendor($id_stok,$id_supplier);
        $cek_tb_service = $this->m_aset->cek_tb_service($id_stok);

        header('Content-Type: application/json');
        if($cek_tb_vendor->num_rows() > '0'){
            if($cek_tb_service->num_rows() > '0'){
                echo json_encode(array('status'=>'error', 'msg'=>'Data sudah ditambahkan'));
            }else{
                echo json_encode(array('status'=>'ok', 'data'=>($cek_tb_vendor->row())));
            }
        }else{
            echo json_encode(array('status'=>'error', 'msg'=>'QR tidak ditemukan / berbeda vendor tujuan'));
        }
    }

    function tambah_barang_service(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_stok = $this->input->post('id_stok');
        $id_barang = $this->input->post('id_barang');
        $id_po = $this->input->post('id_po');
        $id_supplier = $this->input->post('id_supplier');
        $tgl_po = $this->input->post('tanggal_po');
        $harga = $this->input->post('harga_material');
        $harga_jasa = $this->input->post('harga_jasa');
        $sn = $this->input->post('sn');
        $keterangan = $this->input->post('keterangan');
        $ip = $this->input->post('ip');

        $cek_data = $this->m_tb_bantu->cek_dt_service($id_stok,$ip);
        header('Content-Type: application/json');
        if($cek_data->num_rows() > '0'){
            echo json_encode(array('status'=>'error', 'msg'=>'Data sudah ditambahkan'));
        }else{
            $this->m_tb_bantu->tambah_barang_service($id_stok,$id_barang,$id_po,$id_supplier,$tgl_po,$harga,$harga_jasa,$sn,$keterangan,$ip);
            echo json_encode(array('status'=>'ok'));
        }
    }

    function datatabel_service(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $ip = $_SERVER['REMOTE_ADDR'];
        $data = $this->m_tb_bantu->get_datatabel_service($ip)->result();
        echo json_encode($data);
    }

    function hapus_barang_service(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_stok = $this->input->post('id_stok_2');
        $data = $this->m_tb_bantu->hapus_barang_service($id_stok);
        echo json_encode($data);
    }

    function simpan_transaksi_service(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_po = $this->input->post('id_po_2');
        $ip = $this->input->post('ip_2');
        $po = $this->m_po->get_service_po($id_po)->row();
        $no_po = $po->no_po;

        $data = $this->m_aset->get_data_tb_service($id_po,$ip)->result();
        foreach($data as $dt){
            $id_stok = $dt->id_stok;
            $id_barang = $dt->id_barang;
            $id_supplier = $dt->id_supplier;
            $tgl_po = $dt->tgl_po;
            $harga = $dt->harga;
            $harga_jasa = $dt->harga_jasa;
            $ppn = (($harga + $harga_jasa) * 0.1) + ($harga + $harga_jasa);
            $keterangan = $dt->keterangan;
            $status = '0';
            $updated_at = date('Y-m-d H:i:s');

            $id_log = 'hwp'.uniqid();
            $id_aset = '';
            $status_log = '4';
            $ket_log = 'Proses PO service ke vendor';
            $id_user = $this->session->userdata('username_a');

            $this->m_tb_bantu->insert_detail_po_service($id_po,$id_stok,$id_barang,$id_supplier,$harga,$harga_jasa,
            $ppn,$keterangan,$status,$updated_at);
            $this->m_log->insert_log($id_log,$id_stok,$id_aset,$status_log,$id_supplier,$tgl_po,$no_po,$ket_log,$updated_at,$id_user);
        }
        echo json_encode(array('status'=>'ok'));
    }

    function hapus_tb_bantu_aset($id_po,$ip){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        header('Content-Type: application/json');
        $this->m_tb_bantu->hapus_tb_bantu_service($id_po,$ip);
        echo json_encode(array('status'=>'ok'));
    }

    function konfirmasi_service(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_aset->get_konfirm_service()->result();
        $this->load->view('_template/header');
        $this->load->view('aset/v_konfirmasi_service',array('data'=>$data));
        $this->load->view('_template/footer');
    }

    function konfirmasi_service_detail($id_po){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_aset->get_detail_konfirm_service($id_po)->result();
        $this->load->view('_template/header');
        $this->load->view('aset/v_konfirmasi_service_detail', array('id_po'=>$id_po,'data'=>$data));
        $this->load->view('_template/footer');
    }

    function proses_terima_service(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_po = $this->input->post('id_po');
        $tgl_terima = $this->input->post('tgl_terima');
        $surat_jalan = $this->input->post('surat_jalan');
        $select_all = $this->input->post('select_all');
        $updated_at = date('Y-m-d H:i:s');
        
        $id_aset = '';
        $status_keterangan = '0';
        $keterangan = 'Barang datang dari service vendor';
        $id_user = $this->session->userdata('username_a');

        if (is_array($select_all) || is_object($select_all)){
            foreach ($select_all as $key){
                $pecah = explode(";", $key);
                for($i=0; $i<count(array($key)); $i++){
                    $id_stok      = $pecah[$i];
                    $vendor       = $pecah[$i+1];

                    $id_log     = 'hwp'.uniqid();

                    $this->m_aset->update_tb_service($id_po,$id_stok,$surat_jalan,$updated_at);
                    $this->m_aset->update_aset_kembali($id_stok,$updated_at,$id_user);
                    $this->m_aset->delete_tb_vendor($id_stok);
                    $this->m_log->insert_log($id_log,$id_stok,$id_aset,$status_keterangan,$vendor,$tgl_terima,$surat_jalan,$keterangan,$updated_at,$id_user);
                }
            }
        }
        $this->session->set_flashdata(array('status'=>'success','msg'=>'Barang berhasil diterima'));
        redirect('c_aset/konfirmasi_service');
    }

    function export_per_aset($kode,$total){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $temp = $this->m_jenis_barang->get_nama_aset($kode)->row();
        $nama_aset = $temp->nama_aset;

        $id_jenis_barang = $this->m_jenis_barang->get_jenis_barang($kode)->result();
        foreach($id_jenis_barang as $id){
            $jenis_barang[] = $id->id_jenis_barang;
        }
        $sambung = '';

        for($i=0; $i<count($id_jenis_barang); $i++){
            if($i<count($id_jenis_barang)-1){
                $id_jns_brg = "'".$jenis_barang[$i]."',"; 
            }else{
                $id_jns_brg = "'".$jenis_barang[$i]."'";
            }
            $sambung .= $id_jns_brg;
        }

        $objPHPExcel = new PHPExcel();
                            // mengatur center
        $style = array(  
            'font' => array(
                'size' => 12,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_left = array(  
            'font' => array(
                'size' => 11
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                ),
                'borders' => array(    
                    'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                    'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                    'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                    'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
                )
        );

        $style_center = array(  
            'font' => array(
                'size' => 11,
                
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_col = array(  
            'font' => array(
                'bold' => false,
                'size' => 11), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
                ),          
            'borders' => array(    
                'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
            )   
        );

        $style_header = array(  
            'font' => array(
                'size' => 14,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $data = $this->m_aset->export_per_aset($sambung);
        $count = $this->m_aset->count_per_aset($sambung);

        $objPHPExcel->getActiveSheet()->mergeCells('A1:P1');
        $objPHPExcel->getActiveSheet()->setCellValue('A1',$nama_aset);
                
        $heading=array('NO','QR','KODE ASET','JENIS BARANG','NAMA MODEL','KODE EPTE','KODE FA','DETAIL LOKASI','NIK','NAMA USER','SN','KURS','HARGA','HARGA + PPN','STATUS','KETERANGAN');
        $rowNumberH = 4;
        $colH = 'A';
        foreach($heading as $h){
            $objPHPExcel->getActiveSheet()->setCellValue($colH.$rowNumberH,$h);
            $colH++;
        }

        $totn=$data->num_rows();
        $maxRow= $totn+1;
        $q = $data->result();
        $row = 5;
        $nomor = 1;
        foreach ($q as $dt){
            $objPHPExcel->getActiveSheet()->setCellValue('A'.$row,$nomor);
            $objPHPExcel->getActiveSheet()->setCellValue('B'.$row,$dt->id_stok);
            $objPHPExcel->getActiveSheet()->setCellValue('C'.$row,$dt->id_aset);
            $objPHPExcel->getActiveSheet()->setCellValue('D'.$row,$dt->nama_jenis_barang);
            $objPHPExcel->getActiveSheet()->setCellValue('E'.$row,$dt->nama_model);
            $objPHPExcel->getActiveSheet()->setCellValue('F'.$row,$dt->epte_code);
            $objPHPExcel->getActiveSheet()->setCellValue('G'.$row,$dt->FA_code);
            $objPHPExcel->getActiveSheet()->setCellValue('H'.$row,$dt->detail_lokasi);
            if($dt->nik == ''){
                $objPHPExcel->getActiveSheet()->setCellValue('I'.$row,'-');
                $objPHPExcel->getActiveSheet()->setCellValue('J'.$row,$dt->nama_user);
            }else{
                $objPHPExcel->getActiveSheet()->setCellValue('I'.$row,$dt->nik);
                $objPHPExcel->getActiveSheet()->setCellValue('J'.$row,$dt->NAME);
            }           
            $objPHPExcel->getActiveSheet()->setCellValue('K'.$row,$dt->sn);
            $objPHPExcel->getActiveSheet()->setCellValue('L'.$row,$dt->kurs);
            if($dt->kurs == 'IDR'){
                $format = '_("Rp"* #,##0.00_)';
            }elseif($dt->kurs == 'USD'){
                $format = '_("$"* #,##0.00_)';
            }else{
                $format = '_("₩"* #,##0.00_)';
            }
            $objPHPExcel->getActiveSheet()->getStyle('M'.$row)->getNumberFormat()->setFormatCode($format);
            $objPHPExcel->getActiveSheet()->getStyle('N'.$row)->getNumberFormat()->setFormatCode($format);
            $objPHPExcel->getActiveSheet()->setCellValue('M'.$row,$dt->harga);
            $objPHPExcel->getActiveSheet()->setCellValue('N'.$row,$dt->harga_ppn);
            $objPHPExcel->getActiveSheet()->setCellValue('O'.$row,$dt->status);
            $objPHPExcel->getActiveSheet()->setCellValue('P'.$row,$dt->remark);
            $row++;
            $nomor++;
        }

        $nextrow = $row + 2;
        $data_count = $count->result();
        $jumlah_data = $count->num_rows();
        foreach($data_count as $ct){
            $objPHPExcel->getActiveSheet()->setCellValue('C'.$nextrow,$ct->status);
            $objPHPExcel->getActiveSheet()->setCellValue('D'.$nextrow,$ct->jumlah);
            $nextrow++;
        }

        $nextrow2 = $nextrow;
        $objPHPExcel->getActiveSheet()->setCellValue('C'.$nextrow2,'TOTAL'); 
        $objPHPExcel->getActiveSheet()->setCellValue('D'.$nextrow2,$total);        

        for($i=4; $i<$row; $i++){
            $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('B'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('C'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('D'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('E'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('F'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('G'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('H'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('I'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('J'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('K'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('L'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('M'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('N'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('O'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('P'.$i)->applyFromArray($style_left);           
        }

        for($j=($nextrow-$jumlah_data); $j<=$nextrow2; $j++){
            $objPHPExcel->getActiveSheet()->getStyle('C'.$j)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('D'.$j)->applyFromArray($style_col);
        }

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(18);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(35);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(13);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(18);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(28);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(28);

        $objPHPExcel->getActiveSheet()->getStyle('A4:P4')->applyFromArray($style_center);
        $objPHPExcel->getActiveSheet()->getStyle('A1:P1')->applyFromArray($style_header);

        $objPHPExcel->getActiveSheet()->setTitle($nama_aset);
        $objPHPExcel->getDefaultStyle()->applyFromArray($style);
                        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
                        //Header

        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        //Nama File
        header('Content-Disposition: attachment;filename="'.$nama_aset.'.xlsx"');
                        //Download
        $objWriter->save("php://output"); 
    }
}