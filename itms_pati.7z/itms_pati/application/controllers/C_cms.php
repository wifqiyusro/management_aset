<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_cms extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(array('m_cms','m_tb_bantu','m_po'));
        $this->load->library(array('ciqrcode','PHPExcel'));
    }

	function index(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $kategori = $this->m_cms->get_all_kategori()->result();
        $this->load->view('_template/header');
        $this->load->view('cms/v_barang',array('kategori'=>$kategori));
        $this->load->view('_template/footer');
    }

    function get_barang_cms(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_cms->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->kode_barang;
            $row[] = $field->nama_barang;
            $row[] = $field->nama_kategori;
            $row[] = $field->satuan;
            $row[] = $field->isi_per_pack;
            if($field->stok == '0'){
                $row[] = '0';
                $row[] = '0';
            }else{
                $row[] = $field->pack;
                $row[] = $field->pcs;
            }            
            $row[] = $field->stok;
            $row[] = $field->min_stok;            
            $row[] = $field->created_at;
            $row[] = $field->updated_at;
            if($this->session->userdata('level_a') == '1' || $this->session->userdata('level_a') == '2'){
                $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="Edit" onclick="edit_barang('."'".$field->kode_barang."'".')"><span class="fe fe-edit fe-16"><span></a> 
                <a class="btn mb-1 btn-secondary btn-sm" href="'.base_url().'index.php/c_cms/detail_log/'.$field->kode_barang.'" title="History"><i class="fe fe-clock fe-12" aria-hidden="true"></i></a>';
            }else{
                $row[] = '<a class="btn mb-1 btn-secondary btn-sm" href="'.base_url().'index.php/c_cms/detail_log/'.$field->kode_barang.'" title="History"><i class="fe fe-clock fe-12" aria-hidden="true"></i></a>';
            }
            
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_cms->count_all(),
            "recordsFiltered" => $this->m_cms->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function detail_log($kode_barang){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $data = $this->m_cms->get_data_barang($kode_barang)->row();
        $this->load->view('_template/header');
        $this->load->view('log/v_detail_log', array('data'=>$data,'kode_barang'=>$kode_barang));
        $this->load->view('_template/footer');
    }

    function get_detail_log_cms($kode_barang){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_cms->get_datatables_detail_log_cms($kode_barang);
        $data = array();
        $no = @$_POST['start'];
        if(is_array($list) || is_object($list)){
            foreach($list as $field){
                $no++;
                $row = array();
                $row[] = $no;
                if($field->aktivitas == '0'){
                    $row[] = '<span class="badge badge-pill badge-primary">Ditambahkan</span>';
                }elseif($field->aktivitas == '1'){
                    $row[] = '<span class="badge badge-pill badge-danger">Edit Data</span>';
                }elseif($field->aktivitas == '2'){
                    $row[] = '<span class="badge badge-pill badge-success">Masuk</span>';
                }elseif($field->aktivitas == '3'){
                    $row[] = '<span class="badge badge-pill badge-warning">Keluar</span>';
                }elseif($field->aktivitas == '4'){
                    $row[] = '<span class="badge badge-pill badge-info">Kembali</span>';
                }else{
                    $row[] = '<span class="badge badge-pill badge-secondary">Proses PO</span>';
                }
                $row[] = $field->jumlah;
                //$row[] = $field->sisa;
                $row[] = $field->satuan;
                $row[] = $field->tanggal;
                $row[] = $field->surat_jalan;
                $row[] = $field->pengguna;
                $row[] = $field->keperluan;
                $row[] = $field->created_at;
                $data[] = $row;
            }
        }
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $this->m_cms->count_all_detail_log($kode_barang),
            "recordsFiltered" => $this->m_cms->count_filtered_detail_log($kode_barang),
            "data" => $data,
        );
        //output dalam format JSON
        echo json_encode($output);
    }

    function edit_barang_($kode_barang){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_cms->get_data_barang($kode_barang)->row();
        echo json_encode($data);
    }

    function add_barang_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $kode_barang = 'hwp'.uniqid();
        $nama_barang = $this->input->post('nama_barang');
        $kategori = $this->input->post('id_kategori');
        $satuan = $this->input->post('satuan');
        $isi_per_pack = $this->input->post('isi_per_pack');
        $min_stok = $this->input->post('min_stok');
        $updated_at = date('Y-m-d H:i:s');
        $id_user = $this->session->userdata('username_a');

        $add = $this->m_cms->add_barang($kode_barang,$nama_barang,$kategori,$satuan,$isi_per_pack,$min_stok,$updated_at,$id_user);
        if($add){
            $id_log = 'hwp'.uniqid();
            $aktivitas = '0';
            $jumlah = '';
            $surat_jalan = '';
            $pengguna = '';
            $keperluan = 'Barang ditambahkan ke sistem';
            $this->m_cms->insert_log($id_log,$kode_barang,$aktivitas,$jumlah,$surat_jalan,$pengguna,$keperluan,$id_user);
        }
        echo json_encode(array("status" => TRUE));
    }

    function update_barang_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $kode_barang = $this->input->post('kode_barang');
        $nama_barang = $this->input->post('nama_barang');
        $kategori = $this->input->post('id_kategori');
        $satuan = $this->input->post('satuan');
        $isi_per_pack = $this->input->post('isi_per_pack');
        $min_stok = $this->input->post('min_stok');
        $updated_at = date('Y-m-d H:i:s');
        $id_user = $this->session->userdata('username_a');

        $update = $this->m_cms->update_barang($kode_barang,$kategori,$nama_barang,$satuan,$isi_per_pack,$min_stok,$updated_at,$id_user);
        if($update){
            $id_log = 'hwp'.uniqid();
            $aktivitas = '1';
            $jumlah = 0;
            $sisa = '';
            $surat_jalan = '';
            $pengguna = '';
            $keperluan = 'User '.$id_user.' melakukan update data';
            $this->m_cms->insert_log($id_log,$kode_barang,$aktivitas,$jumlah,$sisa,$surat_jalan,$pengguna,$keperluan,$id_user);
        }
        echo json_encode(array("status"=>TRUE));
    }

    function transaksi(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $data = $this->m_cms->get_nama_barang()->result();
        $this->load->view('_template/header');
        $this->load->view('cms/v_transaksi', array('data'=>$data));
        $this->load->view('_template/footer');
    }

    function get_detail_barang($kode_barang){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }
        
        $data = $this->m_cms->cek_kode_barang($kode_barang);
        header('Content-Type: application/json');
        if($data->num_rows()>0){
            echo json_encode(array('status'=>'ok','data'=>($data->row())));
        }else{
            echo json_encode(array('status'=>'error','msg'=>'Barang tidak ditemukan'));
        }
    }

    function cek_status_jumlah($kode_barang,$jumlah,$jenis_transaksi){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $data = $this->m_cms->cek_status_jumlah($kode_barang)->row();
        $stok = $data->stok;
        header('Content-Type: application/json');
        if($jenis_transaksi == '3'){            
            if($jumlah > $stok){
                echo json_encode(array('status'=>'error','msg'=>'Jumlah stok tidak mencukupi'));
            }else{
                echo json_encode(array('status'=>'ok','data'=>$stok));
            }
        }else{
            echo json_encode(array('status'=>'ok','data'=>$stok));
        }
    }

    function proses_transaksi(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2' && $this->session->userdata('level_a') != '3'){
            redirect('c_user/logout');
        }

        $jenis_transaksi = $this->input->post('jenis_transaksi');
        $kode_barang = $this->input->post('kode_barang');
        $stok = $this->input->post('stok');
        $jumlah = $this->input->post('jumlah');
        $pengguna = $this->input->post('pengguna');
        $tanggal = $this->input->post('tanggal');
        $keperluan = $this->input->post('keperluan');
        $updated_at = date('Y-m-d H:i:s');
        $id_user = $this->session->userdata('username_a');
        $id_log = 'hwp'.uniqid();
        $surat_jalan = '';

        if($jenis_transaksi == '4'){
            $stok_update = $stok + $jumlah;
            $update = $this->m_cms->transaksi($kode_barang,$stok_update,$updated_at,$id_user);
            if($update){                
                $this->m_cms->insert_log($id_log,$kode_barang,$jenis_transaksi,$jumlah,$stok_update,$surat_jalan,$pengguna,$tanggal,$keperluan,$id_user);
                $this->session->set_flashdata(array('status'=>'success','msg'=>'Transaksi berhasil disimpan'));
            }
        }elseif($jenis_transaksi == '3'){
            $data = $this->m_cms->get_stok($kode_barang)->row();
            $cek_stok = $data->stok;
            if(($cek_stok - $jumlah) < '0'){
               $this->session->set_flashdata(array('status'=>'danger','msg'=>'Transaksi gagal disimpan'));
            }else{
                $stok_update = $cek_stok - $jumlah;
                $update = $this->m_cms->transaksi($kode_barang,$stok_update,$updated_at,$id_user);
                if($update){
                    $this->m_cms->insert_log($id_log,$kode_barang,$jenis_transaksi,$jumlah,$stok_update,$surat_jalan,$pengguna,$tanggal,$keperluan,$id_user);
                    $this->session->set_flashdata(array('status'=>'success','msg'=>'Transaksi berhasil disimpan'));
                }
            }
        }else{
            $this->session->set_flashdata(array('status'=>'danger','msg'=>'Jenis Transaksi belum dipilih, mohon cek kembali'));
        }
        redirect('c_cms/transaksi');
    }

    function log_cms(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('log/v_log_cms');
        $this->load->view('_template/footer');
    }

    function get_data_log_cms(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_cms->get_datatables_log_cms();
        $data = array();        
        foreach($list as $field){    
            $row = array();            
            $row[] = $field->kode_barang;
            $row[] = $field->nama_barang;
            if($field->aktivitas == '0'){
                $row[] = '<span class="badge badge-pill badge-primary">Ditambahkan</span>';
            }elseif($field->aktivitas == '1'){
                $row[] = '<span class="badge badge-pill badge-danger">Edit Data</span>';
            }elseif($field->aktivitas == '2'){
                $row[] = '<span class="badge badge-pill badge-success">Masuk</span>';
            }elseif($field->aktivitas == '3'){
                $row[] = '<span class="badge badge-pill badge-warning">Keluar</span>';
            }elseif($field->aktivitas == '4'){
                $row[] = '<span class="badge badge-pill badge-info">Kembali</span>';
            }else{
                $row[] = '<span class="badge badge-pill badge-secondary">Proses PO</span>';
            }
            $row[] = $field->jumlah;
            // $row[] = $field->sisa;
            $row[] = $field->satuan;
            $row[] = $field->tanggal;       
            $row[] = $field->surat_jalan;
            $row[] = $field->pengguna;            
            $row[] = $field->keperluan;
            $row[] = $field->nama_user;
            $row[] = $field->created_at;
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_cms->count_all_log(),
            "recordsFiltered" => $this->m_cms->count_filtered_log(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function export_detail_log_cms($kode_barang,$tgl_mulai,$tgl_selesai){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $nama_barang = $this->m_cms->get_data_barang($kode_barang)->row();
        if($tgl_mulai =='-' && $tgl_selesai == '-'){
            $data = $this->m_cms->export_detail_log_cms1($kode_barang);
            $judul = "Data Log ".($nama_barang->nama_barang);
        }elseif($tgl_mulai !='-' && $tgl_selesai == '-'){
            $tanggal_mulai = $tgl_mulai.' 00:00:00';
            $data = $this->m_cms->export_detail_log_cms2($kode_barang,$tanggal_mulai);
            $judul = "Data Log ".($nama_barang->nama_barang)." Mulai Tanggal ".$tgl_mulai;
        }elseif($tgl_mulai =='-' && $tgl_selesai != '-'){
            $tanggal_selesai = $tgl_selesai.' 23:59:59';
            $data = $this->m_cms->export_detail_log_cms3($kode_barang,$tanggal_selesai);
            $judul = "Data Log ".($nama_barang->nama_barang)." Sampai Tanggal ".$tgl_selesai;
        }else{
            $tanggal_mulai = $tgl_mulai.' 00:00:00';
            $tanggal_selesai = $tgl_selesai.' 23:59:59';
            $data = $this->m_cms->export_detail_log_cms4($kode_barang,$tanggal_mulai,$tanggal_selesai);
            $judul = "Data Log ".($nama_barang->nama_barang)." Mulai Tanggal ".$tgl_mulai." Sampai Tanggal ".$tgl_selesai;
        }

        $objPHPExcel = new PHPExcel();
                            // mengatur center
        $style = array(  
            'font' => array(
                'size' => 12,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_left = array(  
            'font' => array(
                'size' => 11
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                ),
                'borders' => array(    
                    'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                    'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                    'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                    'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
                )
        );

        $style_center = array(  
            'font' => array(
                'size' => 11,
                
                ), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
                    'wrap' => true // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $style_col = array(  
            'font' => array(
                'bold' => false,
                'size' => 11), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
                ),          
            'borders' => array(    
                'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis    
                'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis    
                'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis    
                'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis  
            )   
        );

        $style_header = array(  
            'font' => array(
                'size' => 14,
                'bold' => true), // Set font nya jadi bold  
                'alignment' => array(    
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)    
                    'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)  
                )  
        );

        $objPHPExcel->getActiveSheet()->mergeCells('A1:I1');
        $objPHPExcel->getActiveSheet()->setCellValue('A1',$judul);
                
        $heading=array('NO','AKTIVITAS','JML TRANSAKSI','SATUAN','TANGGAL','SURAT JALAN','USER','KETERANGAN','CREATED AT');
        $rowNumberH = 4;
        $colH = 'A';
        foreach($heading as $h){
            $objPHPExcel->getActiveSheet()->setCellValue($colH.$rowNumberH,$h);
            $colH++;
        }

        $totn=$data->num_rows();
        $maxRow= $totn+1;
        $q = $data->result();
        $row = 5;
        $nomor = 1;
        foreach ($q as $dt){
            $objPHPExcel->getActiveSheet()->setCellValue('A'.$row,$nomor);
            $objPHPExcel->getActiveSheet()->setCellValue('B'.$row,$dt->aktivitas);
            $objPHPExcel->getActiveSheet()->setCellValue('C'.$row,$dt->jumlah);
            $objPHPExcel->getActiveSheet()->setCellValue('D'.$row,$dt->satuan);
            $objPHPExcel->getActiveSheet()->setCellValue('E'.$row,$dt->tanggal);
            $objPHPExcel->getActiveSheet()->setCellValue('F'.$row,$dt->surat_jalan);
            $objPHPExcel->getActiveSheet()->setCellValue('G'.$row,$dt->pengguna);
            $objPHPExcel->getActiveSheet()->setCellValue('H'.$row,$dt->keperluan);
            $objPHPExcel->getActiveSheet()->setCellValue('I'.$row,$dt->created_at);
            $row++;
            $nomor++;
        }

        $stok = $nama_barang->stok;
        $satuan = $nama_barang->satuan;
        $gabung = $stok.' '.$satuan;

        $row_b = $row;
        $objPHPExcel->getActiveSheet()->mergeCells('A'.$row_b.':I'.$row_b);
        $objPHPExcel->getActiveSheet()->setCellValue('A'.$row_b,'Stok Terakhir : '.$gabung);
        $objPHPExcel->getActiveSheet()->getStyle('A'.$row_b.':I'.$row_b)->applyFromArray($style_col); 

        for($i=4; $i<$row; $i++){
            $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('B'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('C'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('D'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('E'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('F'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('G'.$i)->applyFromArray($style_col);
            $objPHPExcel->getActiveSheet()->getStyle('H'.$i)->applyFromArray($style_left);
            $objPHPExcel->getActiveSheet()->getStyle('I'.$i)->applyFromArray($style_col);          
        }

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(40);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(20);

        $objPHPExcel->getActiveSheet()->getStyle('A4:I4')->applyFromArray($style_center);
        $objPHPExcel->getActiveSheet()->getStyle('A1:I1')->applyFromArray($style_header);

        $objPHPExcel->getActiveSheet()->setTitle('DATA LOG BARANG CMS');
        $objPHPExcel->getDefaultStyle()->applyFromArray($style);
                        //Save ke .xlsx, kalau ingin .xls, ubah 'Excel2007' menjadi 'Excel5'
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
                        //Header

        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                        //Nama File
        header('Content-Disposition: attachment;filename="'.$judul.'.xlsx"');
                        //Download
        $objWriter->save("php://output");
    }

    function kategori_cms(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('cms/v_kategori_cms');
        $this->load->view('_template/footer');
    }

    function get_kategori_cms(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_cms->get_datatables_kategori();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->id_kategori;
            $row[] = $field->nama_kategori;
            $row[] = $field->created_at;
            $row[] = $field->updated_at;
            if($this->session->userdata('level_a') == '1' || $this->session->userdata('level_a') == '2'){
                $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="Edit" onclick="edit_kategori_cms('."'".$field->id_kategori."'".')"><span class="fe fe-edit fe-16"><span></a>';
            }else{
                $row[] = '';
            }            
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_cms->count_all_kat_cms(),
            "recordsFiltered" => $this->m_cms->count_filtered_kat_cms(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function edit_kategori_cms_($id_kategori){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_cms->get_data_kategori_cms($id_kategori)->row();
        echo json_encode($data);
    }

    function add_kategori_cms_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_kategori = 'hwp'.uniqid();
        $nama_kategori = $this->input->post('nama_kategori');
        $updated_at = date('Y-m-d H:i:s');

        $add = $this->m_cms->add_kategori_cms($id_kategori,$nama_kategori,$updated_at);
        echo json_encode(array("status" => TRUE));
    }

    function update_kategori_cms_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_kategori = $this->input->post('id_kategori');
        $nama_kategori = $this->input->post('nama_kategori');
        $updated_at = date('Y-m-d H:i:s');

        $update = $this->m_cms->update_kategori_cms($id_kategori,$nama_kategori,$updated_at);
        echo json_encode(array("status"=>TRUE));
    }

    function cari_barang(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id = $this->input->post('id');
        echo $this->m_cms->cari_barang($id);
    }

    function tambah_barang_cms(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_kategori = $this->input->post('id_kategori');
        $kode_barang = $this->input->post('kode_barang');
        $id_po = $this->input->post('id_po_2');
        $id_supplier = $this->input->post('id_supplier');
        $kurs = $this->input->post('kurs');
        $harga = $this->input->post('harga');
        $jumlah = $this->input->post('jumlah');
        $harga_total = $jumlah * $harga;
        $ip = $this->input->post('ip');

        $cek_data = $this->m_tb_bantu->cek_data_cms($kode_barang,$ip);
        header('Content-Type: application/json');
        if($cek_data->num_rows()>0){
            echo json_encode(array('status'=>'error','msg'=>'Data sudah ditambahkan'));
        }else{
            $this->m_tb_bantu->tambah_barang_cms($id_kategori,$kode_barang,$id_po,$id_supplier,$kurs,$harga_total,$jumlah,$ip);
            echo json_encode(array('status'=>'ok'));
        } 
    }

    function datatabel_cms(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $ip = $_SERVER['REMOTE_ADDR'];
        $data = $this->m_tb_bantu->get_datatabel_cms($ip)->result();
        echo json_encode($data);
    }

    function hapus_barang_cms(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $ip = $_SERVER['REMOTE_ADDR'];
        $kode_barang = $this->input->post('kode_barang');
        $data = $this->m_tb_bantu->hapus_barang_cms($kode_barang,$ip);
        echo json_encode($data);
    }

    function simpan_transaksi_cms(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_po = $this->input->post('id_po_2');
        $ip = $this->input->post('ip_2');
        $po = $this->m_po->get_data_po_cms($id_po)->row();
        $no_po = $po->no_po;

        $data = $this->m_cms->get_data_tb_cms($id_po,$ip)->result();
        header('Content-Type: application/json');
        foreach($data as $dt){           
            $id_po_2 = $dt->id_po;
            $kode_barang = $dt->kode_barang;
            $id_supplier = $dt->id_supplier;
            $jumlah = $dt->jumlah;
            $jumlah_waiting = $dt->jumlah;
            $jumlah_done = 0;
            $harga = $dt->harga;
            $kurs = $dt->kurs;
            if($kurs == 'IDR'){
                $ppn = (0.11 * $harga)+ $harga;
            }else{
                $ppn = $harga;
            }            
            $status = 0;
            $tanggal = date('Y-m-d');
            $updated_at = date('Y-m-d H:i:s');

            $id_log = 'hwp'.uniqid();
            $aktivitas = 5;
            $sisa = '';
            $surat_jalan = '';
            $pengguna = 'Admin';
            $keperluan = 'Proses PO : '.$no_po;
            $id_user = $this->session->userdata('username_a');
            
            $this->m_cms->insert_po_cms($id_po_2,$kode_barang,$id_supplier,$jumlah,$jumlah_waiting,$jumlah_done,$kurs,$harga,
            $ppn,$status,$updated_at);
            $this->m_cms->insert_log($id_log,$kode_barang,$aktivitas,$jumlah,$sisa,$surat_jalan,$pengguna,$tanggal,$keperluan,$id_user);
        }
        echo json_encode(array('status'=>'ok'));
    }

    function hapus_tb_bantu_cms($id_po,$ip){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        header('Content-Type: application/json');
        $this->m_cms->hapus_tb_bantu_cms($id_po,$ip);
        echo json_encode(array('status'=>'ok'));
    }

    function konfirmasi_cms(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_cms->get_konfirm_cms()->result();
        $this->load->view('_template/header');
        $this->load->view('cms/v_konfirmasi_cms',array('data'=>$data));
        $this->load->view('_template/footer');
    }

    function konfirmasi_cms_detail($id_po){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_cms->get_detail_konfirm_cms($id_po)->result();
        $this->load->view('_template/header');
        $this->load->view('cms/v_konfirmasi_cms_detail', array('id_po'=>$id_po,'data'=>$data));
        $this->load->view('_template/footer');
    }

    function proses_terima_cms(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $surat_jalan = $this->input->post('surat_jalan');
        $jml_dtg = $this->input->post('jml_dtg');
        $tanggal = $this->input->post('tanggal');
        $select_all = $this->input->post('select_all');
        foreach($select_all as $key){
            $pecah = explode(";",$key);
            for($i=0; $i<=count(array($key)); $i++){
                $id_po              = $pecah[$i];
                $kode_barang        = $pecah[$i+1];
                $jumlah             = $pecah[$i+2];
                $harga              = $pecah[$i+3];
                $ppn                = $pecah[$i+4];
                $waiting            = $pecah[$i+5];
                $done               = $pecah[$i+6];
                $surat_jalan_lama   = $pecah[$i+7];
                $status             = $pecah[$i+8];

                $temp_stok          = $this->m_cms->cek_stok($kode_barang)->row();
                $stok_lama          = $temp_stok->stok;
                $updated_at         = date('Y-m-d H:i:s');
                $id_user            = $this->session->userdata('username_a');

                $id_log             = 'hwp'.uniqid();
                $jenis_transaksi    = '2';
                $pengguna           = 'Admin';
                $keperluan          = 'Barang masuk dari pembelian supplier';

                if($jml_dtg<=$waiting){
                    $waiting_baru = $waiting - $jml_dtg;
                    $done_baru = $jumlah - $waiting_baru;
                    $stok_baru = $stok_lama + $jml_dtg;
                    $surat_jalan_baru = $surat_jalan_lama.' '.$surat_jalan;
                    if($waiting_baru == '0'){
                        $status_2 = '1';
                        $this->m_cms->update_detail_cms($id_po,$kode_barang,$waiting_baru,$done_baru,$surat_jalan_baru,$status_2,$updated_at);
                    }else{
                        $this->m_cms->update_detail_cms($id_po,$kode_barang,$waiting_baru,$done_baru,$surat_jalan_baru,$status,$updated_at);
                    }
                    $this->m_cms->transaksi($kode_barang,$stok_baru,$updated_at,$id_user);
                    $this->m_cms->insert_log($id_log,$kode_barang,$jenis_transaksi,$jml_dtg,$stok_baru,$surat_jalan,$pengguna,$tanggal,$keperluan,$id_user);
                    $this->session->set_flashdata(array('status'=>'success','msg'=>'Barang berhasil diterima'));
                    redirect('c_cms/konfirmasi_cms_detail/'.$id_po);
                }else{
                    echo "<script>alert('Jumlah barang melebihi order !');window.location='konfirmasi_cms'</script>";
                }
            }
        }
    }
}
