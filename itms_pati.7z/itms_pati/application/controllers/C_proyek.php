<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_proyek extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(array('m_proyek','m_supplier','m_tb_bantu','m_log'));
    }

	function index(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $supplier = $this->m_supplier->get_data_supplier()->result();
        $this->load->view('_template/header');
        $this->load->view('proyek/v_master_proyek',array('supplier'=>$supplier));
        $this->load->view('_template/footer');
    }

    function get_master_po(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_proyek->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->nama_proyek;
            $row[] = $field->no_po;
            $row[] = $field->nama_supplier;
            $row[] = $field->tanggal;
            $row[] = $field->kurs;
            $row[] = number_format($field->total_harga);
            $row[] = $field->remark;
            $row[] = $field->created_at;
            $row[] = $field->updated_at;
            if($this->session->userdata('level_a') == '1' || $this->session->userdata('level_a') == '2'){
                $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="Edit" onclick="edit_proyek('."'".$field->id_proyek."'".')"><span class="fe fe-edit fe-16"><span></a>';
            }else{
                $row[] = '';
            }
            
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_proyek->count_all(),
            "recordsFiltered" => $this->m_proyek->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function add_proyek_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_proyek = 'hwp'.uniqid();
        $nama_proyek = $this->input->post('nama_proyek');
        $no_po = $this->input->post('no_po');
        $id_supplier = $this->input->post('id_supplier');
        $tanggal = $this->input->post('tanggal');
        $kurs = $this->input->post('kurs');
        $total_harga = $this->input->post('total_harga');
        $remark = $this->input->post('remark');
        $updated_at = date('Y-m-d H:i:s');

        $add = $this->m_proyek->add_proyek($id_proyek,$nama_proyek,$no_po,$id_supplier,$tanggal,$kurs,$total_harga,$remark,$updated_at);
        echo json_encode(array("status" => TRUE));
    }

    function edit_proyek_($id_proyek){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_proyek->get_data_proyek($id_proyek)->row();
        echo json_encode($data);
    }

    function update_proyek_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_proyek = $this->input->post('id_proyek');
        $nama_proyek = $this->input->post('nama_proyek');
        $konfirm_po = $this->input->post('konfirm_po');
        if($konfirm_po == 'Y'){
            $no_po = $this->input->post('no_po');
        }else{
            $no_po = '';
        }
        $id_supplier = $this->input->post('id_supplier');
        $tanggal = $this->input->post('tanggal');
        $kurs = $this->input->post('kurs');
        $total_harga = $this->input->post('total_harga');
        $remark = $this->input->post('remark');
        $updated_at = date('Y-m-d H:i:s');

        $update = $this->m_proyek->update_proyek($id_proyek,$nama_proyek,$no_po,$id_supplier,$tanggal,$kurs,$total_harga,$remark,$updated_at);
        echo json_encode(array("status"=>TRUE));
    }

    function status_ok(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $ip = $_SERVER['REMOTE_ADDR'];
        $data = $this->m_tb_bantu->get_datatabel_proyek($ip)->result();
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    function proses_simpan($id_proyek,$ip){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_tb_bantu->get_datatabel_proyek($ip)->result();
        $data_kurs = $this->m_tb_bantu->get_kurs_proyek($id_proyek)->row();
        $kurs = $data_kurs->kurs;
        header('Content-Type: application/json');
        foreach($data as $dt){
            for($i=1; $i<=$dt->jumlah; $i++){
                $id_stok = 'hwp'.uniqid();
                $id_transaksi = $id_proyek;
                $id_barang = $dt->id_barang;
                $kode_epte = $dt->epte_code;
                $kode_fa = $dt->FA_code;
                $id_supplier = $dt->id_supplier;
                $keterangan = $dt->keterangan;
                $alokasi = $dt->alokasi;
                $status_keterangan = '0';
                $jenis_aset = '2';
                $plan = '2';
                $updated_at = date('Y-m-d H:i:s');
                $id_user = $this->session->userdata('username_a');

                $insert_barang = $this->m_proyek->insert_barang_proyek($id_stok,$id_transaksi,$id_barang,$kode_epte,$kode_fa,$id_supplier,$kurs,$alokasi,$keterangan,$status_keterangan,$jenis_aset,$updated_at,$id_user,$plan);
                if($insert_barang){
                    $id_log = 'hwp'.uniqid();
                    $id_stock = $id_stok;
                    $status_log = $status_keterangan;
                    $tanggal = date('Y-m-d');
                    $keterangan = "Barang masuk projek";
                    $this->m_log->insert_log_proyek($id_log,$id_stock,$status_log,$tanggal,$keterangan,$id_user);
                }
            }
        }
    }

    function hapus_tb_bantu_proyek($ip){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $this->m_tb_bantu->hapus_data_proyek($ip);
        echo json_encode(array('status'=>'ok'));
    }

}