<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_surat_jalan extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(array('m_surat_jalan','m_supplier','m_aset'));
    }

	function index(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $supplier = $this->m_supplier->get_data_supplier()->result();
        $this->load->view('_template/header');
        $this->load->view('surat_jalan/v_master_surat_jalan',array('supplier'=>$supplier));
        $this->load->view('_template/footer');
    }

    function get_master_surat_jalan(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_surat_jalan->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->surat_jalan;
            $row[] = $field->packing_list;
            $row[] = $field->tanggal;
            $row[] = $field->nama_supplier;
            $row[] = $field->pengirim;
            if($field->status == '0'){
                $row[] = '<span class="badge badge-pill badge-danger">Open</span>';
            }else{
                $row[] = '<span class="badge badge-pill badge-info">Close</span>';
            }
            $row[] = $field->keterangan;
            $row[] = $field->created_at;
            $row[] = $field->updated_at;
            if($this->session->userdata('level_a') == '1' || $this->session->userdata('level_a') == '2'){
                if($field->status == 'N'){
                    $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="Edit" onclick="edit_surat_jalan('."'".$field->id_surat_jalan."'".')"><span class="fe fe-edit fe-16"><span></a>';
                }else{
                    $row[] = '';
                }                
            }else{
                $row[] = '';
            }
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_surat_jalan->count_all(),
            "recordsFiltered" => $this->m_surat_jalan->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function add_surat_jalan_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_surat_jalan = uniqid();
        $surat_jalan = $this->input->post('surat_jalan');
        $packing_list = $this->input->post('packing_list');
        $tanggal = $this->input->post('tanggal');
        $supplier = $this->input->post('supplier');
        $pengirim = $this->input->post('pengirim');
        $keterangan = $this->input->post('keterangan');
        $updated_at = date('Y-m-d H:i:s');

        $add = $this->m_surat_jalan->add_surat_jalan($id_surat_jalan,$surat_jalan,$packing_list,$tanggal,$supplier,$pengirim,$keterangan,$updated_at);
        echo json_encode(array("status" => TRUE));
    }

    function edit_surat_jalan_($id_surat_jalan){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_surat_jalan->get_data_surat_jalan($id_surat_jalan)->row();
        echo json_encode($data);
    }

    function update_surat_jalan_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_surat_jalan = $this->input->post('id_surat_jalan');
        $surat_jalan = $this->input->post('surat_jalan');
        $packing_list = $this->input->post('packing_list');
        $tanggal = $this->input->post('tanggal');
        $supplier = $this->input->post('supplier');
        $pengirim = $this->input->post('pengirim');
        $keterangan = $this->input->post('keterangan');
        $updated_at = date('Y-m-d H:i:s');

        $update = $this->m_surat_jalan->update_surat_jalan($id_surat_jalan,$surat_jalan,$packing_list,$tanggal,$supplier,$pengirim,$keterangan,$updated_at);
        echo json_encode(array("status"=>TRUE));
    }

    function input_surat_jalan(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $surat_jalan = $this->m_surat_jalan->get_surat_jalan()->result();
        $this->load->view('_template/header');
        $this->load->view('surat_jalan/v_input_surat_jalan',array('surat_jalan'=>$surat_jalan));
        $this->load->view('_template/footer');
    }

    function cek_surat_jalan($id_surat_jalan){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_surat_jalan->get_data_surat_jalan($id_surat_jalan);
        header('Content-Type: application/json');
        if($data->num_rows() > '0'){
            echo json_encode(array('status'=>'ok', 'data'=>($data->row())));
        }else{
            echo json_encode(array('status'=>'error', 'msg'=>'Surat jalan tidak ditemukan'));
        }
    }

    function cek_data_bi($id_stok){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_surat_jalan->get_data_barang($id_stok);
        header('Content-Type: application/json');
        if($data->num_rows() > '0'){
            echo json_encode(array('status'=>'ok', 'data'=>($data->row())));
        }else{
            echo json_encode(array('status'=>'error', 'msg'=>'Barang tidak ditemukan'));
        }
    }

    function tambah_barang_sj(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_stok_b = $this->input->post('id_stok_b');
        $surat_jalan = $this->input->post('surat_jalan');
        $nama_jenis_barang = $this->input->post('nama_jenis_barang');
        $nama_model = $this->input->post('nama_model');
        $qty = '1';
        $sn = $this->input->post('sn');
        $no_po = $this->input->post('no_po');
        $kategori = $this->input->post('kategori');
        $keterangan_barang = $this->input->post('keterangan_barang');
        $netto = $this->input->post('netto');
        $gross = $this->input->post('gross');
        $volume = $this->input->post('volume');
        $ip = $_SERVER['REMOTE_ADDR'];
        $id_user = $this->session->userdata('username_a');

        $cek_data = $this->m_surat_jalan->cek_data($surat_jalan,$id_stok_b);
        header('Content-Type: application/json');
        if($cek_data->num_rows() > '0'){
            echo json_encode(array('status'=>'error', 'msg'=>'Data sudah ditambahkan'));
        }else{
            $this->m_surat_jalan->tambah_barang_sj($id_stok_b,$surat_jalan,$nama_jenis_barang,$nama_model,$qty,$sn,$no_po,$kategori,$keterangan_barang,$netto,$gross,$volume,$ip,$id_user);
            echo json_encode(array('status'=>'ok'));
        }
    }

    function datatabel($surat_jalan){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $ip = $_SERVER['REMOTE_ADDR'];
        $tgl = date('Ymd');
        $data = $this->m_surat_jalan->get_datatabel($surat_jalan,$tgl,$ip)->result();
        echo json_encode($data);
    }

    function hapus_barang(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_surat_jalan = $this->input->post('id_surat_jalan');
        $qr = $this->input->post('id_stok');

        $data = $this->m_surat_jalan->hapus_barang($id_surat_jalan,$qr);
        echo json_encode($data);
    }

    function tambah_barang_na(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $sj_na = $this->input->post('sj_na');
        $jenis_barang = $this->input->post('jenis_barang_na');
        $barang = $this->input->post('nama_model_na');
        $sn = $this->input->post('sn_na');
        $qty = $this->input->post('qty_na');
        $no_po = $this->input->post('no_po_na');
        $kategori = $this->input->post('kategori_na');
        $keterangan = $this->input->post('keterangan_na');
        $netto = $this->input->post('netto_na');
        $gross = $this->input->post('gross_na');
        $volume = $this->input->post('volume_na');
        $ip = $_SERVER['REMOTE_ADDR'];
        $id_user = $this->session->userdata('username_a');
        
        $cek_qr = $this->m_surat_jalan->get_qr();
        if(($cek_qr->num_rows()) == 0){
            $qr = 'NA0001';
        }else{
            $kode = $this->m_surat_jalan->get_qr()->row();
            $urut = substr($kode->urut,2,4);
            $tambah = $urut + 1;
            if($tambah<10){
                $qr = 'NA000'.$tambah;
            }elseif($tambah<100){
                $qr = 'NA00'.$tambah;
            }elseif($tambah<1000){
                $qr = 'NA0'.$tambah;
            }else{
                $qr = 'NA'.$tambah;
            }
        }

        $this->m_surat_jalan->tambah_barang_sj($qr,$sj_na,$jenis_barang,$barang,$qty,$sn,$no_po,$kategori,$keterangan,$netto,$gross,$volume,$ip,$id_user);
        echo json_encode(array('status'=>'ok'));
    }

    function konfirmasi_sj(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_surat_jalan = $this->input->post('konfirm_sj');
        $updated_at = date('Y-m-d H:i:s');

        $this->m_surat_jalan->konfirmasi_sj($id_surat_jalan,$updated_at);
        $this->session->set_flashdata(array('status'=>'success','msg'=>'Surat jalan sudah disimpan'));
        echo json_encode(array('status'=>'ok'));
    }

}