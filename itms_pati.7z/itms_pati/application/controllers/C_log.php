<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_log extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(array('m_aset','m_jenis_barang','m_stok_barang','m_lokasi','m_log'));
    }

	function log($id_stok,$jenis_aset){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $aset = $this->m_aset->get_total_aset()->result();
        $cek_nama = $this->m_log->get_nama_model($id_stok)->row();
        $nama_model = $cek_nama->nama_model;
        $id_transaksi = $cek_nama->id_transaksi;


        if($jenis_aset == '0' || $jenis_aset == '1'){
            $transaksi = $this->m_log->data_transaksi($id_transaksi)->row();
        }else{
            $transaksi = $this->m_log->data_transaksi_proyek($id_transaksi)->row();
        }

        $this->load->view('_template/header');
        $this->load->view('log/v_log', array('aset'=>$aset,'nama_model'=>$nama_model,'id_stok'=>$id_stok,'jenis_aset'=>$jenis_aset,'transaksi'=>$transaksi,'cek_nama'=>$cek_nama));
        $this->load->view('_template/footer');
    }

    function get_data_log($id_stok,$jenis_aset){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_log->get_datatables($id_stok);
        $data = array();
        $no = @$_POST['start'];        
            foreach($list as $field){
                $no++;
                $row = array();
                $row[] = $no;
                if($field->status_log == '0'){
                    $row[] = '<span class="badge badge-pill badge-primary">Stok</span>';
                }elseif($field->status_log == '1'){
                    $row[] = '<span class="badge badge-pill badge-success">Terpasang</span>';
                }elseif($field->status_log == '3'){
                    $row[] = '<span class="badge badge-pill badge-warning">Rusak IT</span>';
                }else{
                    $row[] = '<span class="badge badge-pill badge-danger">Rusak Vendor</span>';
                }
                $row[] = $field->nama_supplier;
                $row[] = $field->tgl;
                $row[] = $field->po_srt_jln;
                $row[] = $field->keterangan;
                $row[] = $field->created_at;
                $data[] = $row;
            }        
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $this->m_log->count_all($id_stok),
            "recordsFiltered" => $this->m_log->count_filtered($id_stok),
            "data" => $data,
        );
        //output dalam format JSON
        echo json_encode($output);
    }

    function log_barang(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('log/v_log_barang');
        $this->load->view('_template/footer');
    }

    function get_data_log_barang(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_log->get_datatables_log_barang2();
        $data = array();     
            foreach($list as $field){
                $row = array();
                $row[] = $field->id_stock;
                $row[] = $field->nama_model;
                $row[] = $field->sn;
                $row[] = $field->id_aset;
                if($field->status_log == '0'){
                    $row[] = '<span class="badge badge-pill badge-primary">Stok</span>';
                }elseif($field->status_log == '1'){
                    $row[] = '<span class="badge badge-pill badge-success">Terpasang</span>';
                }elseif($field->status_log == '3'){
                    $row[] = '<span class="badge badge-pill badge-warning">Rusak IT</span>';
                }else{
                    $row[] = '<span class="badge badge-pill badge-danger">Rusak Vendor</span>';
                }
                $row[] = $field->nama_supplier;
                $row[] = $field->tgl;
                $row[] = $field->po_srt_jln;
                $row[] = $field->keterangan;
                $row[] = $field->nama_user;
                $row[] = $field->created_at;
                $data[] = $row;
            }        
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $this->m_log->count_all_log(),
            "recordsFiltered" => $this->m_log->count_filtered_log(),
            "data" => $data,
        );
        //output dalam format JSON
        echo json_encode($output);
    }

}
