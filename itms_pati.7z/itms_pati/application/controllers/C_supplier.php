<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_supplier extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(array('m_supplier'));
    }

	function index(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('supplier/v_master_supplier');
        $this->load->view('_template/footer');
    }

    function get_master_supplier(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_supplier->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->nama_supplier;
            $row[] = $field->alamat_supplier;
            $row[] = $field->phone;
            $row[] = $field->created_at;
            $row[] = $field->updated_at;
            if($this->session->userdata('level_a') == '1' || $this->session->userdata('level_a') == '2'){
                $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="Edit" onclick="edit_supplier('."'".$field->id_supplier."'".')"><span class="fe fe-edit fe-16"><span></a>';
            }else{
                $row[] = '';
            }
            
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_supplier->count_all(),
            "recordsFiltered" => $this->m_supplier->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function add_supplier_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_supplier = 'hwp'.uniqid();
        $nama_supplier = $this->input->post('nama_supplier');
        $alamat_supplier = $this->input->post('alamat_supplier');
        $phone = $this->input->post('phone');
        $updated_at = date('Y-m-d H:i:s');

        $add = $this->m_supplier->add_supplier($id_supplier,$nama_supplier,$alamat_supplier,$phone,$updated_at);
        echo json_encode(array("status" => TRUE));
    }

    function edit_supplier_($id_supplier){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_supplier->get_supplier($id_supplier)->row();
        echo json_encode($data);
    }

    function update_supplier_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_supplier = $this->input->post('id_supplier');
        $nama_supplier = $this->input->post('nama_supplier');
        $alamat_supplier = $this->input->post('alamat_supplier');
        $phone = $this->input->post('phone');
        $updated_at = date('Y-m-d H:i:s');

        $update = $this->m_supplier->update_supplier($id_supplier,$nama_supplier,$alamat_supplier,$phone,$updated_at);
        echo json_encode(array("status"=>TRUE));
    }

    function cek_supplier($id_supplier){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_supplier->get_supplier($id_supplier);
        header('Content-Type: application/json');
        if($data->num_rows() > '0'){
            echo json_encode(array('status'=>'ok', 'data'=>($data->row())));
        }else{
            echo json_encode(array('status'=>'error', 'msg'=>'Supplier tidak ditemukan'));
        }
    }

}