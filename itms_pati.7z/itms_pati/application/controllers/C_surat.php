<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_surat extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(array('m_surat','m_surat_log','m_lokasi'));
    }

	function kategori_surat(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $this->load->view('_template/header');
        $this->load->view('surat/v_kategori_surat');
        $this->load->view('_template/footer');
    }
    
    function get_kategori_surat(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_surat->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->id_kategori;
            $row[] = $field->nama_kategori;
            $row[] = $field->created_at;
            $row[] = $field->updated_at;
            if($this->session->userdata('level_a') == '1' || $this->session->userdata('level_a') == '2'){
                $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="javascript:void(0)" title="Edit" onclick="edit_kategori('."'".$field->id_kategori."'".')"><span class="fe fe-edit fe-16"><span></a>';
            }else{
                $row[] = '';
            }
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_surat->count_all(),
            "recordsFiltered" => $this->m_surat->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function add_kategori_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $nama_kategori = $this->input->post('nama_kategori');
        $updated_at = date('Y-m-d H:i:s');

        $cek_kategori = $this->m_surat->cek_kategori();
        if(($cek_kategori->num_rows()) == '0'){
            $id_kategori = 100;
        }else{
            $kode = $cek_kategori->row();
            $id_kategori = ($kode->id_kategori)+1;
        }

        $add = $this->m_surat->add_kategori($id_kategori,$nama_kategori,$updated_at);
        echo json_encode(array("status" => TRUE));
    }

    function edit_kategori_($id_kategori){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_surat->get_data_kategori($id_kategori)->row();
        echo json_encode($data);
    }

    function update_kategori_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_kategori = $this->input->post('id_kategori');
        $nama_kategori = $this->input->post('nama_kategori');
        $updated_at = date('Y-m-d H:i:s');

        $this->m_surat->update_kategori($id_kategori,$nama_kategori,$updated_at);
        echo json_encode(array("status" => TRUE));
    }

    function master_surat(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }
        
        $this->load->view('_template/header');
        $this->load->view('surat/v_master_surat');
        $this->load->view('_template/footer');
    }

    function get_master_surat(){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_surat->get_datatables_surat();
        $data = array();
        $no = $_POST['start'];
        foreach($list as $field){
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->nama_user;
            $row[] = $field->nama_lokasi;
            $row[] = $field->detail_dept;
            $row[] = $field->nama_posisi;
            $row[] = $field->nama_kategori;
            $row[] = $field->deskripsi;
            $row[] = $field->tanggal_masuk;
            $row[] = $field->tanggal_approve;
            if($field->status == '0'){
                $row[] = '<span class="badge badge-pill badge-danger">Open</span>';
            }elseif($field->status == '1'){
                $row[] = '<span class="badge badge-pill badge-warning">Pending</span>';
            }elseif($field->status == '2'){
                $row[] = '<span class="badge badge-pill badge-success">Done</span>';
            }else{
                $row[] = '<span class="badge badge-pill badge-dark">Cancel/Reject</span>';
            }
            //$row[] = '<a href="javascript:void(0)" title="preview" onclick="preview_surat('."'".$field->file_surat."'".')">'.$field->file_surat.'</a>';
            $row[] = '<a href="'.base_url().'assets/file_surat/'.$field->file_surat.'" target="_blank">'.$field->file_surat.'</a>';
            if($this->session->userdata('level_a') == '1' || $this->session->userdata('level_a') == '2'){
                $row[] = '<a class="btn mb-1 btn-warning btn-sm" href="'.base_url().'index.php/c_surat/update_surat/'.$field->id_surat.'" title="Update"><span class="fe fe-edit fe-16"><span></a>
                <a class="btn mb-1 btn-secondary btn-sm" href="'.base_url().'index.php/c_surat/detail_log/'.$field->id_surat.'" title="History"><span class="fe fe-clock fe-16"><span></a>';
            }else{
                $row[] = '<a class="btn mb-1 btn-default btn-sm" href="'.base_url().'index.php/c_surat_log/detail_log/'.$field->id_surat.'" title="History"><span class="fe fe-clock fe-16"><span></a>';
            }
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_surat->count_all_surat(),
            "recordsFiltered" => $this->m_surat->count_filtered_surat(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function add_surat(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $departemen = $this->m_lokasi->get_all_lokasi()->result();
        $kategori = $this->m_surat->cek_kategori()->result();
        $posisi = $this->m_surat->get_all_posisi()->result();
        $this->load->view('_template/header');
        $this->load->view('surat/v_add_surat',array('departemen'=>$departemen,'kategori'=>$kategori,'posisi'=>$posisi));
        $this->load->view('_template/footer');
    }

    function add_surat_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $nama_user = $this->input->post('nama_user');
        $departemen = $this->input->post('departemen');
        $detail_dept = $this->input->post('detail_dept');
        $posisi_user = $this->input->post('posisi_user');
        $kategori_surat = $this->input->post('kategori_surat');
        $deskripsi = $this->input->post('deskripsi');
        $tanggal_masuk = $this->input->post('tanggal_masuk');
        $status = $this->input->post('status');
        $updated_at = date('Y-m-d H:i:s');        
       
        $cek_surat = $this->m_surat->cek_surat();
        if(($cek_surat->num_rows()) == '0'){
            $id_surat = 'ITSRT00001';
        }else{
            $data = $cek_surat->row();
            $id_terakhir = $data->id_surat;
            $auto = substr($id_terakhir,5,5);

            $temp = $auto+1;
            if($temp<10){
                $id_surat = 'ITSRT0000'.$temp;
            }elseif($temp<100){
                $id_surat = 'ITSRT000'.$temp;
            }elseif($temp<1000){
                $id_surat = 'ITSRT00'.$temp;
            }elseif($temp<10000){
                $id_surat = 'ITSRT0'.$temp;
            }else{
                $id_surat = 'ITSRT'.$temp;
            }
        }

        $config['upload_path']          = './assets/file_surat/';
        $config['allowed_types']        = 'pdf';
        $config['max_size']             = 5000;
        $config['file_name']            = $id_surat;

        $this->load->library('upload', $config);

        if(!$this->upload->do_upload('file_surat')){
            $error = array('error' => $this->upload->display_errors());
            $this->session->set_flashdata(array('status'=>'danger','msg'=>'File gagal diupload'));
            redirect('c_surat/master_surat');
        }else{
            $data = array('upload_data' => $this->upload->data());
            $file_surat = $id_surat.'.pdf';

            if($status == '1' || $status == '3'){
                $keterangan = $this->input->post('keterangan');
                $insert = $this->m_surat->add_surat_1($id_surat,$nama_user,$departemen,$detail_dept,$posisi_user,
                $kategori_surat,$deskripsi,$tanggal_masuk,$status,$file_surat,$updated_at);
            }elseif($status == '2'){
                $tanggal_approve = $this->input->post('tanggal_approve');
                $keterangan = '';
                $insert = $this->m_surat->add_surat_2($id_surat,$nama_user,$departemen,$detail_dept,$posisi_user,
                $kategori_surat,$deskripsi,$tanggal_masuk,$tanggal_approve,$status,$file_surat,$updated_at);
            }else{
                $keterangan = '';
                $insert = $this->m_surat->add_surat_1($id_surat,$nama_user,$departemen,$detail_dept,$posisi_user,
                $kategori_surat,$deskripsi,$tanggal_masuk,$status,$file_surat,$updated_at);
            }
            $id_log = uniqid();
            $id_user = $this->session->userdata('username_a');
            $this->m_surat_log->insert_log($id_log,$id_surat,$status,$id_user,$keterangan);

            $this->session->set_flashdata(array('status'=>'success','msg'=>'Surat berhasil ditambahkan'));
            redirect('c_surat/master_surat');
        }
    }

    function update_surat($id_surat){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $data = $this->m_surat->get_by_id($id_surat)->row();
        $dept = $data->departemen;
        $kat = $data->kategori_surat;
        $pos_user = $data->posisi_user;
        $departemen = $this->m_surat->dept_by_id($dept)->result();
        $kategori = $this->m_surat->kat_by_id($kat)->result();
        $posisi = $this->m_surat->pos_by_id($pos_user)->result();
        $this->load->view('_template/header');
        $this->load->view('surat/v_update_surat',array('data'=>$data,'departemen'=>$departemen,'kategori'=>$kategori,'posisi'=>$posisi));
        $this->load->view('_template/footer');
    }

    function update_surat_process(){
        if($this->session->userdata('level_a') != '1' && $this->session->userdata('level_a') != '2'){
            redirect('c_user/logout');
        }

        $id_surat = $this->input->post('id_surat');
        $nama_user = $this->input->post('nama_user');
        $departemen = $this->input->post('departemen');
        $detail_dept = $this->input->post('detail_dept');
        $posisi_user = $this->input->post('posisi_user');
        $kategori_surat = $this->input->post('kategori_surat');
        $deskripsi = $this->input->post('deskripsi');
        $tanggal_masuk = $this->input->post('tanggal_masuk');
        $status = $this->input->post('status');
        $updated_at = date('Y-m-d H:i:s');

        if($_FILES['file_surat']['name'] != ''){
            //hapus file          
            $config['upload_path']          = './assets/file_surat/';
            unlink(FCPATH.$config['upload_path'].$id_surat.'.pdf');

            $config['allowed_types']        = 'pdf';
            $config['max_size']             = 5000;
            $config['file_name']            = $id_surat;

            $this->load->library('upload', $config);

            if(!$this->upload->do_upload('file_surat')){
                $error = array('error' => $this->upload->display_errors());
                $this->session->set_flashdata(array('status'=>'danger','msg'=>'File gagal diupload'));
                redirect('c_surat/master_surat');
            }else{
                $data = array('upload_data' => $this->upload->data());
                $file_surat = $id_surat.'.pdf';
    
                if($status == '1' || $status == '3'){
                    $keterangan = $this->input->post('keterangan');
                    $this->m_surat->update_surat_1($id_surat,$nama_user,$departemen,$detail_dept,$posisi_user,
                    $kategori_surat,$deskripsi,$tanggal_masuk,$status,$updated_at);
                }elseif($status == '2'){
                    $tanggal_approve = $this->input->post('tanggal_approve');
                    $keterangan = '';
                    $this->m_surat->update_surat_2($id_surat,$nama_user,$departemen,$detail_dept,$posisi_user,
                    $kategori_surat,$deskripsi,$tanggal_masuk,$tanggal_approve,$status,$updated_at);
                }else{
                    $keterangan = '';
                    $this->m_surat->update_surat_1($id_surat,$nama_user,$departemen,$detail_dept,$posisi_user,
                    $kategori_surat,$deskripsi,$tanggal_masuk,$status,$updated_at);
                }
                $id_log = uniqid();
                $id_user = $this->session->userdata('username_a');
                $this->m_surat_log->insert_log($id_log,$id_surat,$status,$id_user,$keterangan);
    
                $this->session->set_flashdata(array('status'=>'success','msg'=>'Surat berhasil diupdate'));
                redirect('c_surat/master_surat');
            }
        }else{
            if($status == '1' || $status == '3'){
                $keterangan = $this->input->post('keterangan');
                $this->m_surat->update_surat_1($id_surat,$nama_user,$departemen,$detail_dept,$posisi_user,
                $kategori_surat,$deskripsi,$tanggal_masuk,$status,$updated_at);
            }elseif($status == '2'){
                $tanggal_approve = $this->input->post('tanggal_approve');
                $keterangan = '';
                $this->m_surat->update_surat_2($id_surat,$nama_user,$departemen,$detail_dept,$posisi_user,
                $kategori_surat,$deskripsi,$tanggal_masuk,$tanggal_approve,$status,$updated_at);
            }else{
                $keterangan = '';
                $this->m_surat->update_surat_1($id_surat,$nama_user,$departemen,$detail_dept,$posisi_user,
                $kategori_surat,$deskripsi,$tanggal_masuk,$status,$updated_at);
            }
            $id_log = uniqid();
            $id_user = $this->session->userdata('username_a');
            $this->m_surat_log->insert_log($id_log,$id_surat,$status,$id_user,$keterangan);

            $this->session->set_flashdata(array('status'=>'success','msg'=>'Surat berhasil diupdate'));
            redirect('c_surat/master_surat');
        }
    }

    function detail_log($id_surat){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }
        
        $this->load->view('_template/header');
        $this->load->view('surat/v_detail_log',array('id_surat'=>$id_surat));
        $this->load->view('_template/footer');
    }

    function get_detail_log($id_surat){
        if($this->session->userdata('level_a') == ''){
            redirect('c_user/logout');
        }

        $list = $this->m_surat_log->get_datatables($id_surat);
        $data = array();
        $no = @$_POST['start'];        
            foreach($list as $field){
                $no++;
                $row = array();
                $row[] = $no;
                $row[] = $field->nama_user;
                $row[] = $field->nama_lokasi;
                $row[] = $field->nama_kategori;
                $row[] = $field->deskripsi;
                if($field->status == '0'){
                    $row[] = '<span class="badge badge-pill badge-danger">Open</span>';
                }elseif($field->status == '1'){
                    $row[] = '<span class="badge badge-pill badge-warning">Pending</span>';
                }elseif($field->status == '2'){
                    $row[] = '<span class="badge badge-pill badge-success">Done</span>';
                }else{
                    $row[] = '<span class="badge badge-pill badge-dark">Cancel/Reject</span>';
                }
                $row[] = $field->keterangan;
                $row[] = $field->created_at;
                $data[] = $row;
            }        
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $this->m_surat_log->count_all($id_surat),
            "recordsFiltered" => $this->m_surat_log->count_filtered($id_surat),
            "data" => $data,
        );
        //output dalam format JSON
        echo json_encode($output);
    }
}