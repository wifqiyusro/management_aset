<?php
class M_surat_jalan extends CI_Model{

    var $table = 'surat_jalan';
	var $column_order = array(null, 'sj.surat_jalan','sj.packing_list','sj.tanggal','s.nama_supplier','sj.pengirim','sj.keterangan','sj.status','sj.created_at','sj.updated_at');
    var $column_search = array('sj.surat_jalan','sj.packing_list','sj.tanggal','s.nama_supplier','sj.pengirim','sj.keterangan','sj.status','sj.created_at','sj.updated_at');
    var $order = array('sj.created_at' => 'desc');

    function get_datatables_surat_jalan(){
        $this->db->select("sj.*,s.id_supplier,s.nama_supplier");
        $this->db->from("surat_jalan sj");
        $this->db->join("supplier s","sj.supplier=s.id_supplier");
        $i = 0;
        foreach ($this->column_search as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables(){
        $this->get_datatables_surat_jalan();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered(){
        $this->get_datatables_surat_jalan();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all(){
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

    function add_surat_jalan($id_surat_jalan,$surat_jalan,$packing_list,$tanggal,$supplier,$pengirim,$keterangan,$updated_at){
        $query = $this->db->query("
            INSERT INTO surat_jalan(id_surat_jalan,surat_jalan,packing_list,tanggal,supplier,pengirim,keterangan,status,updated_at)
            VALUES ('$id_surat_jalan','$surat_jalan','$packing_list','$tanggal','$supplier','$pengirim','$keterangan','0','$updated_at')
        ");
        return $query;
    }

    function get_data_surat_jalan($id_surat_jalan){
        $query = $this->db->query("
            SELECT sj.*, s.id_supplier, s.nama_supplier, s.phone, s.alamat_supplier
            FROM surat_jalan sj
            JOIN supplier s ON s.id_supplier = sj.supplier
            WHERE sj.id_surat_jalan = '$id_surat_jalan'
        ");
        return $query;
    }

    function update_surat_jalan($id_surat_jalan,$surat_jalan,$packing_list,$tanggal,$supplier,$pengirim,$keterangan,$updated_at){
        $query = $this->db->query("
            UPDATE surat_jalan SET surat_jalan = '$surat_jalan',packing_list = '$packing_list',tanggal='$tanggal',supplier='$supplier',pengirim='$pengirim',keterangan='$keterangan',updated_at = '$updated_at'
            WHERE id_surat_jalan = '$id_surat_jalan'
        ");
        return $query;
    }

    function get_surat_jalan(){
        $query = $this->db->query("
            SELECT * FROM surat_jalan WHERE status = '0' ORDER BY created_at DESC
        ");
        return $query;
    }

    function get_data_barang($id_stok){
        $query = $this->db->query("
            SELECT s.id_stok, j.nama_jenis_barang, b.nama_model, s.sn, t.no_po, p.nama_proyek, s.jenis_aset
            FROM stock_barang s
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            LEFT JOIN transaksi_pembelian t ON t.id_transaksi = s.id_transaksi
            LEFT JOIN master_proyek p ON p.id_proyek = s.id_transaksi
            WHERE s.id_stok = '$id_stok' AND s.jenis_aset NOT IN ('7','8')
        ");
        return $query;
    }

    function cek_data($surat_jalan,$id_stok_b){
        $query = $this->db->query("
            SELECT * FROM data_surat_jalan d
            JOIN surat_jalan sj ON sj.id_surat_jalan = d.id_surat_jalan
            WHERE sj.id_surat_jalan = '$surat_jalan' AND d.qr = '$id_stok_b' AND sj.status = '0'
        ");
        return $query;
    }

    function tambah_barang_sj($id_stok_b,$surat_jalan,$nama_jenis_barang,$nama_model,$qty,$sn,$no_po,$kategori,$keterangan_barang,$netto,$gross,$volume,$ip,$id_user){
        $query = $this->db->query("
            INSERT INTO data_surat_jalan(id_surat_jalan,nama_jenis_barang,nama_model,sn,unit,qty,qr,no_po,kategori,keterangan,netto,gross,volume,ip,users)
            VALUES('$surat_jalan','$nama_jenis_barang','$nama_model','$sn','EA','$qty','$id_stok_b','$no_po','$kategori','$keterangan_barang','$netto','$gross','$volume','$ip','$id_user')
        ");
        return $query;
    }

    function get_datatabel($surat_jalan,$tgl,$ip){
        $query = $this->db->query("
            SELECT d.*,
            CASE
                WHEN d.kategori = '0' THEN 'Service'
                ELSE 'Return'
            END AS kategori_sj
            FROM data_surat_jalan d
            JOIN surat_jalan sj ON sj.id_surat_jalan = d.id_surat_jalan
            WHERE d.id_surat_jalan = '$surat_jalan' AND CONVERT(CHAR(8), d.created_at, 112) = '$tgl' AND ip = '$ip'
        ");
        return $query;
    }

    function hapus_barang($id_surat_jalan,$qr){
        $query = $this->db->query("
            DELETE FROM data_surat_jalan WHERE id_surat_jalan = '$id_surat_jalan' AND qr = '$qr'
        ");
        return $query;
    }

    function get_qr(){
        $query = $this->db->query("
            SELECT SUBSTRING(qr,3,4) AS urut FROM data_surat_jalan
            WHERE SUBSTRING(qr,1,2) = 'NA' ORDER BY created_at DESC
        ");
        return $query;
    }

    function konfirmasi_sj($id_surat_jalan,$updated_at){
        $query = $this->db->query("
            UPDATE surat_jalan SET status = '1', updated_at = '$updated_at' WHERE id_surat_jalan = '$id_surat_jalan'
        ");
        return $query;
    }

    function get_sj_close(){
        $query = $this->db->query("
            SELECT * FROM surat_jalan WHERE status = '1'
        ");
        return $query;
    }

    function get_detail_sj($id_surat_jalan){
        $query = $this->db->query("
            SELECT sj.*, d.*
            FROM data_surat_jalan d
            JOIN surat_jalan sj ON sj.id_surat_jalan = d.id_surat_jalan
            WHERE d.id_surat_jalan = '$id_surat_jalan'
        ");
        return $query;
    }
}
?>