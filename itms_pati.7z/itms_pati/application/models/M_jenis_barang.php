<?php
class M_jenis_barang extends CI_Model{

    var $table = 'jenis_barang';
	var $column_order = array(null, 'id_jenis_barang','nama_jenis_barang','jenis_aset','label_jns_barang','created_at','updated_at');
    var $column_search = array('id_jenis_barang','nama_jenis_barang','jenis_aset','label_jns_barang','created_at','updated_at');
    var $order = array('nama_jenis_barang' => 'asc');

    function get_datatables_jenis_barang(){
        $this->db->select("*");
        $this->db->from("jenis_barang");
        $i = 0;
        foreach ($this->column_search as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables(){
        $this->get_datatables_jenis_barang();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered(){
        $this->get_datatables_jenis_barang();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all(){
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
    
    function get_all(){
        $query = $this->db->query("SELECT * FROM jenis_barang ORDER BY nama_jenis_barang ASC");
        return $query;
    }

    function get_jenis_barang_rental(){
        $query = $this->db->query("SELECT * FROM jenis_barang WHERE jenis_aset = '1' ORDER BY nama_jenis_barang ASC");
        return $query;
    }

    function get_jenis_barang_po(){
        $query = $this->db->query("SELECT * FROM jenis_barang WHERE jenis_aset = '0' ORDER BY nama_jenis_barang ASC");
        return $query;
    }

	function get_jenis_barang($kode){
        $query = $this->db->query("SELECT * FROM jenis_barang WHERE kel_asset = '$kode'");
        return $query;
    }

    function get_nama($kode){
        $query = $this->db->query("SELECT nama_aset FROM kelompok_aset WHERE kode = '$kode'");
        return $query;
    }

    function get_label($id_jenis_barang){
        $query = $this->db->query("SELECT * FROM jenis_barang WHERE id_jenis_barang = '$id_jenis_barang'");
        return $query;
    }

    function add_jenis_barang($id_jenis_barang,$nama_jenis_barang,$jenis_aset,$label_jns_barang,$kel_aset,$updated_at){
        $query = $this->db->query("INSERT INTO jenis_barang(id_jenis_barang,nama_jenis_barang,jenis_aset,label_jns_barang,kel_asset,updated_at)
        VALUES('$id_jenis_barang','$nama_jenis_barang','$jenis_aset','$label_jns_barang','$kel_aset','$updated_at')");
        return $query;
    }

    function update_jenis_barang($id_jenis_barang,$nama_jenis_barang,$jenis_aset,$label_jns_barang,$kel_aset,$updated_at){
        $query = $this->db->query("UPDATE jenis_barang SET nama_jenis_barang='$nama_jenis_barang',jenis_aset='$jenis_aset',label_jns_barang='$label_jns_barang',kel_asset='$kel_aset',updated_at='$updated_at' WHERE id_jenis_barang='$id_jenis_barang'");
        return $query;
    }

    function update_label_barang($id_jenis_barang,$label_jns_barang,$updated_at){
        $query = $this->db->query("UPDATE barang SET label_jenis_barang='$label_jns_barang',updated_at='$updated_at' WHERE id_jenis_barang='$id_jenis_barang'");
        return $query;
    }

    function get_jenis_barang_proyek(){
        $query = $this->db->query("SELECT * FROM jenis_barang WHERE jenis_aset='2' ORDER BY nama_jenis_barang ASC");
        return $query;
    }

    function get_kel_aset(){
        $query = $this->db->query("SELECT kode,nama_aset FROM kelompok_aset ORDER BY nama_aset ASC");
        return $query;
    }

    function get_data_kel_aset(){
        $query = $this->db->query("SELECT * FROM kelompok_aset ORDER BY kode DESC");
        return $query;
    }

    function get_nama_aset($kode){
        $query = $this->db->query("
            SELECT * FROM kelompok_aset WHERE kode = '$kode'
        ");
        return $query;
    }

    var $table_aset = 'kelompok_aset';
	var $column_order_aset = array(null,'kode','nama_aset','created_at','updated_at');
    var $column_search_aset = array('kode','nama_aset','created_at','updated_at');
    var $order_aset = array('kode' => 'asc');

    function get_datatables_kelompok_aset(){
        $this->db->select("*");
        $this->db->from("kelompok_aset");
        $i = 0;
        foreach ($this->column_search_aset as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search_aset) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order_aset[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order_aset)){
            $order = $this->order_aset;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables_aset(){
        $this->get_datatables_kelompok_aset();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_aset(){
        $this->get_datatables_kelompok_aset();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_aset(){
        $this->db->from($this->table_aset);
        return $this->db->count_all_results();
    }

    function add_kelompok_aset($kode,$nama_aset,$updated_at){
        $query = $this->db->query("
            INSERT INTO kelompok_aset(kode,nama_aset,updated_at)
            VALUES('$kode','$nama_aset','$updated_at')
        ");
        return $query;
    }

    function get_kelompok_aset($kode){
        $query = $this->db->query("
            SELECT * FROM kelompok_aset WHERE kode = '$kode'
        ");
        return $query;
    }

    function update_kelompok_aset($kode,$nama_aset,$updated_at){
        $query = $this->db->query("
            UPDATE kelompok_aset SET nama_aset = '$nama_aset', updated_at = '$updated_at' WHERE kode = '$kode'
        ");
        return $query;
    }
}
?>