<?php
class M_po extends CI_Model{

	var $column_order = array(null, 'p.id_po','p.no_po','p.tanggal_po','s.nama_supplier','p.dept','p.keperluan','p.created_at','p.updated_at');
    var $column_search = array('p.id_po','p.no_po','p.tanggal_po','s.nama_supplier','p.dept','p.keperluan','p.created_at','p.updated_at');
    var $order = array('p.created_at' => 'desc');

    function get_datatables_po(){
        $this->db->select("p.*,s.nama_supplier");
        $this->db->from("master_po p");
        $this->db->join("supplier s","p.id_supplier=s.id_supplier");
        $this->db->where("p.jenis_po =",1);
        $i = 0;
        foreach ($this->column_search as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables(){
        $this->get_datatables_po();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered(){
        $this->get_datatables_po();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all(){
        $this->db->select("*");
        $this->db->from("master_po");
        $this->db->where("jenis_po = '1'");
        return $this->db->count_all_results();
    }

    function get_po(){
        $query = $this->db->query("
            SELECT p.*,s.nama_supplier,s.alamat_supplier,s.phone
            FROM master_po p
            JOIN supplier s ON s.id_supplier = p.id_supplier
            WHERE p.jenis_po = '1'
        ");
        return $query;
    }

    function get_po_row($id_po){
        $query = $this->db->query("
            SELECT p.*,s.nama_supplier,s.alamat_supplier,s.phone
            FROM master_po p
            JOIN supplier s ON s.id_supplier = p.id_supplier
            WHERE jenis_po = '1' AND p.id_po = '$id_po'
        ");
        return $query;
    }

    function get_po_cms(){
        $query = $this->db->query("
            SELECT p.*,s.nama_supplier,s.alamat_supplier,s.phone
            FROM master_po p
            JOIN supplier s ON s.id_supplier = p.id_supplier
            WHERE p.jenis_po = '2'
        ");
        return $query;
    }

    function get_po_cms_2($id_po){
        $query = $this->db->query("
            SELECT p.*,s.nama_supplier,s.alamat_supplier,s.phone
            FROM master_po p
            JOIN supplier s ON s.id_supplier = p.id_supplier
            WHERE p.id_po = '$id_po' AND p.jenis_po = '2'
        ");
        return $query;
    }

    function get_data_po($id_po){
        $query = $this->db->query("
            SELECT p.*, s.nama_supplier FROM master_po p
            JOIN supplier s ON s.id_supplier = p.id_supplier
            WHERE id_po = '$id_po' AND p.jenis_po = '1'
        ");
        return $query;
    }

    function insert_po_aset($id_po,$no_po,$tanggal_po,$id_supplier,$jenis_po,$departemen,$tgl_approval,$keperluan,$updated_at){
        $query = $this->db->query("
            INSERT INTO master_po (id_po,no_po,tanggal_po,id_supplier,jenis_po,dept,tgl_approval,keperluan,updated_at)
            VALUES ('$id_po','$no_po','$tanggal_po','$id_supplier','$jenis_po','$departemen','$tgl_approval','$keperluan','$updated_at')
        ");
        return $query;
    }

    function update_po_aset($id_po,$no_po,$tanggal_po,$id_supplier,$keperluan,$updated_at){
        $query = $this->db->query("
            UPDATE master_po SET no_po='$no_po',tanggal_po='$tanggal_po',id_supplier='$id_supplier',keperluan='$keperluan',updated_at='$updated_at' WHERE id_po='$id_po'
        ");
        return $query;
    }

    function get_datatables_po_cms(){
        $this->db->select("p.*,s.nama_supplier");
        $this->db->from("master_po p");
        $this->db->join("supplier s","p.id_supplier=s.id_supplier");
        $this->db->where("p.jenis_po =",2);
        $i = 0;
        foreach ($this->column_search as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables_cms(){
        $this->get_datatables_po_cms();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_cms(){
        $this->get_datatables_po_cms();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_cms(){
        $this->db->select("*");
        $this->db->from("master_po");
        $this->db->where("jenis_po = '2'");
        return $this->db->count_all_results();
    }

    function add_po_cms($id_po,$no_po,$jenis_po,$tanggal_po,$id_supplier,$keperluan,$updated_at){
        $query = $this->db->query("
            INSERT INTO master_po(id_po,no_po,jenis_po,tanggal_po,id_supplier,keperluan,updated_at)
            VALUES('$id_po','$no_po','$jenis_po','$tanggal_po','$id_supplier','$keperluan','$updated_at')
        ");
        return $query;
    }

    function get_data_po_cms($id_po){
        $query = $this->db->query("SELECT * FROM master_po WHERE id_po = '$id_po'");
        return $query;
    }

    function update_po_cms($id_po,$no_po,$tanggal_po,$id_supplier,$keperluan,$updated_at){
        $query = $this->db->query("
            UPDATE master_po SET no_po = '$no_po',tanggal_po = '$tanggal_po', id_supplier = '$id_supplier', keperluan = '$keperluan',
            updated_at = '$updated_at' WHERE id_po = '$id_po'
        ");
        return $query;
    }

    function get_datatables_po_service(){
        $this->db->select("p.*,s.nama_supplier");
        $this->db->from("master_po p");
        $this->db->join("supplier s","p.id_supplier=s.id_supplier");
        $this->db->where("p.jenis_po =",3);
        $i = 0;
        foreach ($this->column_search as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables_service(){
        $this->get_datatables_po_service();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_service(){
        $this->get_datatables_po_service();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_service(){
        $this->db->select("*");
        $this->db->from("master_po");
        $this->db->where("jenis_po = '3'");
        return $this->db->count_all_results();
    }

    function add_po_service($id_po,$no_po,$jenis_po,$tanggal_po,$id_supplier,$keperluan,$updated_at){
        $query = $this->db->query("
            INSERT INTO master_po(id_po,no_po,jenis_po,tanggal_po,id_supplier,keperluan,updated_at)
            VALUES('$id_po','$no_po','$jenis_po','$tanggal_po','$id_supplier','$keperluan','$updated_at')
        ");
        return $query;
    }

    function get_data_po_service($id_po){
        $query = $this->db->query("SELECT * FROM master_po WHERE id_po = '$id_po'");
        return $query;
    }

    function update_po_service($id_po,$no_po,$tanggal_po,$id_supplier,$keperluan,$updated_at){
        $query = $this->db->query("
            UPDATE master_po SET no_po = '$no_po',tanggal_po = '$tanggal_po', id_supplier = '$id_supplier', keperluan = '$keperluan',
            updated_at = '$updated_at' WHERE id_po = '$id_po'
        ");
        return $query;
    }

    function get_po_service(){
        $query = $this->db->query("
            SELECT p.*,s.nama_supplier,s.alamat_supplier,s.phone
            FROM master_po p
            JOIN supplier s ON s.id_supplier = p.id_supplier
            WHERE p.jenis_po = '3'
        ");
        return $query;
    }

    function get_po_service_2($id_po){
        $query = $this->db->query("
            SELECT p.*,s.nama_supplier,s.alamat_supplier,s.phone
            FROM master_po p
            JOIN supplier s ON s.id_supplier = p.id_supplier
            WHERE p.id_po = '$id_po' AND p.jenis_po = '3'
        ");
        return $query;
    }

    function get_service_po($id_po){
        $query = $this->db->query("
            SELECT * FROM master_po WHERE id_po = '$id_po' AND jenis_po = '3'
        ");
        return $query;
    }
}
?>