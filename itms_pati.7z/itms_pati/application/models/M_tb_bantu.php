<?php
class M_tb_bantu extends CI_Model{

    function cek_data_proyek($id_barang,$kode_epte,$kode_fa,$alokasi,$ip){
        $query = $this->db->query("SELECT * FROM tb_bantu_pembelian_proyek WHERE id_barang='$id_barang' AND epte_code = '$kode_epte' AND FA_code = '$kode_fa' 
        AND alokasi='$alokasi' AND ip='$ip'");
        return $query;
    }

	function tambah_barang_proyek($id_barang,$kode_epte,$kode_fa,$id_supplier,$jumlah,$alokasi,$keterangan,$ip,$updated_at){
        $query = $this->db->query("INSERT INTO tb_bantu_pembelian_proyek(id_barang,epte_code,FA_code,id_supplier,jumlah,alokasi,keterangan,ip,updated_at)
            VALUES('$id_barang','$kode_epte','$kode_fa','$id_supplier','$jumlah','$alokasi','$keterangan','$ip','$updated_at')
        ");
        return $query;
    }

    function get_datatabel_proyek($ip){
        $query = $this->db->query("
        SELECT j.id_jenis_barang, j.nama_jenis_barang, tb.*, b.*
        FROM tb_bantu_pembelian_proyek tb 
        JOIN barang b ON b.id_barang = tb.id_barang
        JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
        WHERE tb.ip = '$ip'
        ORDER BY tb.created_at DESC");
        return $query;
    }

    function hapus_barang_proyek($id_barang,$kode_epte,$kode_fa,$alokasi,$ip){
        $query = $this->db->query("DELETE FROM tb_bantu_pembelian_proyek WHERE id_barang = '$id_barang' AND epte_code = '$kode_epte' AND FA_code = '$kode_fa'
        AND alokasi = '$alokasi' AND [ip] = '$ip'");
        return $query;
    }

    function hapus_data_proyek($ip){
        $query = $this->db->query("DELETE FROM tb_bantu_pembelian_proyek WHERE ip = '$ip'");
        return $query;
    }

    function cek_data_rental($no_rental,$id_barang,$ip){
        $query = $this->db->query("SELECT * FROM tb_bantu_pembelian WHERE no_po = '$no_rental' AND id_barang='$id_barang' AND ip='$ip'");
        return $query;
    }

    function tambah_barang_rental($no_rental,$id_barang,$id_supplier,$jumlah,$kurs,$ppn,$pph,$harga_total,$ip,$updated_at){
        $query = $this->db->query("
            INSERT INTO tb_bantu_pembelian (no_po,id_barang,id_supplier,jumlah,kurs,ppn,pph,harga,ip,updated_at)
            VALUES ('$no_rental','$id_barang','$id_supplier','$jumlah','$kurs','$ppn','$pph','$harga_total','$ip','$updated_at')
        ");
        return $query;
    }

    function get_datatabel_rental($ip){
        $query = $this->db->query("
            SELECT j.id_jenis_barang, j.nama_jenis_barang, tb.*, b.*
            FROM tb_bantu_pembelian tb 
            JOIN barang b ON b.id_barang = tb.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            WHERE tb.ip = '$ip'
            ORDER BY tb.created_at DESC
        ");
        return $query;
    }

    function hapus_barang_rental($no_rental,$id_barang,$ip){
        $query = $this->db->query("DELETE FROM tb_bantu_pembelian WHERE no_po='$no_rental' AND id_barang='$id_barang' AND ip='$ip'");
        return $query;
    }

    function get_data_terakhir(){
        $query = $this->db->query("SELECT * FROM transaksi_pembelian ORDER BY id_transaksi DESC");
        return $query;
    }
    
    function get_data_terakhir_jepara(){
        $query = $this->db->query("SELECT * FROM itmsdata.itms.transaksi_pembelian ORDER BY id_transaksi DESC");
        return $query;
    }

    function ambil_total_harga($ip,$no_rental){
        $query = $this->db->query("
            SELECT
            kurs,SUM(harga) AS total_harga,
            SUM(CASE
                WHEN ppn = 'Yes' THEN harga+(harga*0.11)
                WHEN ppn = 'No' THEN harga
            END) AS total_harga_ppn,
            SUM(CASE
                WHEN pph = 'Yes' THEN harga+(harga*0.02)
                WHEN pph = 'No' THEN harga
            END) AS total_harga_pph
            FROM tb_bantu_pembelian WHERE ip = '$ip' AND no_po = '$no_rental'
            GROUP BY kurs
        ");
        return $query;
    }

    function insert_transaksi_pembelian($id_trs,$no_rental,$tanggal_rental,$no_surat_jalan,$kurs,$total_harga,$total_harga_ppn,$total_harga_pph){
        $query = $this->db->query("
            INSERT INTO transaksi_pembelian (id_transaksi,no_po,tanggal_po,no_surat_jalan,kurs,total,total_biaya_ppn,total_biaya_pph)
            VALUES ('$id_trs','$no_rental','$tanggal_rental','$no_surat_jalan','$kurs','$total_harga','$total_harga_ppn','$total_harga_pph')
        ");
        return $query;
    }

    function update_tb_bantu_rental($id_trs,$no_rental,$ip){
        $query = $this->db->query("UPDATE tb_bantu_pembelian SET id_transaksi = '$id_trs' WHERE no_po = '$no_rental' AND ip = '$ip'");
        return $query;
    }

    function get_tb_rental($ip,$no_rental){
        $query = $this->db->query("SELECT * FROM tb_bantu_pembelian WHERE ip = '$ip' AND no_po = '$no_rental'");
        return $query;
    }

    function copy_isi_rental($id_trs,$no_rental,$ip){
        $query = $this->db->query("
            INSERT INTO detail_transaksi_pembelian (id_transaksi,id_barang,id_supplier,jumlah,harga,created_at,updated_at)
            SELECT id_transaksi,id_barang,id_supplier,jumlah,harga,created_at,updated_at
            FROM tb_bantu_pembelian WHERE id_transaksi = '$id_trs' AND ip = '$ip' AND no_po = '$no_rental'
        ");
        return $query;
    }

    function delete_transaksi_rental($id_trs,$no_rental,$ip){
        $query = $this->db->query("DELETE FROM tb_bantu_pembelian WHERE id_transaksi = '$id_trs' AND ip = '$ip' AND no_po = '$no_rental'");
        return $query;
    }

    function insert_detail_po($id_temp,$id_transaksi,$id_po,$id_barang,$id_supplier,$kurs,$ppn,$pph,$harga_satuan,$estimasi_dtg,$jenis_aset,$updated_at){
        $query = $this->db->query("
            INSERT INTO detail_po (id_temp,id_transaksi,id_po,id_barang,id_supplier,kurs,ppn,pph,harga,estimasi_dtg,jenis_aset,updated_at)
            VALUES ('$id_temp','$id_transaksi','$id_po','$id_barang','$id_supplier','$kurs','$ppn','$pph','$harga_satuan','$estimasi_dtg','$jenis_aset','$updated_at')
        ");
        return $query;
    }

    function cek_po_aset($id_po,$id_barang,$epte_code,$fa_code,$alokasi,$ip){
        $query = $this->db->query("SELECT * FROM tb_bantu_pembelian WHERE no_po = '$id_po' AND id_barang = '$id_barang' AND epte_code = '$epte_code' AND FA_code = '$fa_code' AND alokasi = '$alokasi' AND ip = '$ip'");
        return $query;
    }

    function tambah_barang_po_aset($id_po,$tanggal_po,$id_barang,$epte_code,$fa_code,$id_supplier,$jumlah,$kurs,$harga_total,$estimasi_dtg,$biaya_kirim,$ppn,$pph,$alokasi,$ip,$updated_at){
        $query = $this->db->query("
            INSERT INTO tb_bantu_pembelian(no_po,tgl_po,id_barang,epte_code,FA_code,id_supplier,jumlah,kurs,harga,estimasi_dtg,biaya_kirim,ppn,pph,alokasi,ip,updated_at)
            VALUES('$id_po','$tanggal_po','$id_barang','$epte_code','$fa_code','$id_supplier','$jumlah','$kurs','$harga_total','$estimasi_dtg','$biaya_kirim','$ppn','$pph','$alokasi','$ip','$updated_at')
        ");
        return $query;
    }

    function get_datatabel_po_aset($ip){
        $query = $this->db->query("
            SELECT tb.*, b.*
            FROM tb_bantu_pembelian tb 
            JOIN barang b ON b.id_barang = tb.id_barang
            WHERE tb.ip = '$ip' AND tb.alokasi != ''
            ORDER BY tb.created_at DESC
        ");
        return $query;
    }

    function hapus_barang_po_aset($id_po,$id_barang,$kode_epte,$kode_fa,$alokasi,$ip){
        $query = $this->db->query("DELETE FROM tb_bantu_pembelian WHERE no_po = '$id_po' AND id_barang='$id_barang' 
        AND epte_code = '$kode_epte' AND FA_code = '$kode_fa' AND alokasi = '$alokasi' AND ip = '$ip'");
        return $query;
    }

    function insert_transaksi_pembelian_po_aset($id_trs,$no_po,$tanggal_po,$estimasi_dtg,$kurs,$total_harga,$total_harga_ppn,$total_harga_pph){
        $query = $this->db->query("
            INSERT INTO transaksi_pembelian(id_transaksi,no_po,tanggal_po,estimasi_dtg,kurs,total,total_biaya_ppn,total_biaya_pph)
            VALUES('$id_trs','$no_po','$tanggal_po','$estimasi_dtg','$kurs','$total_harga','$total_harga_ppn','$total_harga_pph')
        ");
        return $query;
    }

    function update_tb_bantu_po_aset($id_trs,$id_po,$ip){
        $query = $this->db->query("
            UPDATE tb_bantu_pembelian SET id_transaksi = '$id_trs' WHERE no_po = '$id_po' AND ip = '$ip'
        ");
        return $query;
    }

    function get_tb_po_aset($ip,$id_po){
        $query = $this->db->query("SELECT * FROM tb_bantu_pembelian WHERE ip = '$ip' AND no_po = '$id_po'");
        return $query;
    }

    function insert_detail_po_aset($id_temp,$id_transaksi,$id_po,$tanggal_po,$id_barang,$kode_epte,$kode_fa,$id_supplier,$kurs,$ppn,$pph,$harga_satuan,$estimasi_dtg,$jenis_aset,$alokasi,$updated_at){
        $query = $this->db->query("
            INSERT INTO detail_po(id_temp,id_transaksi,id_po,tgl_po,id_barang,epte_code,FA_code,id_supplier,kurs,ppn,pph,harga,estimasi_dtg,jenis_aset,alokasi,updated_at)
            VALUES('$id_temp','$id_transaksi','$id_po','$tanggal_po','$id_barang','$kode_epte','$kode_fa','$id_supplier','$kurs','$ppn','$pph','$harga_satuan','$estimasi_dtg','$jenis_aset','$alokasi','$updated_at')
        ");
        return $query;
    }

    function copy_isi_po_aset($id_trs,$id_po,$ip){
        $query = $this->db->query("
            INSERT INTO detail_transaksi_pembelian (id_transaksi,id_barang,epte_code,FA_code,id_supplier,jumlah,harga,created_at,updated_at)
            SELECT id_transaksi,id_barang,epte_code,FA_code,id_supplier,jumlah,harga,created_at,updated_at
            FROM tb_bantu_pembelian WHERE id_transaksi = '$id_trs' AND ip = '$ip' AND no_po = '$id_po'
        "); 
        return $query;
    }

    function delete_transaksi_po_aset($id_trs,$id_po,$ip){
        $query = $this->db->query("
            DELETE FROM tb_bantu_pembelian WHERE id_transaksi = '$id_trs' AND ip = '$ip' AND no_po = '$id_po'
        ");
        return $query;
    }

    function cek_data_cms($kode_barang,$ip){
        $query = $this->db->query("
            SELECT * FROM tb_po_cms WHERE kode_barang = '$kode_barang' AND ip = '$ip'
        ");
        return $query;
    }

    function tambah_barang_cms($id_kategori,$kode_barang,$id_po,$id_supplier,$kurs,$harga_total,$jumlah,$ip){
        $query = $this->db->query("
            INSERT INTO tb_po_cms(kode_barang,kategori,id_po,id_supplier,kurs,harga,jumlah,ip)
            VALUES('$kode_barang','$id_kategori','$id_po','$id_supplier','$kurs','$harga_total','$jumlah','$ip')
        ");
        return $query;
    }

    function get_datatabel_cms($ip){
        $query = $this->db->query("
            SELECT t.*,c.nama_barang,c.satuan,k.nama_kategori
            FROM tb_po_cms t
            JOIN cms c ON c.kode_barang = t.kode_barang
            JOIN kategori_cms k ON k.id_kategori = t.kategori
            WHERE t.ip = '$ip'
            ORDER BY t.created_at DESC");
        return $query;
    }

    function hapus_barang_cms($kode_barang,$ip){
        $query = $this->db->query("
            DELETE FROM tb_po_cms WHERE kode_barang = '$kode_barang' AND ip = '$ip'
        ");
        return $query;
    }

    function cek_dt_service($id_stok,$ip){
        $query = $this->db->query("
            SELECT * FROM tb_po_service WHERE id_po = '$id_stok' AND ip = '$ip'
        ");
        return $query;
    }

    function tambah_barang_service($id_stok,$id_barang,$id_po,$id_supplier,$tgl_po,$harga,$harga_jasa,$sn,$keterangan,$ip){
        $query = $this->db->query("
            INSERT INTO tb_po_service(id_stok,id_barang,id_po,id_supplier,tgl_po,harga,harga_jasa,sn,keterangan,ip)
            VALUES('$id_stok','$id_barang','$id_po','$id_supplier','$tgl_po','$harga','$harga_jasa','$sn','$keterangan','$ip')
        ");
        return $query;
    }

    function get_datatabel_service($ip){
        $query = $this->db->query("
            SELECT tb.*, b.nama_model, s.sn
            FROM tb_po_service tb 
            JOIN barang b ON b.id_barang = tb.id_barang
            JOIN stock_barang s ON s.id_stok = tb.id_stok
            WHERE tb.ip = '$ip'
        ");
        return $query;
    }

    function hapus_barang_service($id_stok){
        $query = $this->db->query("
            DELETE FROM tb_po_service WHERE id_stok = '$id_stok'
        ");
        return $query;
    }

    function insert_detail_po_service($id_po,$id_stok,$id_barang,$id_supplier,$harga,$harga_jasa,
    $ppn,$keterangan,$status,$updated_at){
        $query = $this->db->query("
            INSERT INTO detail_po_service(id_po,id_stok,id_barang,id_supplier,harga,harga_jasa,ppn,keterangan,status,updated_at)
            VALUES('$id_po','$id_stok','$id_barang','$id_supplier','$harga','$harga_jasa','$ppn','$keterangan','$status','$updated_at')
        ");
        return $query;
    }

    function hapus_tb_bantu_service($id_po,$ip){
        $query = $this->db->query("
            DELETE FROM tb_po_service WHERE id_po = '$id_po' AND ip = '$ip'
        ");
        return $query;
    }

    function get_kurs_proyek($id_proyek){
        $query = $this->db->query("SELECT kurs FROM master_proyek WHERE id_proyek = '$id_proyek'");
        return $query;
    }
}
?>