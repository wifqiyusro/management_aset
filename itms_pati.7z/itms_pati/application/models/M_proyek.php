<?php
class M_proyek extends CI_Model{

    var $table = 'master_proyek';
	var $column_order = array(null, 'id_proyek','nama_proyek','no_po','nama_supplier','tanggal','total_harga','remark','p.created_at','p.updated_at');
    var $column_search = array('id_proyek','nama_proyek','no_po','nama_supplier','tanggal','total_harga','remark','p.created_at','p.updated_at');
    var $order = array('nama_proyek' => 'asc');

    function get_datatables_proyek(){
        $this->db->select("p.*,sp.id_supplier,sp.nama_supplier");
        $this->db->from("master_proyek p");
        $this->db->join("supplier sp","sp.id_supplier=p.id_supplier");
        $i = 0;
        foreach ($this->column_search as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables(){
        $this->get_datatables_proyek();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered(){
        $this->get_datatables_proyek();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all(){
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
    
    function add_proyek($id_proyek,$nama_proyek,$no_po,$id_supplier,$tanggal,$kurs,$total_harga,$remark,$updated_at){
        $query = $this->db->query("INSERT INTO master_proyek(id_proyek,nama_proyek,no_po,id_supplier,tanggal,kurs,total_harga,remark,updated_at)
            VALUES('$id_proyek','$nama_proyek','$no_po','$id_supplier','$tanggal','$kurs','$total_harga','$remark','$updated_at')");
        return $query;
    }

    function get_data_proyek($id_proyek){
        $query = $this->db->query("SELECT * FROM master_proyek WHERE id_proyek = '$id_proyek'");
        return $query;
    }

    function update_proyek($id_proyek,$nama_proyek,$no_po,$id_supplier,$tanggal,$kurs,$total_harga,$remark,$updated_at){
        $query = $this->db->query("UPDATE master_proyek SET nama_proyek='$nama_proyek',no_po='$no_po',id_supplier='$id_supplier',tanggal='$tanggal',kurs='$kurs',total_harga='$total_harga',remark='$remark',
        updated_at='$updated_at' WHERE id_proyek='$id_proyek'");
        return $query;
    }

    function get_proyek(){
        $query = $this->db->query("
        SELECT p.*, s.id_supplier, s.nama_supplier FROM master_proyek p JOIN supplier s ON s.id_supplier=p.id_supplier ORDER BY p.nama_proyek ASC");
        return $query;
    }

    function get_proyek2($id_proyek){
        $query = $this->db->query("
        SELECT p.*, s.id_supplier, s.nama_supplier FROM master_proyek p JOIN supplier s ON s.id_supplier=p.id_supplier WHERE id_proyek = '$id_proyek'");
        return $query;
    }

    function insert_barang_proyek($id_stok,$id_transaksi,$id_barang,$kode_epte,$kode_fa,$id_supplier,$kurs,$alokasi,$keterangan,$status_keterangan,$jenis_aset,$updated_at,$id_user,$plan){
        $query = $this->db->query("
            INSERT INTO stock_barang (id_stok,id_transaksi,id_barang,epte_code,FA_code,id_supplier,kurs,harga,harga_ppn,harga_pph,alokasi,remark,status_keterangan,jenis_aset,updated_at,id_user,[plan])
            VALUES ('$id_stok','$id_transaksi','$id_barang','$kode_epte','$kode_fa','$id_supplier','$kurs','0','0','0','$alokasi','$keterangan','$status_keterangan','$jenis_aset','$updated_at','$id_user','$plan')
        ");
        return $query;
    }
}
?>