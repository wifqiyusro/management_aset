<?php
class M_aset extends CI_Model{

	function get_total_aset(){
        $query = $this->db->query("SELECT kode, nama_aset FROM kelompok_aset ORDER BY nama_aset ASC");
        return $query;
    }

    function generate_qr($id_stok,$image_name,$updated_at,$id_user){
        $query = $this->db->query("
            UPDATE itmspati.dbo.stock_barang SET qr = '$image_name', updated_at = '$updated_at', id_user = '$id_user' WHERE id_stok = '$id_stok'
            ");
        return $query;
    }

    function get_data_stok(){
        $query = $this->db->query("SELECT COUNT(id_stok) AS jumlah FROM itmspati.dbo.stock_barang WHERE status_keterangan = '0' AND jenis_aset NOT IN ('7','8')");
        return $query;
    }

    function get_data_pasang(){
        $query = $this->db->query("SELECT COUNT(id_stok) AS jumlah FROM itmspati.dbo.stock_barang WHERE status_keterangan = '1' AND jenis_aset NOT IN ('7','8')");
        return $query;
    }

    function get_data_rusak_it(){
        $query = $this->db->query("SELECT COUNT(id_stok) AS jumlah FROM itmspati.dbo.stock_barang WHERE status_keterangan = '3' AND jenis_aset NOT IN ('7','8')");
        return $query;
    }

    function get_data_rusak_vendor(){
        $query = $this->db->query("SELECT COUNT(id_stok) AS jumlah FROM itmspati.dbo.stock_barang WHERE status_keterangan = '4' AND jenis_aset NOT IN ('7','8')");
        return $query;
    }

    function get_data_all(){
        $query = $this->db->query("SELECT COUNT(id_stok) AS jumlah FROM itmspati.dbo.stock_barang WHERE jenis_aset NOT IN ('7','8')");
        return $query;
    }

    function get_data_user(){
        $query = $this->db->query("SELECT COUNT(id_user) AS jumlah FROM itmspati.dbo.users");
        return $query;
    }

    function export_detail_lokasi1($sambung,$lokasi){
        $query = $this->db->query("
            SELECT s.*,b.*,j.id_jenis_barang,j.nama_jenis_barang,l.id_lokasi,l.nama_lokasi
            FROM itmspati.dbo.stock_barang s
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            JOIN lokasi l ON l.id_lokasi = s.lokasi
            WHERE j.id_jenis_barang IN ($sambung) AND l.id_lokasi = '$lokasi' AND s.status_keterangan = 1
            AND s.jenis_aset NOT IN ('7','8')
            ORDER BY s.id_aset ASC
            ");
        return $query;
    }

    function export_detail_lokasi2($jenis_aset,$sambung,$lokasi){
        $query = $this->db->query("
            SELECT s.*,b.*,j.id_jenis_barang,j.nama_jenis_barang,l.id_lokasi,l.nama_lokasi
            FROM itmspati.dbo.stock_barang s 
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            JOIN lokasi l ON l.id_lokasi = s.lokasi
            WHERE s.jenis_aset = '$jenis_aset' AND j.id_jenis_barang IN ($sambung) AND l.id_lokasi = '$lokasi' AND s.status_keterangan = 1
            AND s.jenis_aset NOT IN ('7','8')
            ORDER BY s.id_aset ASC
            ");
        return $query;
    }

    function export_detail_lokasi3($id_barang,$sambung,$lokasi){
        $query = $this->db->query("
            SELECT s.*,b.*,j.id_jenis_barang,j.nama_jenis_barang,l.id_lokasi,l.nama_lokasi
            FROM itmspati.dbo.stock_barang s 
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            JOIN lokasi l ON l.id_lokasi = s.lokasi
            WHERE s.id_barang = '$id_barang' AND j.id_jenis_barang IN ($sambung) AND l.id_lokasi = '$lokasi' AND s.status_keterangan = 1
            AND s.jenis_aset NOT IN ('7','8')
            ORDER BY s.id_aset ASC
            ");
        return $query;
    }

    function export_detail_lokasi4($jenis_aset,$id_barang,$sambung,$lokasi){
        $query = $this->db->query("
            SELECT s.*,b.*,j.id_jenis_barang,j.nama_jenis_barang,l.id_lokasi,l.nama_lokasi
            FROM itmspati.dbo.stock_barang s 
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            JOIN lokasi l ON l.id_lokasi = s.lokasi
            WHERE s.jenis_aset = '$jenis_aset' AND s.id_barang = '$id_barang' AND j.id_jenis_barang IN ($sambung) AND l.id_lokasi = '$lokasi' AND s.status_keterangan = 1
            AND s.jenis_aset NOT IN ('7','8')
            ORDER BY s.id_aset ASC
            ");
        return $query;
    }

    function proses_cek_jenis($qr){
        $query = $this->db->query("SELECT jenis_aset FROM itmspati.dbo.stock_barang WHERE id_stok = '$qr'");
        return $query;
    }

    function proses_cek_status_proyek($qr){
        $query = $this->db->query("
            SELECT p.nama_proyek,p.tanggal,s.nama_supplier,l.nama_lokasi,b.nama_model,j.nama_jenis_barang,st.*,f.NAME
            FROM itmspati.dbo.stock_barang st 
            JOIN master_proyek p ON p.id_proyek = st.id_transaksi
            JOIN supplier s ON s.id_supplier = st.id_supplier
            JOIN barang b ON b.id_barang = st.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            LEFT JOIN lokasi l ON l.id_lokasi = st.lokasi
            LEFT JOIN FLD.dbo.VIEW_MASTER_KARYAWAN f ON f.NIK = st.NIK
            WHERE st.id_stok = '$qr' AND st.jenis_aset NOT IN ('7','8')");
        return $query;
    }

    function proses_cek_status($qr){
        $query = $this->db->query("
            SELECT t.no_po,t.tanggal_po,s.nama_supplier,l.nama_lokasi,b.nama_model,j.nama_jenis_barang,st.*,f.NAME
            FROM itmspati.dbo.stock_barang st 
            JOIN barang b ON b.id_barang = st.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            JOIN supplier s ON s.id_supplier = st.id_supplier
            LEFT JOIN lokasi l ON l.id_lokasi = st.lokasi
            JOIN transaksi_pembelian t ON t.id_transaksi = st.id_transaksi
            LEFT JOIN FLD.dbo.VIEW_MASTER_KARYAWAN f ON f.NIK = st.nik
            WHERE st.id_stok = '$qr' AND st.jenis_aset NOT IN ('7','8')");
        return $query;
    }

    function cek_data_aset($id_stok){
        $query = $this->db->query("
            SELECT j.id_jenis_barang,j.nama_jenis_barang,j.kel_asset,j.label_jns_barang,
            b.nama_model,s.nama_supplier,st.*
            FROM itmspati.dbo.stock_barang st
            JOIN barang b ON b.id_barang = st.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            JOIN supplier s ON s.id_supplier = st.id_supplier
            WHERE st.id_stok = '$id_stok' AND st.jenis_aset NOT IN ('7','8')
            ");
        return $query;
    }

    function cek_aset_terakhir($id_jenis_barang,$lokasi){
        $query = $this->db->query("
            SELECT TOP 1 s.*, b.*, sp.*, j.*
            FROM itmspati.dbo.stock_barang s
            INNER JOIN barang b ON b.id_barang = s.id_barang
            INNER JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            INNER JOIN supplier sp ON sp.id_supplier = s.id_supplier
            WHERE j.id_jenis_barang = '$id_jenis_barang' AND s.lokasi = '$lokasi'
            ORDER BY s.id_aset DESC
            ");
        return $query;
    }

    function update_aset_out($id_stok,$id,$lokasi,$detail_lokasi,$nama_user,$nik,$windows_ori,$office_ori,$serial_number,$serial_number_office,$os,$ram,$koneksi,$tipe_koneksi,$status_keterangan,$remark,$updated_at,$id_user){
        $query = $this->db->query("UPDATE itmspati.dbo.stock_barang SET id_aset='$id',lokasi='$lokasi',detail_lokasi='$detail_lokasi',nama_user='$nama_user',nik = '$nik',windows_ori='$windows_ori',office_ori='$office_ori',serial_number='$serial_number',serial_number_office='$serial_number_office',os='$os',ram='$ram',koneksi='$koneksi',tipe_koneksi='$tipe_koneksi',status_keterangan='$status_keterangan',remark='$remark',updated_at='$updated_at',id_user='$id_user' WHERE id_stok='$id_stok'");
        return $query;
    }

    function update_aset($id_stok,$id_aset,$lokasi,$detail_lokasi,$nama_user,$nik,$status_keterangan,$updated_at,$id_user){
        $query = $this->db->query("UPDATE itmspati.dbo.stock_barang SET id_aset='$id_aset',lokasi='$lokasi',detail_lokasi='$detail_lokasi',nama_user='$nama_user',nik='$nik',status_keterangan='$status_keterangan',updated_at='$updated_at',id_user='$id_user' WHERE id_stok='$id_stok'");
        return $query;
    }

    function update_aset_pindah($id_stok,$id_aset,$lokasi,$detail_lokasi,$nama_user,$nik,$updated_at,$id_user){
        $query = $this->db->query("
            UPDATE itmspati.dbo.stock_barang SET id_aset='$id_aset',lokasi='$lokasi',detail_lokasi='$detail_lokasi',nama_user='$nama_user',nik='$nik',updated_at='$updated_at',id_user='$id_user' WHERE id_stok='$id_stok'
        ");
        return $query;
    }

    var $column_order = array(null, 's.id_stok','b.nama_model','s.jenis_aset','s.sn','s.alokasi','s.remark','s.qr','s.updated_at');
    var $column_search = array('s.id_stok','b.nama_model','s.jenis_aset','s.sn','s.alokasi','s.remark','s.qr','s.updated_at');
    var $order = array('s.updated_at' => 'desc');

    function get_datatables_non_terpasang($where1,$where2){
        $this->db->select("s.id_stok,b.nama_model,s.jenis_aset,s.sn,s.alokasi,s.remark,s.qr,s.updated_at");
        $this->db->from("itmspati.dbo.stock_barang s");
        $this->db->join("barang b","b.id_barang=s.id_barang");
        $this->db->join("jenis_barang j","j.id_jenis_barang=b.id_jenis_barang");
        $this->db->where($where1);
        $this->db->where($where2);
        $i = 0;
        foreach ($this->column_search as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables($where1,$where2){
        $this->get_datatables_non_terpasang($where1,$where2);
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered($where1,$where2){
        $this->get_datatables_non_terpasang($where1,$where2);
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all($where1,$where2){
        $this->db->select("s.id_stok,b.nama_model,s.jenis_aset,s.sn,s.alokasi,s.remark,s.qr,s.updated_at");
        $this->db->from("itmspati.dbo.stock_barang s");
        $this->db->join("barang b","b.id_barang=s.id_barang");
        $this->db->join("jenis_barang j","j.id_jenis_barang=b.id_jenis_barang");
        $this->db->where($where1);
        $this->db->where($where2);
        return $this->db->count_all_results();
    }

    function update_aset_non_terpasang($id_stok,$sn,$remark,$updated_at,$id_user){
        $query = $this->db->query("UPDATE itmspati.dbo.stock_barang SET sn='$sn',remark='$remark',updated_at='$updated_at',id_user='$id_user' WHERE id_stok='$id_stok'");
        return $query;
    }

    function cek_aset_tf($id_stok){
        $query = $this->db->query("
            SELECT s.*, j.id_jenis_barang,j.nama_jenis_barang,j.label_jns_barang,b.nama_model,l.nama_lokasi,l.label,sp.nama_supplier
            FROM itmspati.dbo.stock_barang s
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            JOIN supplier sp ON sp.id_supplier = s.id_supplier
            LEFT JOIN lokasi l ON l.id_lokasi = s.lokasi
            WHERE s.id_stok = '$id_stok' AND s.jenis_aset NOT IN ('7','8')
            ");
        return $query;
    }

    function transfer_hwi_jepara($id_stok){
        $query = $this->db->query("
            INSERT INTO itmsdata.itms.stock_barang(id_stok,id_transaksi,id_barang,id_supplier,harga,harga_ppn,harga_pph,lokasi,detail_lokasi,nama_user,windows_ori,office_ori,serial_number,serial_number_office,os,ram,koneksi,tipe_koneksi,sn,status_keterangan,mac_adress,remark,alokasi,qr,jenis_aset,tgl_dtg,created_at)
            SELECT id_stok,id_transaksi,id_barang,id_supplier,harga,harga_ppn,harga_pph,lokasi,detail_lokasi,nama_user,windows_ori,office_ori,serial_number,serial_number_office,os,ram,koneksi,tipe_koneksi,sn,status_keterangan,mac_adress,remark,alokasi,qr,jenis_aset,tgl_dtg,created_at
            FROM itmspati.dbo.stock_barang
            WHERE id_stok = '$id_stok'
            ");
        return $query;
    }

    function update_tambahan($id_stok,$id_aset,$plan){
        $query = $this->db->query("
            UPDATE itmsdata.itms.stock_barang SET id_aset='$id_aset', [plan]='$plan' WHERE id_stok = '$id_stok' 
            ");
        return $query;
    }

    function hapus_barang_pati($id_stok){
        $query = $this->db->query("DELETE FROM itmspati.dbo.stock_barang WHERE id_stok='$id_stok'");
        return $query;
    }

    function insert_tb_vendor($id_stok,$vendor){
        $query = $this->db->query("
            INSERT INTO tb_vendor(id_stok,id_supplier)
            VALUES('$id_stok','$vendor')
        ");
        return $query;
    }

    function delete_tb_vendor($id_stok){
        $query = $this->db->query("
            DELETE FROM tb_vendor WHERE id_stok = '$id_stok'
        ");
        return $query;
    }

    function cek_tb_service($id_stok){
        $query = $this->db->query("
            SELECT id_stok FROM tb_po_service WHERE id_stok = '$id_stok'
        ");
        return $query;
    }

    function cek_tb_vendor($id_stok,$id_supplier){
        $query = $this->db->query("
            SELECT s.id_stok, b.id_barang, b.nama_model, s.sn
            FROM stock_barang s
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN tb_vendor v ON v.id_stok = s.id_stok
            WHERE s.id_stok = '$id_stok' AND v.id_supplier = '$id_supplier' 
        ");
        return $query;
    }

    function get_data_tb_service($id_po,$ip){
        $query = $this->db->query("
            SELECT * FROM tb_po_service WHERE id_po = '$id_po' AND ip = '$ip'
        ");
        return $query;
    }

    function get_konfirm_service(){
        $query = $this->db->query("
        SELECT DISTINCT id_po, no_po, tanggal_po, nama_supplier, nama_barang = SUBSTRING (( 
            SELECT ', ' + o.nama_model FROM
            (
            SELECT m.id_po, m.no_po, CONVERT(CHAR(10),m.tanggal_po,105) AS tanggal_po, s.nama_supplier, b.nama_model FROM detail_po_service d
            JOIN master_po m on m.id_po = d.id_po
            JOIN barang b ON b.id_barang = d.id_barang
            JOIN supplier s ON s.id_supplier = d.id_supplier
            JOIN 
            (SELECT id_po FROM detail_po_service) a ON a.id_po = m.id_po
            WHERE m.jenis_po = 3 and d.status = 0
            GROUP BY m.id_po, m.no_po, m.tanggal_po, s.nama_supplier, b.nama_model
            ) AS o
            WHERE o.id_po = o2.id_po FOR XML path(''), elements), 3, 500)
            FROM 
            (
            SELECT m.id_po, m.no_po, CONVERT(CHAR(10),m.tanggal_po,105) AS tanggal_po, s.nama_supplier, b.nama_model FROM detail_po_service d
            JOIN master_po m on m.id_po = d.id_po
            JOIN barang b ON b.id_barang = d.id_barang
            JOIN supplier s ON s.id_supplier = d.id_supplier
            JOIN 
            (SELECT id_po FROM detail_po_service ) a ON a.id_po = m.id_po
            WHERE m.jenis_po = 3 and d.status = 0
            GROUP BY m.id_po, m.no_po, m.tanggal_po, s.nama_supplier, b.nama_model
            ) as o2
        ");
        return $query;
    }

    function get_detail_konfirm_service($id_po){
        $query = $this->db->query("
            SELECT d.*, m.no_po, b.nama_model, s.nama_supplier
            FROM detail_po_service d
            JOIN master_po m ON m.id_po = d.id_po
            JOIN barang b ON b.id_barang = d.id_barang
            JOIN supplier s ON s.id_supplier = d.id_supplier
            WHERE d.id_po = '$id_po'
            ORDER BY b.nama_model ASC
        ");
        return $query;
    }

    function update_tb_service($id_po,$id_stok,$surat_jalan,$updated_at){
        $query = $this->db->query("
            UPDATE detail_po_service SET surat_jalan = '$surat_jalan', status = '1', updated_at = '$updated_at' WHERE id_po = '$id_po' AND id_stok = '$id_stok'
        ");
        return $query;
    }

    function update_aset_kembali($id_stok,$updated_at,$id_user){
        $query = $this->db->query("
            UPDATE stock_barang SET status_keterangan = '0', updated_at = '$updated_at', id_user = '$id_user' WHERE id_stok = '$id_stok'
        ");
        return $query;
    }

    function export_per_aset($sambung){
        $query = $this->db->query("
            SELECT s.id_stok,s.id_aset,j.nama_jenis_barang,b.nama_model,s.epte_code,s.FA_code,l.nama_lokasi,s.detail_lokasi,s.nama_user,s.nik,
            s.sn,s.kurs,s.harga,s.harga_ppn,
            CASE
                WHEN s.status_keterangan = 0 THEN 'STOCK'
                WHEN s.status_keterangan = 1 THEN 'INSTALLED'
                WHEN s.status_keterangan = 3 THEN 'BROKEN ON IT'
                ELSE 'BROKEN ON VENDOR'
            END AS status, s.remark, f.NAME
            FROM stock_barang s
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            JOIN kelompok_aset k ON k.kode = j.kel_asset
            LEFT JOIN lokasi l ON l.id_lokasi = s.lokasi
            LEFT JOIN FLD.dbo.VIEW_MASTER_KARYAWAN f ON f.NIK = s.nik
            WHERE j.id_jenis_barang IN ($sambung) AND (s.status_keterangan NOT IN ('7','8') AND s.jenis_aset NOT IN ('7','8'))
            ORDER BY s.status_keterangan ASC
        ");
        return $query;
    }

    function count_per_aset($sambung){
        $query = $this->db->query("
            SELECT
            CASE
                WHEN s.status_keterangan = 0 THEN 'STOCK'
                WHEN s.status_keterangan = 1 THEN 'INSTALLED'
                WHEN s.status_keterangan = 3 THEN 'BROKEN ON IT'
                ELSE 'BROKEN ON VENDOR'
            END AS status, count(s.id_stok) AS jumlah
            FROM stock_barang s
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            JOIN kelompok_aset k ON k.kode = j.kel_asset
            LEFT JOIN lokasi l ON l.id_lokasi = s.lokasi
            WHERE j.id_jenis_barang IN ($sambung) AND (s.status_keterangan NOT IN ('7','8') AND s.jenis_aset NOT IN ('7','8'))
            GROUP BY s.status_keterangan
        ");
        return $query;
    }

    function get_karyawan(){
        $query = $this->db->query("
            SELECT NIK,NAME,DEPARTEMENT,DESCRIPTION,NAMA_GEDUNG
            FROM FLD.dbo.VIEW_MASTER_KARYAWAN
            WHERE TERMINATION IS NULL
            ORDER BY NIK ASC
        ");
        return $query;
    }

    function get_row_karyawan($nik){
        $query = $this->db->query("
            SELECT NIK,NAME,DEPARTEMENT,DESCRIPTION,NAMA_GEDUNG
            FROM FLD.dbo.VIEW_MASTER_KARYAWAN
            WHERE NIK = '$nik'
        ");
        return $query;
    }

    function get_karyawan_2($searchTerm=null){
        if($searchTerm != null){
            $this->db->where("NIK like '%".$searchTerm."%' ");
            $this->db->or_where("NAME like '%".$searchTerm."%' ");
            $this->db->where("TERMINATION IS NULL");
        }else{
            $this->db->where("TERMINATION IS NULL");
        }
        $this->db->select("NIK,NAME,DEPARTEMENT,NAMA_GEDUNG");        
        $this->db->order_by("NIK","ASC");
        $fetched_records = $this->db->get("FLD.dbo.VIEW_MASTER_KARYAWAN");
        $users = $fetched_records->result_array();
        $data = array();
        foreach($users as $user){
            $data[] = array("id"=>$user['NIK'], "text"=>$user['NIK'].' - '.$user['NAME']);
        }
        return $data;

    }
}
?>