<?php
class M_stok_barang extends CI_Model{

    var $column_order = array(null,'s.id_stok','s.id_aset','b.kode_sap','b.nama_model','s.jenis_aset','s.kurs','s.harga','s.detail_lokasi','s.nama_user','s.sn','s.remark','s.qr','s.lokasi','s.id_barang','f.NAME','s.nik');
    var $column_search = array('s.id_stok','s.id_aset','b.kode_sap','b.nama_model','s.jenis_aset','s.kurs','s.harga','s.detail_lokasi','s.nama_user','s.sn','s.remark','s.qr','s.lokasi','s.id_barang','f.NAME','s.nik');
    var $order = array('s.id_aset'=>'DESC');

	function get_stok($sambung){
        $query = $this->db->query("SELECT count(s.id_stok) AS jumlah
            FROM itmspati.dbo.stock_barang s
            INNER JOIN barang b ON b.id_barang = s.id_barang
            INNER JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            WHERE s.status_keterangan = '0' AND j.id_jenis_barang IN ($sambung) AND s.jenis_aset NOT IN ('7','8')");
        return $query;
    }

    function get_terpasang($sambung){
        $query = $this->db->query("SELECT count(s.id_stok) AS jumlah
            FROM itmspati.dbo.stock_barang s
            INNER JOIN barang b ON b.id_barang = s.id_barang
            INNER JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            WHERE s.status_keterangan = '1' AND j.id_jenis_barang IN ($sambung) AND s.jenis_aset NOT IN ('7','8')");
        return $query;
    }

    function get_rusak_it($sambung){
        $query = $this->db->query("SELECT count(s.id_stok) AS jumlah
            FROM itmspati.dbo.stock_barang s
            INNER JOIN barang b ON b.id_barang = s.id_barang
            INNER JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            WHERE s.status_keterangan = '3' AND j.id_jenis_barang IN ($sambung) AND s.jenis_aset NOT IN ('7','8')");
        return $query;
    }

    function get_rusak_vendor($sambung){
        $query = $this->db->query("SELECT count(s.id_stok) AS jumlah
            FROM itmspati.dbo.stock_barang s
            INNER JOIN barang b ON b.id_barang = s.id_barang
            INNER JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            WHERE s.status_keterangan = '4' AND j.id_jenis_barang IN ($sambung) AND s.jenis_aset NOT IN ('7','8')");
        return $query;
    }

    function aset_non_pc($sambung){
        $query = $this->db->query("
            SELECT l.id_lokasi, l.nama_lokasi, count(s.id_barang) AS total_barang
            FROM itmspati.dbo.stock_barang s 
            JOIN lokasi l on l.id_lokasi = s.lokasi
            JOIN barang b ON b.id_barang = s.id_barang 
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            WHERE s.status_keterangan = 1 AND  j.id_jenis_barang IN ($sambung) AND s.jenis_aset NOT IN ('7','8')
            GROUP BY l.id_lokasi, l.nama_lokasi 
            ORDER BY l.nama_lokasi
            ");
        return $query;
    }

    function aset_pc_non_cell($sambung){
        $query = $this->db->query("
            SELECT 
            j.id_jenis_barang,
            l.id_lokasi,
            l.nama_lokasi,      
            count(s.id_barang) as total_barang, 
            count(s.koneksi) as total_koneksi, 
            SUM(CASE WHEN s.koneksi='LAN' THEN 1 ELSE 0 END) as lan, 
            SUM(CASE WHEN s.koneksi='WIFI' THEN 1 ELSE 0 END) as wifi, 
            SUM(CASE WHEN s.windows_ori='YES' THEN 1 ELSE 0 END) as windows_ori, 
            SUM(CASE WHEN s.windows_ori='NO' THEN 1 ELSE 0 END) as windows_not_ori, 
            SUM(CASE WHEN s.office_ori='YES' THEN 1 ELSE 0 END) as office_ori, 
            SUM(CASE WHEN s.office_ori='NO' THEN 1 ELSE 0 END) as office_not_ori 
            FROM itmspati.dbo.stock_barang s 
            JOIN lokasi l ON l.id_lokasi = s.lokasi  
            JOIN barang b ON b.id_barang = s.id_barang 
            JOIN jenis_barang J ON j.id_jenis_barang = b.id_jenis_barang 
            WHERE s.status_keterangan ='1' AND j.id_jenis_barang IN ($sambung) AND s.jenis_aset NOT IN ('7','8')
            AND substring(l.nama_lokasi, 1, 4) NOT LIKE 'CELL%' AND substring(l.nama_lokasi, 1, 2) NOT LIKE 'FF%'         
            GROUP BY j.id_jenis_barang, l.id_lokasi, l.nama_lokasi
            ");
        return $query;
    }

    function get_pc_prod_a($sambung){
        $query = $this->db->query("
        SELECT 
        j.id_jenis_barang,      
        count(s.id_barang) as total_barang, 
        count(s.koneksi) as total_koneksi, 
        SUM(CASE WHEN s.koneksi='LAN' THEN 1 ELSE 0 END) as lan, 
        SUM(CASE WHEN s.koneksi='WIFI' THEN 1 ELSE 0 END) as wifi, 
        SUM(CASE WHEN s.windows_ori='YES' THEN 1 ELSE 0 END) as windows_ori, 
        SUM(CASE WHEN s.windows_ori='NO' THEN 1 ELSE 0 END) as windows_not_ori, 
        SUM(CASE WHEN s.office_ori='YES' THEN 1 ELSE 0 END) as office_ori, 
        SUM(CASE WHEN s.office_ori='NO' THEN 1 ELSE 0 END) as office_not_ori 
        FROM itmspati.dbo.stock_barang s 
        JOIN lokasi l ON l.id_lokasi = s.lokasi  
        JOIN barang b ON b.id_barang = s.id_barang 
        JOIN jenis_barang J ON j.id_jenis_barang = b.id_jenis_barang 
        WHERE s.status_keterangan ='1' AND j.id_jenis_barang IN ($sambung) AND substring(l.nama_lokasi, 1, 6) = 'CELL A'
        AND s.jenis_aset NOT IN ('7','8')        
        GROUP BY j.id_jenis_barang
        ");
        return $query;
    }

    function get_pc_prod_b($sambung){
        $query = $this->db->query("
        SELECT 
        j.id_jenis_barang,      
        count(s.id_barang) as total_barang, 
        count(s.koneksi) as total_koneksi, 
        SUM(CASE WHEN s.koneksi='LAN' THEN 1 ELSE 0 END) as lan, 
        SUM(CASE WHEN s.koneksi='WIFI' THEN 1 ELSE 0 END) as wifi, 
        SUM(CASE WHEN s.windows_ori='YES' THEN 1 ELSE 0 END) as windows_ori, 
        SUM(CASE WHEN s.windows_ori='NO' THEN 1 ELSE 0 END) as windows_not_ori, 
        SUM(CASE WHEN s.office_ori='YES' THEN 1 ELSE 0 END) as office_ori, 
        SUM(CASE WHEN s.office_ori='NO' THEN 1 ELSE 0 END) as office_not_ori 
        FROM itmspati.dbo.stock_barang s 
        JOIN lokasi l ON l.id_lokasi = s.lokasi  
        JOIN barang b ON b.id_barang = s.id_barang 
        JOIN jenis_barang J ON j.id_jenis_barang = b.id_jenis_barang 
        WHERE s.status_keterangan ='1' AND j.id_jenis_barang IN ($sambung) AND substring(l.nama_lokasi, 1, 6) = 'CELL B'
        AND s.jenis_aset NOT IN ('7','8')        
        GROUP BY j.id_jenis_barang
        ");
        return $query;
    }

    function get_pc_prod_c($sambung){
        $query = $this->db->query("
        SELECT 
        j.id_jenis_barang,      
        count(s.id_barang) as total_barang, 
        count(s.koneksi) as total_koneksi, 
        SUM(CASE WHEN s.koneksi='LAN' THEN 1 ELSE 0 END) as lan, 
        SUM(CASE WHEN s.koneksi='WIFI' THEN 1 ELSE 0 END) as wifi, 
        SUM(CASE WHEN s.windows_ori='YES' THEN 1 ELSE 0 END) as windows_ori, 
        SUM(CASE WHEN s.windows_ori='NO' THEN 1 ELSE 0 END) as windows_not_ori, 
        SUM(CASE WHEN s.office_ori='YES' THEN 1 ELSE 0 END) as office_ori, 
        SUM(CASE WHEN s.office_ori='NO' THEN 1 ELSE 0 END) as office_not_ori 
        FROM itmspati.dbo.stock_barang s 
        JOIN lokasi l ON l.id_lokasi = s.lokasi  
        JOIN barang b ON b.id_barang = s.id_barang 
        JOIN jenis_barang J ON j.id_jenis_barang = b.id_jenis_barang 
        WHERE s.status_keterangan ='1' AND j.id_jenis_barang IN ($sambung) AND substring(l.nama_lokasi, 1, 6) = 'CELL C'   
        AND s.jenis_aset NOT IN ('7','8')     
        GROUP BY j.id_jenis_barang
        ");
        return $query;
    }

    function get_pc_prod_d($sambung){
        $query = $this->db->query("
        SELECT 
        j.id_jenis_barang,      
        count(s.id_barang) as total_barang, 
        count(s.koneksi) as total_koneksi, 
        SUM(CASE WHEN s.koneksi='LAN' THEN 1 ELSE 0 END) as lan, 
        SUM(CASE WHEN s.koneksi='WIFI' THEN 1 ELSE 0 END) as wifi, 
        SUM(CASE WHEN s.windows_ori='YES' THEN 1 ELSE 0 END) as windows_ori, 
        SUM(CASE WHEN s.windows_ori='NO' THEN 1 ELSE 0 END) as windows_not_ori, 
        SUM(CASE WHEN s.office_ori='YES' THEN 1 ELSE 0 END) as office_ori, 
        SUM(CASE WHEN s.office_ori='NO' THEN 1 ELSE 0 END) as office_not_ori 
        FROM itmspati.dbo.stock_barang s 
        JOIN lokasi l ON l.id_lokasi = s.lokasi  
        JOIN barang b ON b.id_barang = s.id_barang 
        JOIN jenis_barang J ON j.id_jenis_barang = b.id_jenis_barang 
        WHERE s.status_keterangan ='1' AND j.id_jenis_barang IN ($sambung) AND substring(l.nama_lokasi, 1, 6) = 'CELL D'
        AND s.jenis_aset NOT IN ('7','8')        
        GROUP BY j.id_jenis_barang
        ");
        return $query;
    }

    function get_pc_prod_e($sambung){
        $query = $this->db->query("
        SELECT 
        j.id_jenis_barang,      
        count(s.id_barang) as total_barang, 
        count(s.koneksi) as total_koneksi, 
        SUM(CASE WHEN s.koneksi='LAN' THEN 1 ELSE 0 END) as lan, 
        SUM(CASE WHEN s.koneksi='WIFI' THEN 1 ELSE 0 END) as wifi, 
        SUM(CASE WHEN s.windows_ori='YES' THEN 1 ELSE 0 END) as windows_ori, 
        SUM(CASE WHEN s.windows_ori='NO' THEN 1 ELSE 0 END) as windows_not_ori, 
        SUM(CASE WHEN s.office_ori='YES' THEN 1 ELSE 0 END) as office_ori, 
        SUM(CASE WHEN s.office_ori='NO' THEN 1 ELSE 0 END) as office_not_ori 
        FROM itmspati.dbo.stock_barang s 
        JOIN lokasi l ON l.id_lokasi = s.lokasi  
        JOIN barang b ON b.id_barang = s.id_barang 
        JOIN jenis_barang J ON j.id_jenis_barang = b.id_jenis_barang 
        WHERE s.status_keterangan ='1' AND j.id_jenis_barang IN ($sambung) AND substring(l.nama_lokasi, 1, 6) = 'CELL E'
        AND s.jenis_aset NOT IN ('7','8')       
        GROUP BY j.id_jenis_barang
        ");
        return $query;
    }

    function get_pc_prod_f($sambung){
        $query = $this->db->query("
        SELECT 
        j.id_jenis_barang,      
        count(s.id_barang) as total_barang, 
        count(s.koneksi) as total_koneksi, 
        SUM(CASE WHEN s.koneksi='LAN' THEN 1 ELSE 0 END) as lan, 
        SUM(CASE WHEN s.koneksi='WIFI' THEN 1 ELSE 0 END) as wifi, 
        SUM(CASE WHEN s.windows_ori='YES' THEN 1 ELSE 0 END) as windows_ori, 
        SUM(CASE WHEN s.windows_ori='NO' THEN 1 ELSE 0 END) as windows_not_ori, 
        SUM(CASE WHEN s.office_ori='YES' THEN 1 ELSE 0 END) as office_ori, 
        SUM(CASE WHEN s.office_ori='NO' THEN 1 ELSE 0 END) as office_not_ori 
        FROM itmspati.dbo.stock_barang s 
        JOIN lokasi l ON l.id_lokasi = s.lokasi  
        JOIN barang b ON b.id_barang = s.id_barang 
        JOIN jenis_barang J ON j.id_jenis_barang = b.id_jenis_barang 
        WHERE s.status_keterangan ='1' AND j.id_jenis_barang IN ($sambung) AND substring(l.nama_lokasi, 1, 2) = 'FF'
        AND s.jenis_aset NOT IN ('7','8')      
        GROUP BY j.id_jenis_barang
        ");
        return $query;
    }

    function get_datatables_detail_aset($where,$lokasi){

        if($this->input->post('jenis_aset')){
            if($this->input->post('jenis_aset') == '3'){
                $this->db->where('s.jenis_aset','0');
            }else{
                $this->db->where('s.jenis_aset',$this->input->post('jenis_aset'));
            }
        }
        if($this->input->post('id_barang')){
            $this->db->where('s.id_barang',$this->input->post('id_barang'));
        }
        if($this->input->post('lokasi')){
            $this->db->where('s.lokasi',$this->input->post('lokasi'));
        }

        $this->db->select("s.id_stok,s.id_aset,b.kode_sap,b.nama_model,s.jenis_aset,s.kurs,s.harga,s.detail_lokasi,s.nama_user,s.nik,f.NAME,s.sn,s.remark,s.qr,s.lokasi,s.id_barang");
        $this->db->from("itmspati.dbo.stock_barang s");
        $this->db->join("barang b","b.id_barang=s.id_barang");
        $this->db->join("jenis_barang j","j.id_jenis_barang=b.id_jenis_barang");
        $this->db->join("lokasi as lk","lk.id_lokasi = s.lokasi");
        $this->db->join("FLD.dbo.VIEW_MASTER_KARYAWAN f","f.NIK=s.nik","LEFT");
        $this->db->where($where);       
        $this->db->where("s.lokasi =",$lokasi);
        $i = 0;
        foreach ($this->column_search as $item){
            if(@$_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables($where,$lokasi){
        $this->get_datatables_detail_aset($where,$lokasi);
        if(@$_POST['length'] != -1)
        $this->db->limit(@$_POST['length'], @$_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered($where,$lokasi){
        $this->get_datatables_detail_aset($where,$lokasi);
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all($where,$lokasi){
        $this->db->select('s.id_stok');
        $this->db->from('itmspati.dbo.stock_barang s');
        $this->db->join('barang b','b.id_barang=s.id_barang');
        $this->db->join('jenis_barang j','j.id_jenis_barang=b.id_jenis_barang');
        $this->db->join('lokasi lk','lk.id_lokasi=s.lokasi');
        $this->db->join('FLD.dbo.VIEW_MASTER_KARYAWAN f','f.NIK=s.nik','left');
        $this->db->where($where);
        $this->db->where("s.lokasi =",$lokasi);
        return $this->db->count_all_results();
    }

    function edit_barang($id_stok){
        $query = $this->db->query("SELECT s.*, b.nama_model, f.NAME,
            CASE
                WHEN s.jenis_aset = '0' THEN 'PO'
                WHEN s.jenis_aset = '1' THEN 'Rental'
                ELSE 'Projek'
            END AS jns_aset 
            FROM itmspati.dbo.stock_barang s
            JOIN barang b ON b.id_barang = s.id_barang
            LEFT JOIN FLD.dbo.VIEW_MASTER_KARYAWAN f ON f.NIK = s.nik
            WHERE s.id_stok = '$id_stok'");
        return $query;
    }

    function update_barang($id_stok,$id_aset,$windows_ori,$office_ori,$serial_number,$serial_number_office,$os,$ram,$koneksi,$tipe_koneksi,$mac_adress,$detail_lokasi,$nama_user,$nik,$sn,$remark,$updated_at,$id_user){
        $query = $this->db->query("
            UPDATE itmspati.dbo.stock_barang
            SET id_aset = '$id_aset', windows_ori ='$windows_ori', office_ori = '$office_ori', serial_number='$serial_number', serial_number_office='$serial_number_office', os = '$os', ram = '$ram', koneksi = '$koneksi', tipe_koneksi = '$tipe_koneksi', mac_adress = '$mac_adress', detail_lokasi = '$detail_lokasi',nama_user = '$nama_user', nik = '$nik', sn = '$sn', remark = '$remark', updated_at = '$updated_at', id_user = '$id_user' WHERE id_stok = '$id_stok'
            ");
        return $query;
    }

    function cek_data_jepara($id_jenis_barang,$id_lokasi){
        $query = $this->db->query("
            SELECT TOP 1 s.*, b.*, sp.*, j.*
            FROM itmsdata.itms.stock_barang s
            INNER JOIN barang b ON b.id_barang = s.id_barang
            INNER JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            INNER JOIN supplier sp ON sp.id_supplier = s.id_supplier
            WHERE j.id_jenis_barang = '$id_jenis_barang' AND s.lokasi = '$id_lokasi'
            ORDER BY s.id_aset DESC
            ");
        return $query;
    }

    var $column_order_rental = array(null,'j.nama_jenis_barang','b.nama_model','d.estimasi_dtg','d.kurs','d.harga','d.ppn','d.pph','d.created_at');
    var $column_search_rental = array('j.nama_jenis_barang','b.nama_model','d.estimasi_dtg','d.kurs','d.harga','d.ppn','d.pph','d.created_at');
    var $order_rental = array('d.created_at' => 'desc');

    function get_datatables_konfirm_rental(){
        $this->db->select("d.*,j.id_jenis_barang,j.nama_jenis_barang,b.nama_model");
        $this->db->from("itmspati.dbo.detail_po d");
        $this->db->join("barang b","b.id_barang=d.id_barang");
        $this->db->join("jenis_barang j","j.id_jenis_barang=b.id_jenis_barang");
        $this->db->where("d.jenis_aset =",1);
        $i = 0;
        foreach ($this->column_search_rental as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search_rental) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order_rental[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order_rental)){
            $order = $this->order_rental;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables_rental(){
        $this->get_datatables_konfirm_rental();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_rental(){
        $this->get_datatables_konfirm_rental();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_rental(){
        $this->db->select("*");
        $this->db->from("itmspati.dbo.detail_po");
        $this->db->where("jenis_aset =",1);
        return $this->db->count_all_results();
    }

    function insert_stok($id_stok,$id_transaksi,$id_barang,$kode_epte,$kode_fa,$id_supplier,$kurs,$harga,$harga_ppn,$harga_pph,$status_keterangan,$remark,$jenis_aset,$tgl_dtg,$alokasi,$updated_at,$id_user,$plan){
        $query = $this->db->query("
            INSERT INTO itmspati.dbo.stock_barang (id_stok,id_transaksi,id_barang,epte_code,FA_code,id_supplier,kurs,harga,harga_ppn,harga_pph,status_keterangan,remark,jenis_aset,tgl_dtg,alokasi,updated_at,id_user,[plan])
            VALUES('$id_stok','$id_transaksi','$id_barang','$kode_epte','$kode_fa','$id_supplier','$kurs','$harga','$harga_ppn','$harga_pph','$status_keterangan','$remark','$jenis_aset','$tgl_dtg','$alokasi','$updated_at','$id_user','$plan')");
        return $query;
    }

    function hapus_konfirm($id_temp,$jenis_aset){
        $query = $this->db->query("DELETE FROM itmspati.dbo.detail_po WHERE id_temp = '$id_temp' AND jenis_aset = '$jenis_aset'");
        return $query;
    }

    function get_konfirm_po(){
        $query = $this->db->query("
            SELECT DISTINCT id_po, no_po, tanggal_po, nama_supplier, nama_model = SUBSTRING (( 
              SELECT ', ' + o.nama_model FROM
              (
              SELECT m.id_po, m.no_po, CONVERT(CHAR(10),m.tanggal_po,105) AS tanggal_po, s.nama_supplier, b.nama_model FROM itmspati.dbo.detail_po d
              JOIN master_po m on m.id_po = d.id_po
              JOIN barang b ON b.id_barang = d.id_barang
              JOIN supplier s ON s.id_supplier = d.id_supplier
              JOIN 
                (SELECT id_po FROM itmspati.dbo.detail_po) a ON a.id_po = m.id_po
              WHERE m.jenis_po = 1 AND d.jenis_aset = 0
              GROUP BY m.id_po, m.no_po, m.tanggal_po, s.nama_supplier, b.nama_model
              ) AS o
              WHERE o.id_po = o2.id_po FOR XML path(''), elements), 3, 500)
              FROM 
              (
              SELECT m.id_po, m.no_po, CONVERT(CHAR(10),m.tanggal_po,105) AS tanggal_po, s.nama_supplier, b.nama_model FROM itmspati.dbo.detail_po d
              JOIN master_po m on m.id_po = d.id_po
              JOIN barang b ON b.id_barang = d.id_barang
              JOIN supplier s ON s.id_supplier = d.id_supplier
              JOIN 
                (SELECT id_po FROM itmspati.dbo.detail_po ) a ON a.id_po = m.id_po
              WHERE m.jenis_po = 1 AND d.jenis_aset = 0
              GROUP BY m.id_po, m.no_po, m.tanggal_po, s.nama_supplier, b.nama_model
              ) as o2
            ");
        return $query;
    }

    var $column_order_po = array(null,'m.no_po','d.tgl_po','j.nama_jenis_barang','b.nama_model','d.epte_code','d.fa_code','d.kurs','d.harga','d.ppn','d.pph','d.alokasi');
    var $column_search_po = array('m.no_po','d.tgl_po','j.nama_jenis_barang','b.nama_model','d.epte_code','d.fa_code','d.kurs','d.harga','d.ppn','d.pph','d.alokasi');
    var $order_po = array('j.nama_jenis_barang'=>'asc');


    function get_datatables_konfirm_po($id_po){
        $this->db->select("d.*,m.no_po,j.id_jenis_barang,j.nama_jenis_barang,b.id_barang,b.nama_model");
        $this->db->from("itmspati.dbo.detail_po d");
        $this->db->join("barang b","b.id_barang=d.id_barang");
        $this->db->join("jenis_barang j","j.id_jenis_barang=b.id_jenis_barang");
        $this->db->join("master_po m","m.id_po=d.id_po");
        $this->db->where("d.id_po =",$id_po);
        $this->db->where("d.jenis_aset =",0);
        $i = 0;
        foreach ($this->column_search_po as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search_po) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order_po[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order_po)){
            $order = $this->order_po;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables_po($id_po){
        $this->get_datatables_konfirm_po($id_po);
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_po($id_po){
        $this->get_datatables_konfirm_po($id_po);
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_po($id_po){
        $this->db->select("*");
        $this->db->from("itmspati.dbo.detail_po");
        $this->db->where("id_po =",$id_po);
        $this->db->where("jenis_aset =",0);
        return $this->db->count_all_results();
    }

    function count_konfirm_po(){
        $query = $this->db->query("
            SELECT id_po FROM itmspati.dbo.detail_po WHERE jenis_aset = 0 GROUP BY id_po
            ");
        return $query;
    }

    function count_konfirm_rental(){
        $query = $this->db->query("
            SELECT id_po FROM itmspati.dbo.detail_po WHERE jenis_aset = 1 GROUP BY id_po
            ");
        return $query;
    }

    function count_konfirm_cms(){
        $query = $this->db->query("
            SELECT id_po FROM itmspati.dbo.detail_po_cms WHERE [status] = '0' GROUP BY id_po
        ");
        return $query;
    }

    // function get_data_hwi1(){
    //     $query = $this->db->query("
    //         SELECT TOP 5 j.nama_jenis_barang, b.nama_model, count(s.id_stok) AS jumlah
    //         FROM stock_barang s
    //         JOIN barang b ON b.id_barang = s.id_barang
    //         JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
    //         WHERE SUBSTRING(s.id_stok,1,3) <> 'hwp'
    //         GROUP BY j.nama_jenis_barang, b.nama_model
    //         ORDER BY COUNT(s.id_stok) DESC
    //     ");
    //     return $query;
    // }
}

?>