<?php
class M_log extends CI_Model{

    var $column_order = array(null,'l.id_stock','l.status_log','s.nama_supplier','l.tgl','l.po_srt_jln','l.keterangan','l.created_at');
    var $column_search = array('l.id_stock','l.status_log','s.nama_supplier','l.tgl','l.po_srt_jln','l.keterangan','l.created_at');
    var $order = array('l.created_at'=>'DESC');

    function insert_log($id_log,$id_stok,$id_aset,$status_keterangan,$vendor,$tgl,$surat_jalan,$keterangan,$updated_at,$id_user){
        $query = $this->db->query("
            INSERT INTO itmspati.dbo.log(id_log,id_stock,id_aset,status_log,supplier,tgl,po_srt_jln,keterangan,created_at,section)
            VALUES('$id_log','$id_stok','$id_aset','$status_keterangan','$vendor','$tgl','$surat_jalan','$keterangan','$updated_at','$id_user')
            ");
        return $query;
    }

    function get_nama_model($id_stok){
        $query = $this->db->query("
            SELECT s.windows_ori,s.office_ori,s.serial_number,s.serial_number_office,s.os, s.id_aset, b.nama_model, s.id_transaksi, t.nama_aset, sp.nama_supplier, t.kode FROM itmspati.dbo.stock_barang s
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            JOIN kelompok_aset t ON t.kode = j.kel_asset
            JOIN supplier sp ON sp.id_supplier = s.id_supplier
            WHERE s.id_stok = '$id_stok'");
        return $query;
    }

    function get_datatables_log($id_stok){
        $this->db->select("l.id_stock,l.status_log,s.nama_supplier,l.tgl,l.po_srt_jln,l.keterangan,l.created_at");
        $this->db->from("itmspati.dbo.log l");
        $this->db->join("supplier s","s.id_supplier=l.supplier","LEFT");
        $this->db->where("l.id_stock =",$id_stok);
        $i = 0;
        foreach ($this->column_search as $item){
            if(@$_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables($id_stok){
        $this->get_datatables_log($id_stok);
        if(@$_POST['length'] != -1)
        $this->db->limit(@$_POST['length'], @$_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered($id_stok){
        $this->get_datatables_log($id_stok);
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all($id_stok){
        $this->db->select('*');
        $this->db->from('itmspati.dbo.log');
        $this->db->where('id_stock =',$id_stok);        
        return $this->db->count_all_results();
    }

    function data_transaksi($id_transaksi){
        $query = $this->db->query("SELECT * FROM transaksi_pembelian WHERE id_transaksi = '$id_transaksi'");
        return $query;
    }

    function data_transaksi_proyek($id_transaksi){
        $query = $this->db->query("SELECT * FROM master_proyek WHERE id_proyek = '$id_transaksi'");
        return $query;
    }

    var $column_order_log = array(null,'l.id_stock','b.nama_model','s.sn','l.id_aset','l.status_log','sp.nama_supplier','l.tgl','l.po_srt_jln','l.keterangan','u.nama_user','l.created_at');
    var $column_search_log = array('l.id_stock','b.nama_model','s.sn','l.id_aset','l.status_log','sp.nama_supplier','l.tgl','l.po_srt_jln','l.keterangan','u.nama_user','l.created_at');
    var $order_log = array('l.created_at'=>'DESC');

    function get_datatables_log_barang(){
        $this->db->select("l.id_stock,b.nama_model,s.sn,l.id_aset,l.status_log,sp.nama_supplier,l.tgl,l.po_srt_jln,l.keterangan,u.nama_user,l.created_at");
        $this->db->from("itmspati.dbo.log l");
        $this->db->join("itmspati.dbo.stock_barang s","s.id_stok=l.id_stock");
        $this->db->join("barang b","b.id_barang=s.id_barang");
        $this->db->join("supplier sp","sp.id_supplier=l.supplier","left");
        $this->db->join("itmspati.dbo.users u","u.username=l.section","left");
        $i = 0;
        foreach ($this->column_search_log as $item){
            if(@$_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search_log) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order_log[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order_log)){
            $order = $this->order_log;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables_log_barang2(){
        $this->get_datatables_log_barang();
        if(@$_POST['length'] != -1)
        $this->db->limit(@$_POST['length'], @$_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_log(){
        $this->get_datatables_log_barang();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_log(){
        $this->db->select('*');
        $this->db->from('itmspati.dbo.log'); 
        return $this->db->count_all_results();
    }

    function get_info_log(){
        $query = $this->db->query("
            SELECT TOP 5 l.*,b.nama_model,s.sn FROM itmspati.dbo.log l
            JOIN itmspati.dbo.stock_barang s ON s.id_stok = l.id_stock
            JOIN barang b ON b.id_barang = s.id_barang
            ORDER BY l.created_at DESC
            ");
        return $query;
    }

    function insert_log_jepara($id_log,$id_stok,$id_aset,$status_keterangan,$keterangan,$updated_at,$id_user){
        $query = $this->db->query("INSERT INTO itmsdata.itms.log (id_log,id_stock,id_aset,status_log,keterangan,created_at,section)
            VALUES ('$id_log','$id_stok','$id_aset','$status_keterangan','$keterangan','$updated_at','$id_user')");
        return $query;
    }

    function insert_log_proyek($id_log,$id_stock,$status_log,$tanggal,$keterangan,$id_user){
        $query = $this->db->query("
            INSERT INTO log (id_log,id_stock,status_log,tgl,keterangan,section)
            VALUES ('$id_log','$id_stock','$status_log','$tanggal','$keterangan','$id_user')
        ");
        return $query;
    }
}
?>