<?php
class M_surat extends CI_Model{

    var $table = "surat_kategori";
    var $column_order = array(null, 'id_kategori','nama_kategori','created_at','updated_at');
    var $column_search = array('id_kategori','nama_kategori','created_at','updated_at');
    var $order = array('id_kategori' => 'asc');

    function get_datatables_kategori(){
        $this->db->select("*");
        $this->db->from("surat_kategori");
        $i = 0;
        foreach ($this->column_search as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables(){
        $this->get_datatables_kategori();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered(){
        $this->get_datatables_kategori();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all(){
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
    
    function cek_kategori(){
        $query = $this->db->query("
            SELECT * FROM surat_kategori ORDER BY id_kategori DESC 
        ");
        return $query;
    }

    function get_all_posisi(){
        $query = $this->db->query("
            SELECT id_posisi, nama_posisi FROM surat_posisi ORDER BY id_posisi ASC
        ");
        return $query;
    }

    function add_kategori($id_kategori,$nama_kategori,$updated_at){
        $query = $this->db->query("
            INSERT INTO surat_kategori(id_kategori,nama_kategori,updated_at)
            VALUES('$id_kategori','$nama_kategori','$updated_at')
        ");
        return $query;
    }

    function get_data_kategori($id_kategori){
        $query = $this->db->query("
            SELECT * FROM surat_kategori WHERE id_kategori = '$id_kategori'
        ");
        return $query;
    }

    function update_kategori($id_kategori,$nama_kategori,$updated_at){
        $query = $this->db->query("
            UPDATE surat_kategori SET nama_kategori = '$nama_kategori', updated_at = '$updated_at' WHERE id_kategori = '$id_kategori'
        ");
        return $query;
    }

    var $column_order_surat = array(null, 's.id_surat','s.nama_user','l.nama_lokasi','s.detail_dept','s.posisi_user','k.nama_kategori','s.deskripsi','s.tanggal_masuk','s.tanggal_approve','s.status','s.file_surat','s.updated_at');
    var $column_search_surat = array('s.id_surat','s.nama_user','l.nama_lokasi','s.detail_dept','s.posisi_user','k.nama_kategori','s.deskripsi','s.tanggal_masuk','s.tanggal_approve','s.status','s.file_surat','s.updated_at');
    var $order_surat = array('s.id_surat' => 'desc');

    function get_datatables_master_surat(){
        $this->db->select("s.*, l.nama_lokasi, k.nama_kategori, p.nama_posisi");
        $this->db->from("surat_master s");
        $this->db->join("lokasi l","l.id_lokasi=s.departemen");
        $this->db->join("surat_kategori k","k.id_kategori=s.kategori_surat");
        $this->db->join("surat_posisi p","p.id_posisi=s.posisi_user");
        $i = 0;
        foreach ($this->column_search_surat as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search_surat) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order_surat[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order_surat;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables_surat(){
        $this->get_datatables_master_surat();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_surat(){
        $this->get_datatables_master_surat();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_surat(){
        $this->db->select("*");
        $this->db->from("surat_master");
        return $this->db->count_all_results();
    }

    function cek_surat(){
        $query = $this->db->query("
            SELECT * FROM surat_master ORDER BY id_surat DESC
        ");
        return $query;
    }

    function add_surat_2($id_surat,$nama_user,$departemen,$detail_dept,$posisi_user,$kategori_surat,$deskripsi,$tanggal_masuk,$tanggal_approve,$status,$file_surat,$updated_at){
        $query = $this->db->query("
            INSERT INTO surat_master(id_surat,nama_user,departemen,detail_dept,posisi_user,kategori_surat,deskripsi,tanggal_masuk,tanggal_approve,status,file_surat,updated_at)
            VALUES('$id_surat','$nama_user','$departemen','$detail_dept','$posisi_user','$kategori_surat','$deskripsi','$tanggal_masuk','$tanggal_approve','$status','$file_surat','$updated_at')
        ");
        return $query;
    }

    function add_surat_1($id_surat,$nama_user,$departemen,$detail_dept,$posisi_user,$kategori_surat,$deskripsi,$tanggal_masuk,$status,$file_surat,$updated_at){
        $query = $this->db->query("
            INSERT INTO surat_master(id_surat,nama_user,departemen,detail_dept,posisi_user,kategori_surat,deskripsi,tanggal_masuk,status,file_surat,updated_at)
            VALUES('$id_surat','$nama_user','$departemen','$detail_dept','$posisi_user','$kategori_surat','$deskripsi','$tanggal_masuk','$status','$file_surat','$updated_at')
        ");
        return $query;
    }

    function get_by_id($id_surat){
        $query = $this->db->query("
            SELECT s.*, l.nama_lokasi, k.nama_kategori, p.nama_posisi
            FROM surat_master s
            JOIN lokasi l ON l.id_lokasi = s.departemen
            JOIN surat_kategori k ON k.id_kategori = s.kategori_surat
            JOIN surat_posisi p ON p.id_posisi = s.posisi_user
            WHERE s.id_surat = '$id_surat'
        ");
        return $query;
    }

    function dept_by_id($dept){
        $query = $this->db->query("
            SELECT * FROM lokasi WHERE id_lokasi <> '$dept'
        ");
        return $query;
    }

    function kat_by_id($kat){
        $query = $this->db->query("
            SELECT * FROM surat_kategori WHERE id_kategori <> '$kat'
        ");
        return $query;
    }

    function pos_by_id($pos_user){
        $query = $this->db->query("
            SELECT * FROM surat_posisi WHERE id_posisi <> '$pos_user'
        ");
        return $query;
    }

    function update_surat_1($id_surat,$nama_user,$departemen,$detail_dept,$posisi_user,$kategori_surat,$deskripsi,$tanggal_masuk,$status,$updated_at){
        $query = $this->db->query("
            UPDATE surat_master SET nama_user='$nama_user',departemen='$departemen',detail_dept='$detail_dept',posisi_user='$posisi_user',kategori_surat='$kategori_surat',deskripsi='$deskripsi',
            tanggal_masuk='$tanggal_masuk',status='$status',updated_at='$updated_at' WHERE id_surat='$id_surat'
        ");
        return $query;
    }

    function update_surat_2($id_surat,$nama_user,$departemen,$detail_dept,$posisi_user,$kategori_surat,$deskripsi,$tanggal_masuk,$tanggal_approve,$status,$updated_at){
        $query = $this->db->query("
            UPDATE surat_master SET nama_user='$nama_user',departemen='$departemen',detail_dept='$detail_dept',posisi_user='$posisi_user',kategori_surat='$kategori_surat',deskripsi='$deskripsi',
            tanggal_masuk='$tanggal_masuk',tanggal_approve='$tanggal_approve',status='$status',updated_at='$updated_at' WHERE id_surat='$id_surat'
        ");
        return $query;
    }
}
?>