<?php
class M_karyawan extends CI_Model{

	var $column_order = array(null, 's.nik','f.NAME','f.DEPARTEMENT','f.NAMA_GEDUNG','s.id_stok','j.nama_jenis_barang','s.sn','l.nama_lokasi');
    var $column_search = array('s.nik','f.NAME','f.DEPARTEMENT','f.NAMA_GEDUNG','s.id_stok','j.nama_jenis_barang','s.sn','l.nama_lokasi');
    var $order = array('s.nik' => 'asc');
	
    function get_datatables_karyawan_resign($where){
        $this->db->select("s.nik,f.NAME,f.DEPARTEMENT,f.NAMA_GEDUNG,s.id_stok,j.nama_jenis_barang,s.sn,l.nama_lokasi");
        $this->db->from("stock_barang s");
        $this->db->join("barang b","b.id_barang=s.id_barang");
        $this->db->join("jenis_barang j","j.id_jenis_barang=b.id_jenis_barang");
        $this->db->join("lokasi l","l.id_lokasi=s.lokasi");
        $this->db->join("FLD.dbo.VIEW_MASTER_KARYAWAN f","f.NIK=s.nik");
        $this->db->where($where);
        //$this->db->order_by("s.nik","ASC");
        $i = 0;
        foreach ($this->column_search as $item){
            if(@$_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables($where){
        $this->get_datatables_karyawan_resign($where);
        if(@$_POST['length'] != -1)
        $this->db->limit(@$_POST['length'], @$_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered($where){
        $this->get_datatables_karyawan_resign($where);
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all($where){
        $this->db->select("s.nik,f.NAME,f.DEPARTEMENT,f.NAMA_GEDUNG,s.id_stok,j.nama_jenis_barang,l.nama_lokasi");
        $this->db->from("stock_barang s");
        $this->db->join("barang b","b.id_barang=s.id_barang");
        $this->db->join("jenis_barang j","j.id_jenis_barang=b.id_jenis_barang");
        $this->db->join("lokasi l","l.id_lokasi=s.lokasi");
        $this->db->join("FLD.dbo.VIEW_MASTER_KARYAWAN f","f.NIK=s.nik");
        $this->db->where($where);
        return $this->db->count_all_results();
    }

    function get_data_aset($id_stok){
        $query = $this->db->query("
            SELECT s.nik, f.NAME FROM stock_barang s
            JOIN FLD.dbo.VIEW_MASTER_KARYAWAN f ON f.NIK = s.nik 
            WHERE s.id_stok = '$id_stok'
        ");
        return $query;
    }

    function get_row_karyawan($nik){
        $query = $this->db->query("
            SELECT NAME FROM FLD.dbo.VIEW_MASTER_KARYAWAN WHERE NIK = '$nik'
        ");
        return $query;
    }

    function update_pengguna($id_stok,$nik,$nama_user,$updated_at,$id_user){
        $query = $this->db->query("
            UPDATE stock_barang SET nik = '$nik', nama_user = '$nama_user', updated_at = '$updated_at', id_user = '$id_user'
            WHERE id_stok = '$id_stok'
        ");
        return $query;
    }

    function get_data_resign(){
        $query = $this->db->query("
            SELECT TOP 3 s.nik, f.NAME, f.DEPARTEMENT, f.NAMA_GEDUNG
            FROM stock_barang s
            JOIN FLD.dbo.VIEW_MASTER_KARYAWAN f ON f.NIK = s.nik
            WHERE TERMINATION <> ''
            GROUP BY s.nik, f.NAME, f.DEPARTEMENT, f.NAMA_GEDUNG
        ");
        return $query;
    }

}?>