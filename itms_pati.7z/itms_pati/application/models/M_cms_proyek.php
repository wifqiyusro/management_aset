<?php
class M_cms_proyek extends CI_Model{

    var $table = 'itmspati.dbo.cms_proyek';
	var $column_order = array(null, 'kode_barang','nama_barang','satuan','isi_per_pack','stok','min_stok','created_at','updated_at');
    var $column_search = array('kode_barang','nama_barang','satuan','isi_per_pack','stok','min_stok','created_at','updated_at');
    var $order = array('updated_at' => 'desc');

    function get_datatables_barang(){
        $this->db->select("*,floor(stok/isi_per_pack) as pack,floor(stok%isi_per_pack) as pcs");
        $this->db->from("itmspati.dbo.cms_proyek");
        $i = 0;
        foreach ($this->column_search as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables(){
        $this->get_datatables_barang();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered(){
        $this->get_datatables_barang();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all(){
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

    var $column_order_detail_log = array(null, 'l.kode_barang','c.nama_barang','l.aktivitas','l.jumlah','c.satuan','l.tanggal','l.surat_jalan','l.pengguna','l.keperluan','l.created_at');
    var $column_search_detail_log = array('l.kode_barang','c.nama_barang','l.aktivitas','l.jumlah','c.satuan','l.tanggal','l.surat_jalan','l.pengguna','l.keperluan','l.created_at');
    var $order_detail_log = array('l.created_at' => 'desc');

    function get_datatables_detail_log($kode_barang){
        if($this->input->post('tgl_mulai')){
            $this->db->where('l.created_at >=',$this->input->post('tgl_mulai').' 00:00:00');
        }
        if($this->input->post('tgl_selesai')){
            $this->db->where('l.created_at <=',$this->input->post('tgl_selesai').' 23:59:59');
        }

        $this->db->select("l.*,c.nama_barang,c.satuan");
        $this->db->from("itmspati.dbo.log_cms_proyek l");
        $this->db->join("itmspati.dbo.cms_proyek c","c.kode_barang=l.kode_barang");
        $this->db->where("l.kode_barang =",$kode_barang);

        $i = 0;
        foreach ($this->column_search_detail_log as $item){
            if(@$_POST['search']['value']){   
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search_detail_log) - 1 == $i) 
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order_detail_log[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }else if(isset($this->order_detail_log)){
            $order = $this->order_detail_log;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables_detail_log_cms($kode_barang){
        $this->get_datatables_detail_log($kode_barang);
        if(@$_POST['length'] != -1)
        $this->db->limit(@$_POST['length'], @$_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_detail_log($kode_barang){
        $this->get_datatables_detail_log($kode_barang);
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_detail_log($kode_barang){
        $this->db->select("*");
        $this->db->from("itmspati.dbo.log_cms_proyek");
        $this->db->where("kode_barang =",$kode_barang);
        return $this->db->count_all_results();
    }

    function export_detail_log_cms1($kode_barang){
        $query = $this->db->query("
            SELECT CASE
                WHEN l.aktivitas = '0' THEN 'Ditambahkan'
                WHEN l.aktivitas = '1' THEN 'Edit Data'
                WHEN l.aktivitas = '2' THEN 'Masuk'
                WHEN l.aktivitas = '3' THEN 'Keluar'
                WHEN l.aktivitas = '4' THEN 'Kembali'
                ELSE 'Proses PO'
            END AS aktivitas,l.jumlah,l.sisa,c.satuan,l.tanggal,l.surat_jalan,l.pengguna,l.keperluan,l.created_at
            FROM itmspati.dbo.log_cms_proyek l
            JOIN itmspati.dbo.cms_proyek c ON c.kode_barang = l.kode_barang
            WHERE l.kode_barang = '$kode_barang'
            ORDER BY l.created_at DESC
        ");
        return $query;
    }

    function export_detail_log_cms2($kode_barang,$tanggal_mulai){
        $query = $this->db->query("
            SELECT CASE
                WHEN l.aktivitas = '0' THEN 'Ditambahkan'
                WHEN l.aktivitas = '1' THEN 'Edit Data'
                WHEN l.aktivitas = '2' THEN 'Masuk'
                WHEN l.aktivitas = '3' THEN 'Keluar'
                WHEN l.aktivitas = '4' THEN 'Kembali'
                ELSE 'Proses PO'
            END AS aktivitas,l.jumlah,l.sisa,c.satuan,l.tanggal,l.surat_jalan,l.pengguna,l.keperluan,l.created_at
            FROM itmspati.dbo.log_cms_proyek l
            JOIN itmspati.dbo.cms_proyek c ON c.kode_barang = l.kode_barang
            WHERE l.kode_barang = '$kode_barang' AND l.created_at >= '$tanggal_mulai'
            ORDER BY l.created_at DESC
        ");
        return $query;
    }

    function export_detail_log_cms3($kode_barang,$tanggal_selesai){
        $query = $this->db->query("
            SELECT CASE
                WHEN l.aktivitas = '0' THEN 'Ditambahkan'
                WHEN l.aktivitas = '1' THEN 'Edit Data'
                WHEN l.aktivitas = '2' THEN 'Masuk'
                WHEN l.aktivitas = '3' THEN 'Keluar'
                WHEN l.aktivitas = '4' THEN 'Kembali'
                ELSE 'Proses PO'
            END AS aktivitas,l.jumlah,l.sisa,c.satuan,l.tanggal,l.surat_jalan,l.pengguna,l.keperluan,l.created_at
            FROM itmspati.dbo.log_cms_proyek l
            JOIN itmspati.dbo.cms_proyek c ON c.kode_barang = l.kode_barang
            WHERE l.kode_barang = '$kode_barang' AND l.created_at <= '$tanggal_selesai'
            ORDER BY l.created_at DESC
        ");
        return $query;
    }

    function export_detail_log_cms4($kode_barang,$tanggal_mulai,$tanggal_selesai){
        $query = $this->db->query("
            SELECT CASE
                WHEN l.aktivitas = '0' THEN 'Ditambahkan'
                WHEN l.aktivitas = '1' THEN 'Edit Data'
                WHEN l.aktivitas = '2' THEN 'Masuk'
                WHEN l.aktivitas = '3' THEN 'Keluar'
                WHEN l.aktivitas = '4' THEN 'Kembali'
                ELSE 'Proses PO'
            END AS aktivitas,l.jumlah,l.sisa,c.satuan,l.tanggal,l.surat_jalan,l.pengguna,l.keperluan,l.created_at
            FROM itmspati.dbo.log_cms_proyek l
            JOIN itmspati.dbo.cms_proyek c ON c.kode_barang = l.kode_barang
            WHERE l.kode_barang = '$kode_barang' AND l.created_at BETWEEN '$tanggal_mulai' AND '$tanggal_selesai'
            ORDER BY l.created_at DESC
        ");
        return $query;
    }

    function add_barang($kode_barang,$nama_barang,$satuan,$isi_per_pack,$min_stok,$updated_at,$id_user){
        $query = $this->db->query("
            INSERT INTO itmspati.dbo.cms_proyek(kode_barang,nama_barang,satuan,stok,isi_per_pack,min_stok,updated_at,id_user)
            VALUES('$kode_barang','$nama_barang','$satuan','0','$isi_per_pack','$min_stok','$updated_at','$id_user')
            ");
        return $query;
    }

    function get_data_barang($kode_barang){
        $query = $this->db->query("SELECT * FROM itmspati.dbo.cms_proyek WHERE kode_barang = '$kode_barang'");
        return $query;
    }

    function update_barang($kode_barang,$nama_barang,$satuan,$isi_per_pack,$min_stok,$updated_at,$id_user){
        $query = $this->db->query("UPDATE itmspati.dbo.cms_proyek SET nama_barang='$nama_barang',satuan='$satuan',isi_per_pack='$isi_per_pack',min_stok='$min_stok',updated_at='$updated_at',id_user='$id_user' WHERE kode_barang='$kode_barang'");
        return $query;
    }

    function get_stok($kode_barang){
        $query = $this->db->query("SELECT stok FROM itmspati.dbo.cms_proyek WHERE kode_barang = '$kode_barang'");
        return $query;
    }

    function transaksi($kode_barang,$stok_update,$updated_at,$id_user){
        $query = $this->db->query("UPDATE itmspati.dbo.cms_proyek SET stok = '$stok_update', updated_at = '$updated_at', id_user = '$id_user' WHERE kode_barang = '$kode_barang'");
        return $query;
    }

    function insert_log($id_log,$kode_barang,$aktivitas,$jumlah,$stok_update,$surat_jalan,$pengguna,$tanggal,$keperluan,$id_user){
        $query = $this->db->query("INSERT INTO itmspati.dbo.log_cms_proyek(id_log,kode_barang,aktivitas,jumlah,sisa,surat_jalan,pengguna,tanggal,keperluan,id_user)
            VALUES('$id_log','$kode_barang','$aktivitas','$jumlah','$stok_update','$surat_jalan','$pengguna','$tanggal','$keperluan','$id_user')");
        return $query;
    }

    function get_nama_barang(){
        $query = $this->db->query("SELECT * FROM itmspati.dbo.cms_proyek ORDER BY nama_barang ASC");
        return $query;
    }

    function cek_kode_barang($kode_barang){
        $query = $this->db->query("SELECT * FROM itmspati.dbo.cms_proyek WHERE kode_barang = '$kode_barang'");
        return $query;
    }

    function cek_status_jumlah($kode_barang){
        $query = $this->db->query("SELECT stok FROM itmspati.dbo.cms_proyek WHERE kode_barang = '$kode_barang'");
        return $query;
    }

    var $column_order_log = array(null, 'l.kode_barang','c.nama_barang','l.aktivitas','l.jumlah','c.satuan','l.surat_jalan','l.pengguna','l.tanggal','l.keperluan','u.nama_user','l.created_at');
    var $column_search_log = array('l.kode_barang','c.nama_barang','l.aktivitas','l.jumlah','c.satuan','l.surat_jalan','l.pengguna','l.tanggal','l.keperluan','u.nama_user','l.created_at');
    var $order_log = array('l.created_at' => 'desc');

    function get_datatables_log(){
        $this->db->select("l.kode_barang,c.nama_barang,l.aktivitas,l.jumlah,c.satuan,l.surat_jalan,l.pengguna,l.tanggal,l.keperluan,u.nama_user,l.created_at");
        $this->db->from("itmspati.dbo.log_cms_proyek l");
        $this->db->join("itmspati.dbo.cms_proyek c","c.kode_barang=l.kode_barang");
        $this->db->join("itmspati.dbo.users u","u.username=l.id_user");
        $i = 0;
        foreach ($this->column_search_log as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search_log) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order_log[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order_log)){
            $order = $this->order_log;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables_log_cms_proyek(){
        $this->get_datatables_log();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_log(){
        $this->get_datatables_log();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_log(){
        $this->db->select("*");
        $this->db->from("itmspati.dbo.log_cms_proyek");
        return $this->db->count_all_results();
    }
}
?>