<?php
class M_surat_log extends CI_Model{

    function insert_log($id_log,$id_surat,$status,$id_user,$keterangan){
        $query = $this->db->query("
            INSERT INTO surat_log(id_log_surat,id_surat,status,id_user,keterangan)
            VALUES('$id_log','$id_surat','$status','$id_user','$keterangan')
        ");
        return $query;
    }

    var $column_order = array(null,'s.id_surat','s.nama_user','l.nama_lokasi','k.nama_kategori','s.deskripsi','lg.status','lg.keterangan','lg.created_at');
    var $column_search = array('s.id_surat','s.nama_user','l.nama_lokasi','k.nama_kategori','s.deskripsi','lg.status','lg.keterangan','lg.created_at');
    var $order = array('lg.created_at'=>'DESC');

    function get_datatables_log($id_surat){
        $this->db->select("s.id_surat,s.nama_user,l.nama_lokasi,k.nama_kategori,s.deskripsi,lg.status,lg.keterangan,lg.created_at");
        $this->db->from("surat_log lg");
        $this->db->join("surat_master s","s.id_surat=lg.id_surat");
        $this->db->join("lokasi l","l.id_lokasi=s.departemen");
        $this->db->join("surat_kategori k","k.id_kategori=s.kategori_surat");
        $this->db->where("s.id_surat =","$id_surat");
        $i = 0;
        foreach ($this->column_search as $item){
            if(@$_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables($id_surat){
        $this->get_datatables_log($id_surat);
        if(@$_POST['length'] != -1)
        $this->db->limit(@$_POST['length'], @$_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered($id_surat){
        $this->get_datatables_log($id_surat);
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all($id_surat){
        $this->db->select('*');
        $this->db->from('surat_log');
        $this->db->where('id_surat =',$id_surat);        
        return $this->db->count_all_results();
    }
}
?>