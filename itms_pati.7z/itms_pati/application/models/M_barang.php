<?php
class M_barang extends CI_Model{

    var $table = 'barang';
	var $column_order = array(null, 'id_barang','kode_sap','nama_jenis_barang','nama_model','label_jenis_barang','b.created_at','b.updated_at');
    var $column_search = array('id_barang','kode_sap','nama_jenis_barang','nama_model','label_jenis_barang','b.created_at','b.updated_at');
    var $order = array('nama_jenis_barang' => 'asc');

    function get_datatables_barang(){
        $this->db->select("b.*,j.id_jenis_barang,j.nama_jenis_barang");
        $this->db->from("barang b");
        $this->db->join("jenis_barang j","j.id_jenis_barang=b.id_jenis_barang");
        $i = 0;
        foreach ($this->column_search as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables(){
        $this->get_datatables_barang();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered(){
        $this->get_datatables_barang();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all(){
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

	function get_barang($sambung,$lokasi){
         $query = $this->db->query("
            SELECT DISTINCT s.id_barang, b.nama_model
            FROM stock_barang s
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN jenis_barang J ON j.id_jenis_barang = b.id_jenis_barang
            WHERE j.id_jenis_barang IN ($sambung) AND s.lokasi = '$lokasi'
         ");
        return $query;
    }

    function add_barang($id_barang,$nama_model,$id_jenis_barang,$label_jenis_barang,$updated_at){
        $query = $this->db->query("INSERT INTO barang(id_barang,nama_model,id_jenis_barang,label_jenis_barang,updated_at)
        VALUES('$id_barang','$nama_model','$id_jenis_barang','$label_jenis_barang','$updated_at')");
        return $query;
    }

    function get_data_barang($id_barang){
        $query = $this->db->query("SELECT * FROM barang WHERE id_barang = '$id_barang'");
        return $query;
    }

    function update_barang($id_barang,$nama_model,$id_jenis_barang,$label_barang,$updated_at){
        $query = $this->db->query("UPDATE barang SET nama_model='$nama_model',id_jenis_barang='$id_jenis_barang',label_jenis_barang='$label_barang',updated_at='$updated_at' WHERE id_barang='$id_barang'");
        return $query;
    }

    function cari_barang($id){
        $barang = "<option value='0'>-- Pilih Barang --</option>";
        $this->db->order_by('nama_model','ASC');
        $barang_data = $this->db->get_where($this->table,array('id_jenis_barang'=>$id));

        foreach($barang_data->result_array() as $data){
            $barang.="<option value='$data[id_barang]'>$data[nama_model]</option>";
        }

        return $barang;
    }
}
?>