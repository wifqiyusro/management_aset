<?php
class M_supplier extends CI_Model{

    var $table = 'supplier';
	var $column_order = array(null, 'id_supplier','nama_supplier','alamat_supplier','phone','created_at','updated_at');
    var $column_search = array('id_supplier','nama_supplier','alamat_supplier','phone','created_at','updated_at');
    var $order = array('nama_supplier' => 'asc');

    function get_datatables_supplier(){
        $this->db->select("*");
        $this->db->from("supplier");
        $i = 0;
        foreach ($this->column_search as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables(){
        $this->get_datatables_supplier();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered(){
        $this->get_datatables_supplier();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all(){
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

	function get_data_supplier(){
        $query = $this->db->query("SELECT * FROM supplier ORDER BY nama_supplier ASC");
        return $query;
    }

    function add_supplier($id_supplier,$nama_supplier,$alamat_supplier,$phone,$updated_at){
        $query = $this->db->query("INSERT INTO supplier(id_supplier,nama_supplier,alamat_supplier,phone,updated_at)
        VALUES('$id_supplier','$nama_supplier','$alamat_supplier','$phone','$updated_at')");
        return $query;
    }

    function get_supplier($id_supplier){
        $query = $this->db->query("SELECT * FROM supplier WHERE id_supplier = '$id_supplier'");
        return $query;
    }

    function update_supplier($id_supplier,$nama_supplier,$alamat_supplier,$phone,$updated_at){
        $query = $this->db->query("UPDATE supplier SET nama_supplier='$nama_supplier',alamat_supplier='$alamat_supplier',phone='$phone',updated_at='$updated_at' WHERE id_supplier='$id_supplier'");
        return $query;
    }
}
?>