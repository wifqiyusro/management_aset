<?php
class M_report extends CI_Model{

    function get_summary_aset1(){
        $query = $this->db->query("
            SELECT A.*, (select count(nama_jenis_barang) from itmspati.dbo.summary_aset1 
            where nama_jenis_barang = A.nama_jenis_barang) as kode  FROM itmspati.dbo.summary_aset1 A
        ");
        return $query;
    }

	function get_po_aset(){
        $query = $this->db->query("
        SELECT DISTINCT no_po, id_transaksi = SUBSTRING (( 
            SELECT ''',''' + o.id_transaksi FROM
            (
            SELECT t.no_po, s.id_transaksi FROM itmspati.dbo.stock_barang s
            JOIN transaksi_pembelian t on t.id_transaksi = s.id_transaksi   
            JOIN 
            (SELECT no_po FROM transaksi_pembelian) a ON a.no_po = t.no_po
            GROUP BY t.no_po, s.id_transaksi
            ) AS o
            WHERE o.no_po = o2.no_po FOR XML path(''), elements), 3, 500)
            FROM 
            (
            SELECT t.no_po, s.id_transaksi FROM itmspati.dbo.stock_barang s
            JOIN transaksi_pembelian t on t.id_transaksi = s.id_transaksi
            JOIN 
            (SELECT no_po FROM transaksi_pembelian ) a ON a.no_po = t.no_po
            GROUP BY t.no_po, s.id_transaksi
            ) as o2
   
        ");
        return $query;
    }

    var $column_order_po = array(null, 's.id_stok','s.id_aset','j.nama_jenis_barang','b.nama_model','s.kurs','s.harga','l.nama_lokasi','s.detail_lokasi','s.nama_user','s.sn','s.remark','s.status_keterangan','f.NAME','s.nik');
    var $column_search_po = array('s.id_stok','s.id_aset','j.nama_jenis_barang','b.nama_model','s.kurs','s.harga','l.nama_lokasi','s.detail_lokasi','s.nama_user','s.sn','s.remark','s.status_keterangan','f.NAME','s.nik');
    var $order_po = array('j.nama_jenis_barang' => 'asc');

    function get_datatables_po(){
        
        $where = "s.id_transaksi IN (".$this->input->post('id_transaksi').")";
        $where2 = "s.jenis_aset IN ('0','1')";

        if($this->input->post('id_transaksi')){
            $this->db->where($where);
        }      

        $this->db->select("s.id_stok,s.id_transaksi,s.id_aset,j.nama_jenis_barang,b.nama_model,s.kurs,s.harga,l.nama_lokasi,s.detail_lokasi,s.nama_user,s.nik,s.sn,s.remark,s.jenis_aset,s.status_keterangan,f.NAME");
        $this->db->from("itmspati.dbo.stock_barang s");
        $this->db->join("barang b","b.id_barang=s.id_barang");
        $this->db->join("jenis_barang j","j.id_jenis_barang=b.id_jenis_barang");
        $this->db->join("lokasi l","l.id_lokasi=s.lokasi","left");
        $this->db->join("FLD.dbo.VIEW_MASTER_KARYAWAN f","f.NIK=s.nik","left");
        $this->db->where($where2);       
        $i = 0;
        foreach ($this->column_search_po as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search_po) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order_po[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order_po)){
            $order = $this->order_po;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables_po_aset(){
        $this->get_datatables_po();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_po_aset(){
        $this->get_datatables_po();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_po_aset(){
        $this->db->select("*");
        $this->db->from("itmspati.dbo.stock_barang");
        $this->db->where("jenis_aset <>",2);
        return $this->db->count_all_results();
    }

    function get_data_po_aset_1(){
        $query = $this->db->query("
            SELECT t.no_po,sp.nama_supplier,s.id_stok,s.id_aset,j.nama_jenis_barang,b.nama_model,s.epte_code,s.FA_code,s.kurs,s.harga,s.harga_ppn,l.nama_lokasi,s.detail_lokasi,s.nama_user,s.nik,s.sn,
            CASE
                WHEN s.status_keterangan = '0' THEN 'STOCK'
                WHEN s.status_keterangan = '1' THEN 'INSTALLED'
                WHEN s.status_keterangan = '3' THEN 'BROKEN ON IT'
                ELSE 'BROKEN ON VENDOR'
            END AS keterangan, s.jenis_aset, s.remark, f.NAME
            FROM itmspati.dbo.stock_barang s
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            JOIN supplier sp ON sp.id_supplier = s.id_supplier
            JOIN transaksi_pembelian t ON t.id_transaksi = s.id_transaksi
            LEFT JOIN lokasi l ON l.id_lokasi = s.lokasi
            LEFT JOIN FLD.dbo.VIEW_MASTER_KARYAWAN f ON f.NIK = s.nik
            WHERE s.jenis_aset NOT IN ('2','7','8')
        ");
        return $query;
    }

    function get_data_po_aset_2($id_transaksi){
        $query = $this->db->query("
            SELECT t.no_po,sp.nama_supplier,s.id_stok,s.id_aset,j.nama_jenis_barang,b.nama_model,s.epte_code,s.FA_code,s.kurs,s.harga,s.harga_ppn,l.nama_lokasi,s.detail_lokasi,s.nama_user,s.nik,s.sn,
            CASE
                WHEN s.status_keterangan = '0' THEN 'STOCK'
                WHEN s.status_keterangan = '1' THEN 'INSTALLED'
                WHEN s.status_keterangan = '3' THEN 'BROKEN ON IT'
                ELSE 'BROKEN ON VENDOR'
            END AS keterangan, s.jenis_aset, s.remark, f.NAME
            FROM itmspati.dbo.stock_barang s
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            JOIN supplier sp ON sp.id_supplier = s.id_supplier
            JOIN transaksi_pembelian t ON t.id_transaksi = s.id_transaksi
            LEFT JOIN lokasi l ON l.id_lokasi = s.lokasi
            LEFT JOIN FLD.dbo.VIEW_MASTER_KARYAWAN f ON f.NIK = s.nik
            WHERE s.jenis_aset NOT IN ('2','7','8') AND s.id_transaksi IN $id_transaksi
        ");
        return $query;
    }

    function get_po_cms(){
        $query = $this->db->query("
            SELECT d.id_po, m.no_po
            FROM detail_po_cms d
            JOIN master_po m ON d.id_po = m.id_po
            GROUP BY d.id_po,m.no_po
            ORDER BY m.no_po ASC
        ");
        return $query;
    }

    var $column_order_cms = array(null, 'd.id_po','m.no_po','c.nama_barang','d.jumlah','d.jumlah_done','d.jumlah_waiting','c.satuan','d.kurs','d.harga','d.ppn','d.status','d.updated_at');
    var $column_search_cms = array( 'd.id_po','m.no_po','c.nama_barang','d.jumlah','d.jumlah_done','d.jumlah_waiting','c.satuan','d.kurs','d.harga','d.ppn','d.status','d.updated_at');
    var $order_cms = array('c.nama_barang' => 'asc');

    function get_datatables_cms(){

        if($this->input->post('id_po')){
            $this->db->where('d.id_po',$this->input->post('id_po'));
        }

        $this->db->select("d.*,m.no_po,c.nama_barang,c.satuan");
        $this->db->from("detail_po_cms d");
        $this->db->join("cms c","c.kode_barang=d.kode_barang");
        $this->db->join("master_po m","m.id_po=d.id_po");       
        $i = 0;
        foreach ($this->column_search_cms as $item){
            if(@$_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search_cms) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order_cms[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order_cms)){
            $order = $this->order_cms;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables_po_cms(){
        $this->get_datatables_cms();
        if(@$_POST['length'] != -1)
        $this->db->limit(@$_POST['length'], @$_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_po_cms(){
        $this->get_datatables_cms();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_po_cms(){
        $this->db->select("*");
        $this->db->from("detail_po_cms");
        return $this->db->count_all_results();
    }

    function get_po_service(){
        $query = $this->db->query("
            SELECT d.id_po, m.no_po
            FROM detail_po_service d
            JOIN master_po m ON m.id_po = d.id_po
            GROUP BY d.id_po, m.no_po
            ORDER BY m.no_po ASC
        ");
        return $query;
    }

    var $column_order_service = array(null, 'd.id_po','m.no_po','sp.nama_supplier','d.id_stok','b.nama_model','s.sn','d.ppn','d.keterangan','d.status','d.updated_at');
    var $column_search_service = array('d.id_po','m.no_po','sp.nama_supplier','d.id_stok','b.nama_model','s.sn','d.ppn','d.keterangan','d.status','d.updated_at');
    var $order_service = array('b.nama_model' => 'asc');

    function get_datatables_service(){

        if($this->input->post('id_po')){
            $this->db->where('d.id_po',$this->input->post('id_po'));
        }

        $this->db->select("d.*,m.no_po,sp.nama_supplier,b.nama_model,s.sn");
        $this->db->from("detail_po_service d");
        $this->db->join("master_po m","m.id_po=d.id_po");
        $this->db->join("supplier sp","sp.id_supplier=d.id_supplier");
        $this->db->join("barang b","b.id_barang=d.id_barang");
        $this->db->join("stock_barang s","s.id_stok=d.id_stok");              
        $i = 0;
        foreach ($this->column_search_service as $item){
            if(@$_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search_service) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order_service[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order_service)){
            $order = $this->order_service;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables_po_service(){
        $this->get_datatables_service();
        if(@$_POST['length'] != -1)
        $this->db->limit(@$_POST['length'], @$_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_po_service(){
        $this->get_datatables_service();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_po_service(){
        $this->db->select("*");
        $this->db->from("detail_po_service");
        return $this->db->count_all_results();
    }

    var $column_order_sj = array(null, 'sj.surat_jalan','sj.tanggal','s.nama_supplier','d.qr','d.nama_jenis_barang','d.nama_model','d.unit','d.qty','d.sn','d.no_po','d.keterangan');
    var $column_search_sj = array('sj.surat_jalan','sj.tanggal','s.nama_supplier','d.qr','d.nama_jenis_barang','d.nama_model','d.unit','d.qty','d.sn','d.no_po','d.keterangan');
    var $order_sj = array('sj.tanggal' => 'desc');

    function get_datatables_surat_jalan(){

        $id_surat_jalan = '-';

        // if($this->input->post('id_surat_jalan')){
        //     $this->db->where('d.id_surat_jalan ',$this->input->post('id_surat_jalan'));
        // }
        $this->db->where('d.id_surat_jalan =', ($this->input->post('id_surat_jalan') == NULL ? $id_surat_jalan : $this->input->post('id_surat_jalan')));

        $this->db->select("d.*,sj.surat_jalan,sj.tanggal,s.nama_supplier");
        $this->db->from("data_surat_jalan d");
        $this->db->join("surat_jalan sj","sj.id_surat_jalan=d.id_surat_jalan");
        $this->db->join("supplier s","s.id_supplier=sj.supplier");                     
        $i = 0;
        foreach ($this->column_search_sj as $item){
            if(@$_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search_sj) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order_sj[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order_sj)){
            $order = $this->order_sj;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables_sj(){
        $this->get_datatables_surat_jalan();
        if(@$_POST['length'] != -1)
        $this->db->limit(@$_POST['length'], @$_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_sj(){
        $this->get_datatables_surat_jalan();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_sj(){
        $this->db->select("d.*");
        $this->db->from("data_surat_jalan d");
        $this->db->join("surat_jalan sj","sj.id_surat_jalan=d.id_surat_jalan");
        $this->db->where("sj.status=",1);
        return $this->db->count_all_results();
    }

    function get_data_po_cms_1(){
        $query = $this->db->query("
            SELECT m.id_po,m.no_po,b.nama_barang,c.jumlah,c.jumlah_done,c.jumlah_waiting,b.satuan,c.kurs,c.harga,
            c.ppn,c.no_surat_jalan,c.[status],c.updated_at
            FROM detail_po_cms c
            JOIN master_po m ON m.id_po = c.id_po
            JOIN cms b ON b.kode_barang = c.kode_barang
            ORDER BY b.nama_barang ASC
        ");
        return $query;
    }

    function get_data_po_cms_2($id_po){
        $query = $this->db->query("
            SELECT m.id_po,m.no_po,b.nama_barang,c.jumlah,c.jumlah_done,c.jumlah_waiting,b.satuan,c.kurs,c.harga,
            c.ppn,c.no_surat_jalan,c.[status],c.updated_at
            FROM detail_po_cms c
            JOIN master_po m ON m.id_po = c.id_po
            JOIN cms b ON b.kode_barang = c.kode_barang
            WHERE m.id_po = '$id_po'
            ORDER BY b.nama_barang ASC
        ");
        return $query;
    }

    var $column_order_proyek = array(null, 's.id_stok','s.id_aset','j.nama_jenis_barang','b.nama_model','l.nama_lokasi','s.detail_lokasi','s.nama_user','s.sn','s.remark','s.status_keterangan','f.NAME','s.nik');
    var $column_search_proyek = array('s.id_stok','s.id_aset','j.nama_jenis_barang','b.nama_model','l.nama_lokasi','s.detail_lokasi','s.nama_user','s.sn','s.remark','s.status_keterangan','f.NAME','s.nik');
    var $order_proyek = array('j.nama_jenis_barang' => 'asc');

    function get_datatables_report_proyek(){
        
        if($this->input->post('id_proyek')){
            $this->db->where('s.id_transaksi',$this->input->post('id_proyek'));
        }     

        $this->db->select("s.id_stok,s.id_transaksi,s.id_aset,j.nama_jenis_barang,b.nama_model,l.nama_lokasi,s.detail_lokasi,s.nama_user,s.nik,s.sn,s.remark,s.status_keterangan,f.NAME");
        $this->db->from("itmspati.dbo.stock_barang s");
        $this->db->join("barang b","b.id_barang=s.id_barang");
        $this->db->join("jenis_barang j","j.id_jenis_barang=b.id_jenis_barang");
        $this->db->join("lokasi l","l.id_lokasi=s.lokasi","left");
        $this->db->join("FLD.dbo.VIEW_MASTER_KARYAWAN f","f.NIK=s.nik","left");
        $this->db->where("s.jenis_aset =",2);       
        $i = 0;
        foreach ($this->column_search_proyek as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search_proyek) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order_proyek[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order_proyek)){
            $order = $this->order_proyek;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables_proyek(){
        $this->get_datatables_report_proyek();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_proyek(){
        $this->get_datatables_report_proyek();
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_proyek(){
        $this->db->select("*");
        $this->db->from("itmspati.dbo.stock_barang");
        $this->db->where("jenis_aset =",2);
        return $this->db->count_all_results();
    }

    function get_data_proyek_1(){
        $query = $this->db->query("
            SELECT s.*, b.nama_model, j.nama_jenis_barang, l.nama_lokasi, sp.nama_supplier, m.nama_proyek, f.NAME
            FROM stock_barang s
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            LEFT JOIN lokasi l ON l.id_lokasi = s.lokasi
            JOIN supplier sp ON sp.id_supplier = s.id_supplier
            JOIN master_proyek m ON m.id_proyek = s.id_transaksi
            LEFT JOIN FLD.dbo.VIEW_MASTER_KARYAWAN f ON f.NIK = s.nik 
            WHERE s.jenis_aset = '2'
            ORDER BY j.nama_jenis_barang ASC
        ");
        return $query;
    }

    function get_data_proyek_2($id_proyek){
        $query = $this->db->query("
            SELECT s.*, b.nama_model, j.nama_jenis_barang, l.nama_lokasi, sp.nama_supplier, m.nama_proyek, f.NAME
            FROM stock_barang s
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            LEFT JOIN lokasi l ON l.id_lokasi = s.lokasi
            JOIN supplier sp ON sp.id_supplier = s.id_supplier
            JOIN master_proyek m ON m.id_proyek = s.id_transaksi
            LEFT JOIN FLD.dbo.VIEW_MASTER_KARYAWAN f ON f.NIK = s.nik
            WHERE m.id_proyek = '$id_proyek' AND s.jenis_aset = '2'
            ORDER BY j.nama_jenis_barang ASC
        ");
        return $query;
    }

    var $column_order_hwi1 = array(null, 's.id_stok','t.no_po','p.nama_proyek','s.id_aset','j.nama_jenis_barang','b.nama_model','s.kurs','s.harga','l.nama_lokasi','s.detail_lokasi','s.nama_user','s.sn','s.remark','s.status_keterangan','f.NAME');
    var $column_search_hwi1 = array('s.id_stok','t.no_po','p.nama_proyek','s.id_aset','j.nama_jenis_barang','b.nama_model','s.kurs','s.harga','l.nama_lokasi','s.detail_lokasi','s.nama_user','s.sn','s.remark','s.status_keterangan','f.NAME');
    var $order_hwi1 = array('j.nama_jenis_barang' => 'asc');

    function get_datatables_data_hwi1($where){  

        $this->db->select("s.id_stok,t.no_po,p.nama_proyek,s.id_aset,j.nama_jenis_barang,b.nama_model,s.kurs,s.harga,l.nama_lokasi,s.detail_lokasi,s.nama_user,s.nik,s.sn,s.remark,s.jenis_aset,s.status_keterangan,f.NAME");
        $this->db->from("itmspati.dbo.stock_barang s");
        $this->db->join("barang b","b.id_barang=s.id_barang");
        $this->db->join("jenis_barang j","j.id_jenis_barang=b.id_jenis_barang");
        $this->db->join("lokasi l","l.id_lokasi=s.lokasi","left");
        $this->db->join("transaksi_pembelian t","t.id_transaksi=s.id_transaksi","left");
        $this->db->join("master_proyek p","p.id_proyek=s.id_transaksi","left");
        $this->db->join("FLD.dbo.VIEW_MASTER_KARYAWAN f","f.NIK=s.nik","left");
        $this->db->where($where);       
        $i = 0;
        foreach ($this->column_search_hwi1 as $item){
            if($_POST['search']['value']){
                if($i===0){
                    $this->db->group_start();
                    $this->db->like($item, $_POST['search']['value']);
                }else{
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search_hwi1) - 1 == $i)
                    $this->db->group_end();
            }
            $i++;
        }
        if(isset($_POST['order'])){
            $this->db->order_by($this->column_order_hwi1[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }elseif(isset($this->order_hwi1)){
            $order = $this->order_hwi1;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables_hwi1($where){
        $this->get_datatables_data_hwi1($where);
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered_hwi1($where){
        $this->get_datatables_data_hwi1($where);
        $query = $this->db->get();
        return $query->num_rows();
    }

    function count_all_hwi1($where){
        $this->db->select("*");
        $this->db->from("itmspati.dbo.stock_barang");
        $this->db->where($where);
        return $this->db->count_all_results();
    }

    function export_data_hwi1(){
        $query = $this->db->query("
            SELECT s.*,
            CASE
                WHEN s.status_keterangan = '0' THEN 'STOCK'
                WHEN s.status_keterangan = '1' THEN 'INSTALLED'
                WHEN s.status_keterangan = '3' THEN 'BROKEN ON IT'
                ELSE 'BROKEN ON VENDOR'
            END AS status,t.no_po, p.nama_proyek, j.nama_jenis_barang, b.nama_model, l.nama_lokasi, f.NAME
            FROM stock_barang s
            JOIN barang b ON b.id_barang = s.id_barang
            JOIN jenis_barang j ON j.id_jenis_barang = b.id_jenis_barang
            LEFT JOIN lokasi l ON l.id_lokasi = s.lokasi
            LEFT JOIN transaksi_pembelian t ON t.id_transaksi = s.id_transaksi
            LEFT JOIN master_proyek p ON p.id_proyek = s.id_transaksi
            LEFT JOIN FLD.dbo.VIEW_MASTER_KARYAWAN f ON f.NIK = s.nik
            WHERE SUBSTRING(id_stok,1,3) <> 'hwp'
            ORDER BY s.status_keterangan DESC
        ");
        return $query;
    }

}
?>