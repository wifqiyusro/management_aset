      <main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Transaksi Barang Rusak di IT</h2>
              <div class="card shadow mb-4">
                <?php if($this->session->flashdata('status') != null){
                  echo '<div class="alert alert-'.$this->session->flashdata('status').'" role="alert">
                        <span class="fe fe-alert-circle fe-16 mr-2"></span>'.$this->session->flashdata('msg').'</div>';
                }?>
                <?php echo form_open('c_aset/proses_barang_rusak_it');?>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group mb-3">
                        <label><b>QR</b></label>
                        <input type="text" class="form-control" name="id_stok" id="id_stok_bi" placeholder="QR Code" required>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Jenis Barang</b></label>
                        <input type="text" class="form-control" name="nama_jenis_barang" id="nama_jenis_barang" placeholder="Jenis Barang" readonly>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Nama Model</b></label>
                        <input type="text" class="form-control" name="nama_model" id="nama_model" placeholder="Model Barang" readonly>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Supplier</b></label>
                        <input type="text" class="form-control" name="nama_supplier" id="nama_supplier" placeholder="Supplier" readonly>
                      </div>
                    </div> <!-- /.col -->
                    <div class="col-md-6">
                      <div class="form-group mb-3">
                        <label><b>Tanggal Kembali</b></label>
                        <input type="text" class="form-control drgpicker" name="tanggal_kembali" id="tanggal_kembali" placeholder="Tanggal Kembali" required>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Pengambil</b></label>
                        <input type="text" class="form-control" name="pengambil" id="pengambil" placeholder="Pengambil" required>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Keterangan</b></label>
                        <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan"></textarea>
                      </div>
                      <div class="form-group mb-3">
                        <button class="btn mb-2 btn-info btn-sm">Simpan</button>
                      </div>
                    </div>
                  </div>
                </div>
                <?php echo form_close();?>
              </div> <!-- / .card -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      $('.drgpicker').daterangepicker(
      {
        singleDatePicker: true,
        timePicker: false,
        showDropdowns: true,
        locale:
        {
          format: 'YYYY-MM-DD'
        }
      });
      $('.time-input').timepicker(
      {
        'scrollDefault': 'now',
        'zindex': '9999' /* fix modal open */
      });

      $('.select2').select2(
      {
        theme: 'bootstrap4',
      });

      $('#id_stok_bi').change(function(){
        $.ajax({
          url:"<?php echo site_url('c_aset/cek_status_bi/')?>"+$('#id_stok_bi').val(),
          success : function(o) {
            console.log(o)         
              if(o.status=='ok'){
                var data = o.data
                $('#nama_jenis_barang').val(data.nama_jenis_barang);
                $('#nama_model').val(data.nama_model);
                $('#nama_supplier').val(data.nama_supplier);
              }else{
                alert(o.msg);
                location.reload();              
              }
          },
          error : function(data) {
          // do something
          console.log(data)
        }
        });
      });
    </script>
  </body>
</html>