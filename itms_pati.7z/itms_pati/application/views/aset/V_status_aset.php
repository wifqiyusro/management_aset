<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="h3 mb-4 page-title">Status Aset</h2>
              <div class="row my-4">
                <div class="col-md-12">
                  <div class="card shadow mb-4">
                    <div class="card-header">
                      <strong class="card-title">Inputkan QR Code</strong>
                    </div>
                    <div class="card-body">
                      <div class="col-md-8">
                        <div class="form-group mb-4">
                          <input type="text" id="qr" name="qr" placeholder="QR Code" class="form-control"  autofocus="autofocus">
                        </div>
                      </div>
                      <div class="col-md-8" id="hasil_qr">
                        <table class="table table-bordered">
                          <tr>
                            <td width="50%">PO/Proyek</td>
                            <td width="50%"><input type="text" name="no_po" id="no_po" style="outline: none; border-style: hidden;" size="50" readonly></td>
                          </tr>
                          <tr>
                            <td width="50%">Tanggal PO/Proyek</td>
                            <td width="50%"><input type="text" name="tanggal" id="tanggal" style="outline: none; border-style: hidden;" size="50" readonly></td>
                          </tr>
                          <tr>
                            <td width="50%">Jenis Barang</td>
                            <td width="50%"><input type="text" name="jenis_barang" id="jenis_barang" style="outline: none; border-style: hidden;" size="50" readonly></td>
                          </tr>
                          <tr>
                            <td width="50%">Nama Model</td>
                            <td width="50%"><input type="text" name="nama_model" id="nama_model" style="outline: none; border-style: hidden;" size="50" readonly></td>
                          </tr>
                          <tr>
                            <td width="50%">Supplier</td>
                            <td width="50%"><input type="text" name="supplier" id="supplier" style="outline: none; border-style: hidden;" size="50" readonly></td>
                          </tr>
                          <tr>
                            <td width="50%">Status</td>
                            <td width="50%"><input type="text" name="status_keterangan" id="status_keterangan" style="outline: none; border-style: hidden;" size="50" readonly></td>
                          </tr>
                          <tr>
                            <td width="50%">Lokasi</td>
                            <td width="50%"><input type="text" name="lokasi" id="lokasi" style="outline: none; border-style: hidden;" size="50" readonly></td>
                          </tr>
                          <tr>
                            <td width="50%">Detail Lokasi</td>
                            <td width="50%"><input type="text" name="detail_lokasi" id="detail_lokasi" style="outline: none; border-style: hidden;" size="50" readonly></td>
                          </tr>
                          <tr>
                            <td width="50%">User</td>
                            <td width="50%"><input type="text" name="user" id="user" style="outline: none; border-style: hidden;" size="50" readonly></td>
                          </tr>
                          <tr>
                            <td width="50%">Kode Aset</td>
                            <td width="50%"><input type="text" name="kode_aset" id="kode_aset" style="outline: none; border-style: hidden;" size="50" readonly></td>
                          </tr>
                        </table>
                      </div>
                    </div>
                  </div>          
              </div>
            </div> <!-- .col-12 -->                
              </div>
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];

      function gtag()
      {
        dataLayer.push(arguments);
      }
      gtag('js', new Date());
      gtag('config', 'UA-56159088-1');

      $('#hasil_qr').hide();

      $('#qr').change(function(){
        $.ajax({
          url : "<?php echo site_url('c_aset/proses_cek_status/');?>"+$('#qr').val(),
          success : function(o){
            console.log(o)
              if(o.status == 'ok'){
                var hasil = o.hasil;
                $('#hasil_qr').show();
                
                if(hasil.jenis_aset == '2'){
                  $('#no_po').val(hasil.nama_proyek);
                  $('#tanggal').val(hasil.tanggal);
                }else{
                  $('#no_po').val(hasil.no_po);
                  $('#tanggal').val(hasil.tanggal_po);
                }
                $('#jenis_barang').val(hasil.nama_jenis_barang);
                $('#nama_model').val(hasil.nama_model);
                $('#supplier').val(hasil.nama_supplier);
                if(hasil.status_keterangan == '0'){
                  $('#status_keterangan').val('STOK');
                }else if(hasil.status_keterangan == '1'){
                  $('#status_keterangan').val('TERPASANG');
                }else if(hasil.status_keterangan == '3'){
                  $('#status_keterangan').val('RUSAK IT');
                }else{
                  $('#status_keterangan').val('RUSAK VENDOR');
                }
                $('#lokasi').val(hasil.nama_lokasi);
                $('#detail_lokasi').val(hasil.detail_lokasi);
                if(hasil.nik != ''){
                  $('#user').val(hasil.NAME);
                }else{
                  $('#user').val(hasil.nama_user);
                }                
                $('#kode_aset').val(hasil.id_aset);
                $('#qr').val('');
                $('#qr').focus();
              }else{
                alert(o.msg);
                $('#qr').val('');
                $('#qr').focus();
              }
          },
          error : function(hasil){
            console.log(hasil);
          }
        });
      });
    </script>
  </body>
</html>