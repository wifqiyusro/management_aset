      <main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Transaksi Barang Keluar</h2>
              <div class="card shadow mb-4">
                <?php if($this->session->flashdata('status') != null){
                  echo '<div class="alert alert-'.$this->session->flashdata('status').'" role="alert">
                        <span class="fe fe-alert-circle fe-16 mr-2"></span>'.$this->session->flashdata('msg').'</div>';
                }?>
                <?php echo form_open('c_aset/proses_barang_keluar');?>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group mb-3">
                        <label><b>QR</b></label>
                        <input type="text" class="form-control" name="id_stok" id="id_stok_out" placeholder="QR Code" required>
                        <input type="hidden" name="kode" id="kode">
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Jenis Barang</b></label>
                        <input type="text" class="form-control" name="nama_jenis_barang" id="nama_jenis_barang" placeholder="Jenis Barang" readonly>
                        <input type="hidden" name="id_jenis_barang" id="id_jenis_barang">
                        <input type="hidden" name="label_jns_barang" id="label_jns_barang">
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Nama Model</b></label>
                        <input type="text" class="form-control" name="nama_model" id="nama_model" placeholder="Model Barang" readonly>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Supplier</b></label>
                        <input type="text" class="form-control" name="nama_supplier" id="nama_supplier" placeholder="Supplier" readonly>
                      </div>
                      <div class="form-group mb-3" id="win_ori">
                        <label><b>Windows Original</b></label>
                        <select class="form-control select2" name="windows_ori" id="windows_ori" style="width: 100%">
                          <option value=""></option>
                          <option value="YES">YA</option>
                          <option value="NO">TIDAK</option>
                        </select>
                      </div>
                      <div class="form-group mb-3" id="sn_windows">
                        <label><b>SN Windows</b></label>
                        <input type="text" class="form-control" name="serial_number" id="serial_number" placeholder="Serial Number Windows">
                      </div>
                      <div class="form-group mb-3" id="off_ori">
                        <label><b>Office Original</b></label>
                        <select class="form-control select2" name="office_ori" id="office_ori" style="width: 100%">
                          <option value=""></option>
                          <option value="YES">YA</option>
                          <option value="NO">TIDAK</option>
                        </select>
                      </div>
                      <div class="form-group mb-3" id="sn_off">
                        <label><b>SN Office</b></label>
                        <input type="text" class="form-control" name="serial_number_office" id="serial_number_office" placeholder="Serial Number Office">
                      </div>
                      <div class="form-group mb-3" id="os_id">
                        <label><b>Operating Sistem</b></label>
                        <select class="form-control select2" name="os" id="os" style="width: 100%">
                          <option value=""></option>
                          <option value="32 Bit">32 Bit</option>
                          <option value="64 Bit">64 Bit</option>
                        </select>
                      </div>
                    </div> <!-- /.col -->
                    <div class="col-md-6">
                      <div class="form-group mb-3" id="ram_id">
                        <label><b>RAM</b></label>
                        <select class="form-control select2" name="ram" id="ram" style="width: 100%">
                          <option value=""></option>
                          <option value="2 GB">2 GB</option>
                          <option value="4 GB">4 GB</option>
                          <option value="8 GB">8 GB</option>
                          <option value="16 GB">16 GB</option>
                          <option value="32 GB">32 GB</option>
                        </select>
                      </div>
                      <div class="form-group mb-3" id="koneksi_id">
                        <label><b>Koneksi</b></label>
                        <select class="form-control select2" name="koneksi" id="koneksi" style="width: 100%">
                          <option value=""></option>
                          <option value="LAN">LAN</option>
                          <option value="WIFI">WIFI</option>
                        </select>
                      </div>
                      <div class="form-group mb-3" id="tipe_koneksi_id">
                        <label><b>Tipe Koneksi</b></label>
                        <select class="form-control select2" name="tipe_koneksi" id="tipe_koneksi" style="width: 100%">
                          <option value=""></option>
                          <option value="Internet">Internet</option>
                          <option value="Intranet">Intranet</option>
                        </select>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Lokasi</b></label>
                        <select class="form-control select2" name="lokasi" id="lokasi" style="width: 100%">
                            <option value=""></option>
                          <?php foreach($lokasi as $data){
                            echo '<option value='.$data->id_lokasi.'>'.$data->nama_lokasi.'</option>';
                          }?>
                        </select>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Detail Lokasi</b></label>
                        <input type="text" class="form-control" name="detail_lokasi" id="detail_lokasi" placeholder="Detail Lokasi" required>
                      </div>
                      <div class="form-group mb-3" id="form_tipe_user">
                        <label><b>Tipe User</b></label>
                        <select class="form-control select2" name="tipe_user" id="tipe_user" style="width: 100%">
                          <option value=""></option>
                          <option value="nik">NIK</option>
                          <option value="non_nik">NON NIK</option>
                        </select>
                      </div>
                      <div class="form-group mb-3" id="form_nik">
                        <label><b>Karyawan</b></label>
                        <select class="form-control select2" name="nik" id="nik" style="width: 100%">
                          <option value=""></option>
                        </select>
                      </div>
                      <div class="form-group mb-3" id="form_nama_user">
                        <label><b>Non Karyawan</b></label>
                        <input type="text" class="form-control" name="nama_user" id="nama_user" placeholder="Non Karyawan">
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Tanggal Pasang</b></label>
                        <input type="text" class="form-control drgpicker" name="tanggal_pasang" id="tanggal_pasang" placeholder="Tanggal Pasang" required>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Pemasang</b></label>
                        <input type="text" class="form-control" name="pemasang" id="pemasang" placeholder="Pemasang" required>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Keterangan</b></label>
                        <textarea class="form-control" name="remark" id="remark" placeholder="Keterangan"></textarea>
                      </div>
                      <div class="form-group mb-3">
                        <button class="btn mb-2 btn-info btn-sm">Simpan</button>
                      </div>
                    </div>
                  </div>
                </div>
                <?php echo form_close();?>
              </div> <!-- / .card -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      $('.drgpicker').daterangepicker(
      {
        singleDatePicker: true,
        timePicker: false,
        showDropdowns: true,
        locale:
        {
          format: 'YYYY-MM-DD'
        }
      });
      $('.time-input').timepicker(
      {
        'scrollDefault': 'now',
        'zindex': '9999' /* fix modal open */
      });

      $('.select2').select2(
      {
        theme: 'bootstrap4',
        placeholder: '--- Pilih Salah Satu ---'
      });

      $(function(){
        $('#nik').select2({
        theme: 'bootstrap4',
        placeholder: '--- Pilih Karyawan ---',
        ajax: {
          dataType: 'JSON',
          url: '<?=site_url('c_aset/get_karyawan_2')?>',
          type: "POST",
          delay: 250,
          data: function(params) {
            return {
              searchTerm: params.term
            }
          },
          processResults: function (response) {
              return {
                results: response
              };
          }
        },
        cache: true
        });
      });

      $('#win_ori').hide();
      $('#sn_windows').hide();
      $('#off_ori').hide();
      $('#sn_off').hide();
      $('#os_id').hide();
      $('#ram_id').hide();
      $('#koneksi_id').hide();
      $('#tipe_koneksi_id').hide();
      $('#form_nik').hide();
      $('#form_nama_user').hide();

      $("#tipe_user").change(function(){
            if($("#tipe_user").val() == 'nik'){
              $("#form_nik").show();
              $("#nama_user").val('');
              $("#form_nama_user").hide();
            }else{
              $("#nik").val('');
              $("#form_nik").hide();
              $("#form_nama_user").show();
            }
      });

      $('#id_stok_out').change(function(){
        $.ajax({
          url:"<?php echo site_url('c_aset/cek_status_out/')?>"+$('#id_stok_out').val(),
          success : function(o) {
            console.log(o)         
              if(o.status=='ok'){
                var data = o.data
                $('#id_jenis_barang').val(data.id_jenis_barang);
                $('#nama_jenis_barang').val(data.nama_jenis_barang);
                $('#label_jns_barang').val(data.label_jns_barang);
                $('#nama_model').val(data.nama_model);
                $('#nama_supplier').val(data.nama_supplier);
                $('#kode').val(data.kel_asset);
                $('#remark').val(data.remark);

                if(data.kel_asset == 'AS030'){                
                  $('#win_ori').show();
                  $('#sn_windows').show();
                  $('#off_ori').show();
                  $('#sn_off').show();
                  $('#os_id').show();
                  $('#ram_id').show();
                  $('#koneksi_id').show();
                  $('#tipe_koneksi_id').show();
                }else{
                  $('#win_ori').hide();
                  $('#sn_windows').hide();
                  $('#off_ori').hide();
                  $('#sn_off').hide();
                  $('#os_id').hide();
                  $('#ram_id').hide();
                  $('#koneksi_id').hide();
                  $('#tipe_koneksi_id').hide();
                }
              }else{
                alert(o.msg);
                location.reload();              
              }
          },
          error : function(data) {
          // do something
          console.log(data)
        }
        });
      });
    </script>
  </body>
</html>