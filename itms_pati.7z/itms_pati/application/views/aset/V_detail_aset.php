<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <!-- <h2 class="page-title">Daftar Aset</h2> -->
              <div class="row">
                <div class="col-md-12 mb-4">
                  <div class="accordion accordion-boxed" id="accordion2">
                    <div class="card shadow">
                      <div class="card-header" id="headingOne">
                        <a role="button" href="#collapseOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                          <strong>ASET IT DEPARTEMENT</strong>
                        </a>
                      </div>
                      <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion2">
                        <div class="card-body">
                          <?php
                            foreach ($aset as $dt) {
                              $url = base_url().'index.php/c_aset/detail_aset/'.$dt->kode;
                                $label = $dt->nama_aset;                                  
                                  echo 
                                    anchor($url,$label,array('class'=>'btn mb-2 btn-info btn-sm'));
                                  echo ' ';
                            }
                          ?>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow">
                      <div class="card-header" id="headingTwo">
                        <a role="button" href="#collapseTwo" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                          <strong><?php echo $nama_jenis_barang;?></strong>
                        </a>
                      </div>
                      <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#accordion2">
                        <div class="card-body">
                          <div class="row my-1">
                            <div class="col-md-6 col-xl-2 mb-0">
                              <div class="card shadow mb-0">
                                <div class="card-body">
                                  <div class="row align-items-center">
                                    <div class="col-3 text-center">
                                      <span class="circle circle-sm bg-primary">
                                        <i class="fe fe-16 fe-shopping-cart text-white mb-0"></i>
                                      </span>
                                    </div>
                                    <div class="col pr-0">
                                      <p class="small text-muted mb-0">Stok</p>
                                      <span class="h3 mb-0"><?php echo $stok->jumlah;?></span>
                                      <?php if($stok->jumlah > '0'){?>
                                          <a href="<?php echo base_url();?>index.php/c_aset/stok/<?php echo $kode;?>/0" style="text-decoration:none;"><span class="small text-primary">More...</span></a>
                                      <?php } else{ ?>
                                          <span class="small text-primary">More...</span>
                                      <?php } ?>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6 col-xl-2 mb-0">
                              <div class="card shadow mb-0">
                                <div class="card-body">
                                  <div class="row align-items-center">
                                    <div class="col-3 text-center">
                                      <span class="circle circle-sm bg-success">
                                        <i class="fe fe-16 fe-check-square text-white mb-0"></i>
                                      </span>
                                    </div>
                                    <div class="col pr-0">
                                      <p class="small text-muted mb-0">Terpasang</p>
                                      <span class="h3 mb-0"><?php echo $terpasang->jumlah;?></span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div> 
                            <div class="col-md-6 col-xl-2 mb-0">
                              <div class="card shadow mb-0">
                                <div class="card-body">
                                  <div class="row align-items-center">
                                    <div class="col-3 text-center">
                                      <span class="circle circle-sm bg-warning">
                                        <i class="fe fe-16 fe-x-octagon text-white mb-0"></i>
                                      </span>
                                    </div>
                                    <div class="col pr-0">
                                      <p class="small text-muted mb-0">Rusak di IT</p>
                                      <span class="h3 mb-0"><?php echo $rusak_it->jumlah;?></span>
                                      <?php if($rusak_it->jumlah > '0'){?>
                                          <a href="<?php echo base_url();?>index.php/c_aset/rusak_it/<?php echo $kode;?>/3" style="text-decoration:none;"><span class="small text-warning">More...</span></a>
                                      <?php } else{ ?>
                                          <span class="small text-warning">More...</span>
                                      <?php } ?>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6 col-xl-2 mb-0">
                              <div class="card shadow mb-0">
                                <div class="card-body">
                                  <div class="row align-items-center">
                                    <div class="col-3 text-center">
                                      <span class="circle circle-sm bg-danger">
                                        <i class="fe fe-16 fe-tool text-white mb-0"></i>
                                      </span>
                                    </div>
                                    <div class="col pr-0">
                                      <p class="small text-muted mb-0">Rusak di Vendor</p>
                                      <span class="h3 mb-0"><?php echo $rusak_vendor->jumlah;?></span>
                                      <?php if($rusak_vendor->jumlah > '0'){?>
                                          <a href="<?php echo base_url();?>index.php/c_aset/rusak_vendor/<?php echo $kode;?>/4" style="text-decoration:none;"><span class="small text-danger">More...</span></a>
                                      <?php } else{ ?>
                                          <span class="small text-danger">More...</span>
                                      <?php } ?>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6 col-xl-2 mb-0">
                              <div class="card shadow mb-0">
                                <div class="card-body">
                                  <div class="row align-items-center">
                                    <div class="col-3 text-center">
                                      <span class="circle circle-sm bg-info">
                                        <i class="fe fe-16 fe-list text-white mb-0"></i>
                                      </span>
                                    </div>
                                    <div class="col pr-0">
                                      <p class="small text-muted mb-0">Total</p>
                                      <span class="h3 mb-0"><?php echo $total;?></span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6 col-xl-2 mb-0">
                              <div class="card shadow mb-0">
                                <div class="card-body">
                                  <div class="row align-items-center">
                                    <div class="col-3 text-center">
                                      <span class="circle circle-sm bg-dark">
                                        <i class="fe fe-16 fe-download text-white mb-0"></i>
                                      </span>
                                    </div>
                                    <div class="col pr-0">
                                      <p class="small text-muted mb-0"><?php echo $nama_jenis_barang;?></p>
                                      <a href="<?php echo base_url();?>index.php/c_aset/export_per_aset/<?php echo $kode;?>/<?php echo $total;?>" style="text-decoration:none;" target="_blank"><span class="h3 mb-0">Export</span></a>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div> <!-- end section -->                          
                        </div>
                      </div>                      
                    </div>
                    <div class="card shadow">
                      <div class="card-header" id="headingTwo">
                        <a role="button" href="#collapseTwo" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                          <strong><?php echo $nama_jenis_barang;?> - TERPASANG</strong>
                        </a>
                      </div>
                      <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#accordion2">
                        <div class="card-body">
                          <div class="row my-0">
                            <?php foreach($data as $dt){?>
                            <div class="col-md-6 col-xl-3 mb-2">
                              <div class="card shadow bg-success text-white border-0">
                                <div class="card-body">
                                  <div class="row align-items-center">
                                    <div class="col-3 text-center">
                                      <span class="circle circle-sm bg-success-light">
                                        <i class="fe fe-16 fe-home text-white mb-0"></i>
                                      </span>
                                    </div>
                                    <div class="col pr-0">
                                      <p class="small text-white mb-0 "><?php echo $dt->nama_lokasi;?></p>
                                      <span class="h3 mb-0 text-white"><?php echo $dt->total_barang?></span>
                                      <a href="<?php echo base_url();?>index.php/c_aset/detail_lokasi/<?php echo $kode;?>/<?php echo $dt->id_lokasi;?>" style="text-decoration:none;"><span class="small text-white">More...</span></a>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <?php } ?>
                          </div> <!-- end section -->                          
                        </div>
                      </div>                      
                    </div>
                  </div>
                </div>
              </div> <!-- end section -->
            </div> <!-- .col-12 -->                
                <!-- <div class="col-md-12 mb-4">
                  <div class="card shadow">                    
                    <div class="card-body">                     
                    </div> 
                  </div> 
                </div>  -->
              </div>
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];

      function gtag()
      {
        dataLayer.push(arguments);
      }
      gtag('js', new Date());
      gtag('config', 'UA-56159088-1');
    </script>
  </body>
</html>