<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <!-- <h2 class="page-title">Daftar Aset</h2> -->
              <div class="row">
                <div class="col-md-12 mb-4">
                  <div class="accordion accordion-boxed" id="accordion2">
                    <div class="card shadow">
                      <div class="card-header" id="headingOne">
                        <a role="button" href="#collapseOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                          <strong>ASET IT DEPARTEMENT</strong>
                        </a>
                      </div>
                      <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion2">
                        <div class="card-body">
                          <?php
                            foreach ($aset as $dt) {
                              $url = base_url().'index.php/c_aset/detail_aset/'.$dt->kode;
                                $label = $dt->nama_aset;                                  
                                  echo 
                                    anchor($url,$label,array('class'=>'btn mb-2 btn-info btn-sm'));
                                  echo ' ';
                            }
                          ?>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow">
                      <div class="card-header" id="headingTwo">
                        <a role="button" href="#collapseTwo" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                          <strong><?php echo $nama_jenis_barang;?> - RUSAK DI IT</strong>
                        </a>
                      </div>
                      <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#accordion2">
                        <div class="card-body">
                        <table class="table table-bordered table-hover mb-0 datatables" id="table_stok" cellspacing="0" width="100%">
                          <thead class="thead-dark" style="text-align: center;">
                            <tr>
                              <th>No</th>
                              <th>ID Stok</th>
                              <th>Nama Model</th>
                              <th>Jenis Aset</th>
                              <th>Serial Number</th>
                              <th>Alokasi</th>
                              <th>keterangan</th>
                              <th>QR</th>
                              <th>Aksi</th>
                            </tr>
                          </thead>
                          <tbody>                          
                          </tbody>
                        </table>                       
                        </div>
                      </div>                      
                    </div>
                  </div>
                </div>
              </div> <!-- end section -->
            </div> <!-- .col-12 -->                
                <!-- <div class="col-md-12 mb-4">
                  <div class="card shadow">                    
                    <div class="card-body">                     
                    </div> 
                  </div> 
                </div>  -->
              </div>
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script>
      var table;
      $(document).ready(function(){
        table = $('#table_stok').DataTable({
          "processing":true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide":true,
          "ordering":false,
          "order":[],
          "ajax":{
            "url": "<?php echo site_url('c_aset/get_aset_selain_terpasang/'.$kode.'/'.$status_keterangan);?>",
            "type":"POST"
          },
        });
      });

      function reload_table(){
        table.ajax.reload(null,false); //reload datatable ajax 
      }

      function edit_barang(id_stok){
        save_method = 'edit_barang';
        $('#form_barang')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class
        // $('#modal_barang').modal('show');

        $.ajax({
            url : "<?php echo site_url('c_aset/edit_barang')?>/"+id_stok,
            type: "GET",
            dataType: "JSON",
            success: function(data){     
                $('[name="id_stok"]').val(data.id_stok);
                $('[name="nama_model"]').val(data.nama_model);
                $('[name="jenis_aset"]').val(data.jns_aset);
                $('[name="sn"]').val(data.sn);
                $('[name="remark"]').val(data.remark);
                $('[name="status_keterangan"]').val(data.status_keterangan);         
                $('#modal_barang').modal('show'); // show bootstrap modal when complete loaded
                $('.modal-title').text('Edit Barang'); // Set title to Bootstrap modal title     
            },
            error: function (jqXHR, textStatus, errorThrown){
                alert('Gagal menampilkan data Barang');
            }
        });
      }

      function savebarang(){
        $('#savebarang').text('menyimpan...'); //change button text
        $('#savebarang').attr('disabled',true); //set button disable

        $.ajax({
          url : "<?php echo site_url('c_aset/edit_barang_non_terpasang_proses');?>",
          type: "POST",
          data: $('#form_barang').serialize(),
          dataType: "JSON",
          success: function(data){
            if(data.status){
              $('#modal_barang').modal('hide');
              reload_table();
            }
            $('#savebarang').text('menyimpan'); //change button text
            $('#savebarang').attr('disabled',false); //set button enable
          },
          error: function (jqXHR, textStatus, errorThrown){
            alert('Gagal edit barang');
            $('#savebarang').text('menyimpan'); //change button text
            $('#savebarang').attr('disabled',false); //set button enable
          }
        });
      }

      function generate_barang(id_stok){
        $.ajax({
          url : "<?php echo site_url('c_aset/generate_qr')?>/"+id_stok,
          type: "GET",
          dataType: "JSON",
          success: function(data){
            reload_table();
          },
          error: function (jqXHR, textStatus, errorThrown){
            alert('Gagal generate QR');
          }
        });
      }


      window.dataLayer = window.dataLayer || [];

      function gtag()
      {
        dataLayer.push(arguments);
      }
      gtag('js', new Date());
      gtag('config', 'UA-56159088-1');
    </script>
  </body>
</html>

<div class="modal fade" id="modal_barang" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel"></h5>
      </div>
      <div class="modal-body">
        <form action="#" id="form_barang">
          <div class="form-group">
            <label class="col-form-label"><b>QR</b></label>
            <input type="hidden" name="id_user">
            <input type="text" class="form-control" name="id_stok" placeholder="ID Stok" readonly>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Nama Model</b></label>
            <input type="text" class="form-control" name="nama_model" placeholder="Nama Model" readonly>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Jenis Aset</b></label>
            <input type="text" class="form-control" name="jenis_aset" placeholder="Jenis Aset" readonly>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Serial Number</b></label>
            <input type="text" class="form-control" name="sn" placeholder="Serial Number" required>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Keterangan</b></label>
            <textarea class="form-control" name="remark" placeholder="Keterangan" required></textarea>
            <input type="hidden" name="status_keterangan">
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" id="savebarang" onclick="savebarang()" class="btn mb-2 btn-primary">Simpan</button>
      </div>
    </div>
  </div>
</div>
