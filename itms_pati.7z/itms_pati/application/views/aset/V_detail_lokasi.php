<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <!-- <h2 class="page-title">Daftar Aset</h2> -->
              <div class="row">
                <div class="col-md-12 mb-4">
                  <div class="accordion accordion-boxed" id="accordion2">
                    <div class="card shadow">
                      <div class="card-header" id="headingOne">
                        <a role="button" href="#collapseOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                          <strong>ASET IT DEPARTEMENT</strong>
                        </a>
                      </div>
                      <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion2">
                        <div class="card-body">
                          <?php
                            foreach ($aset as $dt) {
                              $url = base_url().'index.php/c_aset/detail_aset/'.$dt->kode;
                                $label = $dt->nama_aset;                                  
                                  echo 
                                    anchor($url,$label,array('class'=>'btn mb-2 btn-info btn-sm'));
                                  echo ' ';
                            }
                          ?>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow">
                      <div class="card-header" id="headingTwo">
                        <a role="button" href="#collapseTwo" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                          <strong><?php echo $nama_jenis_barang;?></strong>
                        </a>
                      </div>
                      <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#accordion2">
                        <div class="card-body">
                          <div class="row my-1">
                            <div class="col-md-6 col-xl-2 mb-0">
                              <div class="card shadow mb-0">
                                <div class="card-body">
                                  <div class="row align-items-center">
                                    <div class="col-3 text-center">
                                      <span class="circle circle-sm bg-primary">
                                        <i class="fe fe-16 fe-shopping-cart text-white mb-0"></i>
                                      </span>
                                    </div>
                                    <div class="col pr-0">
                                      <p class="small text-muted mb-0">Stok</p>
                                      <span class="h3 mb-0"><?php echo $stok->jumlah;?></span>
                                      <?php if($stok->jumlah > 0){?>
                                          <a href="<?php echo base_url();?>index.php/c_aset/stok/<?php echo $kode;?>/0" style="text-decoration:none;"><span class="small text-primary">More...</span></a>
                                      <?php } else{ ?>
                                          <span class="small text-primary">More...</span>
                                      <?php } ?>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6 col-xl-2 mb-0">
                              <div class="card shadow mb-0">
                                <div class="card-body">
                                  <div class="row align-items-center">
                                    <div class="col-3 text-center">
                                      <span class="circle circle-sm bg-success">
                                        <i class="fe fe-16 fe-check-square text-white mb-0"></i>
                                      </span>
                                    </div>
                                    <div class="col pr-0">
                                      <p class="small text-muted mb-0">Terpasang</p>
                                      <span class="h3 mb-0"><?php echo $terpasang->jumlah;?></span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>  
                            <div class="col-md-6 col-xl-2 mb-0">
                              <div class="card shadow mb-0">
                                <div class="card-body">
                                  <div class="row align-items-center">
                                    <div class="col-3 text-center">
                                      <span class="circle circle-sm bg-warning">
                                        <i class="fe fe-16 fe-home text-white mb-0"></i>
                                      </span>
                                    </div>
                                    <div class="col pr-0">
                                      <p class="small text-muted mb-0">Rusak di IT</p>
                                      <span class="h3 mb-0"><?php echo $rusak_it->jumlah;?></span>
                                      <?php if($rusak_it->jumlah > 0){?>
                                          <a href="<?php echo base_url();?>index.php/c_aset/rusak_it/<?php echo $kode;?>/3" style="text-decoration:none;"><span class="small text-warning">More...</span></a>
                                      <?php } else{ ?>
                                          <span class="small text-warning">More...</span>
                                      <?php } ?>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6 col-xl-2 mb-0">
                              <div class="card shadow mb-0">
                                <div class="card-body">
                                  <div class="row align-items-center">
                                    <div class="col-3 text-center">
                                      <span class="circle circle-sm bg-danger">
                                        <i class="fe fe-16 fe-tool text-white mb-0"></i>
                                      </span>
                                    </div>
                                    <div class="col pr-0">
                                      <p class="small text-muted mb-0">Rusak di Vendor</p>
                                      <span class="h3 mb-0"><?php echo $rusak_vendor->jumlah;?></span>
                                      <?php if($rusak_vendor->jumlah > 0){?>
                                          <a href="<?php echo base_url();?>index.php/c_aset/rusak_vendor/<?php echo $kode;?>/4" style="text-decoration:none;"><span class="small text-danger">More...</span></a>
                                      <?php } else{ ?>
                                          <span class="small text-danger">More...</span>
                                      <?php } ?>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6 col-xl-2 mb-0">
                              <div class="card shadow mb-0">
                                <div class="card-body">
                                  <div class="row align-items-center">
                                    <div class="col-3 text-center">
                                      <span class="circle circle-sm bg-info">
                                        <i class="fe fe-16 fe-list text-white mb-0"></i>
                                      </span>
                                    </div>
                                    <div class="col pr-0">
                                      <p class="small text-muted mb-0">Total</p>
                                      <span class="h3 mb-0"><?php echo $total;?></span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6 col-xl-2 mb-0">
                              <div class="card shadow mb-0">
                                <div class="card-body">
                                  <div class="row align-items-center">
                                    <div class="col-3 text-center">
                                      <span class="circle circle-sm bg-dark">
                                        <i class="fe fe-16 fe-download text-white mb-0"></i>
                                      </span>
                                    </div>
                                    <div class="col pr-0">
                                      <p class="small text-muted mb-0"><?php echo $nama_jenis_barang;?></p>
                                      <a href="<?php echo base_url();?>index.php/c_aset/export_per_aset/<?php echo $kode;?>/<?php echo $total;?>" style="text-decoration:none;" target="_blank"><span class="h3 mb-0">Export</span></a>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div> <!-- end section -->                          
                        </div>
                      </div>                      
                    </div>
                    <div class="card shadow">
                      <div class="card-header" id="headingThree">
                        <a role="button" href="#collapseThree" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                          <strong><?php echo $nama_jenis_barang.' - '.$nama_lokasi;?></strong>
                        </a>
                      </div>
                      <div id="collapseThree" class="collapse show" aria-labelledby="headingThree" data-parent="#accordion2">
                        <div class="card-body">                          
                          <div class="col-md-4">
                            <form class="form-horizontal" id="filter" method="post">
                            <div class="form-group row">
                              <label for="inputEmail3" class="col-sm-4 col-form-label"><b>Jenis</b></label>
                              <div class="col-sm-8">
                                <select class="form-control select2" name="jenis_aset" id="jenis_aset">
                                  <option value=""></option>
                                  <option value="3">PO</option>
                                  <option value="1">Rental</option>
                                  <option value="2">Projek</option>
                                </select>
                              </div>
                            </div>
                            <div class="form-group row">
                              <label for="inputEmail3" class="col-sm-4 col-form-label"><b>Nama Model</b></label>
                              <div class="col-sm-8">
                                <select class="form-control select2" name="id_barang" id="id_barang">
                                    <option value=""></option>
                                  <?php foreach($barang as $data){?>
                                    <option value="<?php echo $data->id_barang;?>"><?php echo $data->nama_model;?></option>
                                  <?php } ?>
                                </select>
                                <input type="hidden" name="lokasi" id="lokasi" value="<?php echo $lokasi;?>">
                                <input type="hidden" name="kode" id="kode" value="<?php echo $kode;?>">
                              </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-8 ml-sm-auto">
                                  <button class="btn mb-2 btn-info btn-sm" type="button" id="btn_filter">Filter</button>
                                  <button class="btn mb-2 btn-success btn-sm" type="button" onclick="getExcel()">Export</button>
                                  <button class="btn mb-2 btn-secondary btn-sm" type="button" id="btn_reset">Reset</button>
                                </div>
                            </div>
                            </form>
                          </div>                         
                          <!-- <div class="row my-0"> -->
                            <table class="table table-bordered table-hover mb-0 datatables" id="table_detail_aset" cellspacing="0" width="100%">
                              <thead class="thead-dark" style="text-align: center;">
                                <tr>
                                  <th>No</th>
                                  <?php if($kode == 'AS030'){
                                    echo '
                                    <th>QR</th>
                                    <th>Kode Aset</th>
                                    ';
                                  }else{
                                    echo '<th>QR</th>';
                                  }?>                                  
                                  <!-- <th>Kode EPTE</th> -->
                                  <th>Nama Model</th>
                                  <th>Jenis</th>
                                  <th>Kurs</th>
                                  <th>Harga</th>
                                  <th>Detail Lokasi</th>
                                  <th>Pengguna</th>
                                  <th>SN</th>
                                  <th>Ket.</th>
                                  <th></th>
                                  <th>Aksi</th>
                                </tr>
                              </thead>
                              <tbody>                          
                              </tbody>
                            </table>
                          <!-- </div>  --><!-- end section -->                          
                        </div>
                      </div>                      
                    </div>
                  </div>
                </div>
              </div> <!-- end section -->
            </div> <!-- .col-12 -->                
                <!-- <div class="col-md-12 mb-4">
                  <div class="card shadow">                    
                    <div class="card-body">                     
                    </div> 
                  </div> 
                </div>  -->
              </div>
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script>
      var table;
      $(document).ready(function(){
        $('#tipe_user').select2({
          theme: 'bootstrap4'
        });

        $("#tipe_user").change(function(){
            if($("#tipe_user").val() == 'nik'){
              $("#form_nik").show();
              $("#nama_user").val('');
              $("#form_nama_user").hide();
            }else{
              $("#nik").val('');
              $("#form_nik").hide();
              $("#form_nama_user").show();
            }
        });

        table = $('#table_detail_aset').DataTable({
          "processing":true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide":true,
          "ordering":false,
          "order":[],
          "ajax":{
            "url": "<?php echo site_url('c_aset/get_detail_aset/'.$kode.'/'.$lokasi);?>",
            "type":"POST",
            "data":function(data){
              data.jenis_aset = $('#jenis_aset').val();
              data.id_barang = $('#id_barang').val();
              data.lokasi = $('#lokasi').val();
            }
          },
        });
      });
      
      $("#tipe_user").change(function(){
            if($("#tipe_user").val() == 'nik'){
              $("#form_nik").show();
              $("#form_nama_user").hide();
            }else{
              $("#form_nik").hide();
              $("#form_nama_user").show();
            }
      });

      //JS reload table
      function reload_table(){
        table.ajax.reload(null,false); //reload datatable ajax 
      }

      function edit_barang(id_stok){
        save_method = 'edit_barang';
        $('#form_barang')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class
        $('#modal_barang').modal('show');

        $.ajax({
            url : "<?php echo site_url('c_aset/edit_barang')?>/"+id_stok,
            type: "GET",
            dataType: "JSON",
            success: function(data){   
              console.log(data)  
                $('[name="id_stok"]').val(data.id_stok);
                $('[name="id_aset"]').val(data.id_aset);
                $('[name="nama_model"]').val(data.nama_model);
                $('[name="jenis_aset"]').val(data.jns_aset);
                $('[name="id_jenis_aset"]').val(data.jenis_aset);
                $('[name="detail_lokasi"]').val(data.detail_lokasi);
                if(data.nik == null || data.nik == ''){
                  $('#tipe_user').html('<option value="nik">NIK</option> <option value="non_nik" selected>NON NIK</option>');
                  $('#form_nik').hide();
                  $('#form_nama_user').show();
                  $('[name="nama_user"]').val(data.nama_user);
                }else{
                  $('#tipe_user').html('<option value="nik" selected>NIK</option> <option value="non_nik">NON NIK</option>');
                  $('#form_nik').show();
                  $('#form_nama_user').hide();
                  $("#nik").html('<option value = "'+data.nik+'" selected>'+data.nik+' - '+data.NAME+'</option>');
                }
                $('#windows_ori').val(data.windows_ori).select2({theme: 'bootstrap4'});
                $('#office_ori').val(data.office_ori).select2({theme: 'bootstrap4'});
                $('[name="serial_number"]').val(data.serial_number);
                $('[name="serial_number_office"]').val(data.serial_number_office);
                $('#os').val(data.os).select2({theme: 'bootstrap4'});
                $('#ram').val(data.ram).select2({theme: 'bootstrap4'});
                $('#koneksi').val(data.koneksi).select2({theme: 'bootstrap4'});
                $('#tipe_koneksi').val(data.tipe_koneksi).select2({theme: 'bootstrap4'});
                $('[name="mac_adress"]').val(data.mac_adress);
                $('[name="sn"]').val(data.sn);
                $('[name="remark"]').val(data.remark);
                $('[name="status_keterangan"]').val(data.status_keterangan);          
                $('#modal_barang').modal('show'); // show bootstrap modal when complete loaded
                $('.modal-title').text('Edit Barang'); // Set title to Bootstrap modal title     
            },
            error: function (jqXHR, textStatus, errorThrown){
                alert('Gagal menampilkan data Barang');
            }
        });
      }

      $(function(){
        $('#nik').select2({
        theme: 'bootstrap4',
        placeholder : '--- Pilih Karyawan ---',
        ajax: {
          dataType: 'JSON',
          url: '<?=site_url('c_aset/get_karyawan_2')?>',
          type: "POST",
          delay: 250,
          data: function(params) {
            return {
              searchTerm: params.term
            }
          },
          processResults: function (response) {
              return {
                results: response
              };
          }
        },
        cache: false
        });
      }); 

      function savebarang(){
        $('#savebarang').text('menyimpan...'); //change button text
        $('#savebarang').attr('disabled',true); //set button disable

        $.ajax({
          url : "<?php echo site_url('c_aset/edit_barang_proses');?>",
          type: "POST",
          data: $('#form_barang').serialize(),
          dataType: "JSON",
          success: function(data){
            if(data.status){
              $('#modal_barang').modal('hide');
              reload_table();
            }
            $('#savebarang').text('simpan'); //change button text
            $('#savebarang').attr('disabled',false); //set button enable
          },
          error: function (jqXHR, textStatus, errorThrown){
            alert('Gagal edit barang');
            $('#savebarang').text('simpan'); //change button text
            $('#savebarang').attr('disabled',false); //set button enable
          }
        });
      }

      function generate_barang(id_stok){
        $.ajax({
          url : "<?php echo site_url('c_aset/generate_qr')?>/"+id_stok,
          type: "GET",
          dataType: "JSON",
          success: function(data){
            reload_table();
          },
          error: function (jqXHR, textStatus, errorThrown){
            alert('Gagal generate QR');
          }
        });
      }
      
      $("#id_barang").select2({
        placeholder: "-- Semua Barang --",
        theme: 'bootstrap4',
        allowClear: true
      });

      $("#jenis_aset").select2({
        placeholder: "-- Semua Jenis --",
        theme: 'bootstrap4',
        allowClear: true
      });   

      $('#btn_reset').click(function(){ //button reset event click
        $('#filter')[0].reset();
        $('#jenis_aset').val('');
        $('#id_barang').val('');
        $('#jenis_aset').trigger('change');
        $('#id_barang').trigger('change');
        table.ajax.reload();  //just reload table
      });

      $('#btn_filter').click(function(){ //button filter event click
        table.ajax.reload();  //just reload table
      });

      function getExcel(){
        var jenis_aset = ($('#jenis_aset').val()?$('#jenis_aset').val():'-')
        var id_barang = ($('#id_barang').val()?$('#id_barang').val():'-')
        var lokasi = ($('#lokasi').val()?$('#lokasi').val():'-')
        var kode = ($('#kode').val()?$('#kode').val():'-')
        window.open("<?php echo site_url('c_aset/export_detail_lokasi/');?>"+jenis_aset+'/'+id_barang+'/'+lokasi+'/'+kode,"_blank");
      }

      window.dataLayer = window.dataLayer || [];

      function gtag()
      {
        dataLayer.push(arguments);
      }
      gtag('js', new Date());
      gtag('config', 'UA-56159088-1');
    </script>
  </body>
</html>
<div id="modal_barang" class="modal fade bd-example-modal-lg" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel"></h5>
      </div>
      <div class="modal-body">
        <form action="#" id="form_barang">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">            
                <label class="col-form-label"><b>QR</b></label>
                <input type="text" class="form-control" name="id_stok" readonly>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Kode Aset</b></label>
                <input type="text" class="form-control" name="id_aset" readonly>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Nama Model</b></label>
                <input type="text" class="form-control" name="nama_model" readonly>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Jenis Aset</b></label>
                <input type="text" class="form-control" name="jenis_aset" readonly>
                <input type="hidden" name="id_jenis_aset">
              </div>
              <?php if($kode == 'AS030'){?>
              <div class="form-group">            
                <label class="col-form-label"><b>Windows Ori</b></label>
                <select class="form-control select2" name="windows_ori" id="windows_ori">
                  <option value="YES">YA</option>
                  <option value="NO">TIDAK</option>
                </select>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Office Ori</b></label>
                <select class="form-control select2" name="office_ori" id="office_ori">
                  <option value="YES">YA</option>
                  <option value="NO">TIDAK</option>
                </select>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>SN Windows</b></label>
                <input type="text" class="form-control" name="serial_number" placeholder="Serial Number Windows" required>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>SN Office</b></label>
                <input type="text" class="form-control" name="serial_number_office" placeholder="Serial Number Office" required>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>OS</b></label>
                <select class="form-control select2" name="os" id="os">
                  <option value="32 Bit">32 Bit</option>
                  <option value="64 Bit">64 Bit</option>
                </select>
              </div>
              <?php } ?>
            </div>
            <div class="col-md-6">
              <?php if($kode=='AS030'){?>
              <div class="form-group">            
                <label class="col-form-label"><b>RAM</b></label>
                <select class="form-control select2" name="ram" id="ram">
                  <option value="4 GB">4 GB</option>
                  <option value="6 GB">6 GB</option>
                  <option value="8 GB">8 GB</option>
                  <option value="12 GB">12 GB</option>
                  <option value="16 GB">16 GB</option>
                </select>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Koneksi</b></label>
                <select class="form-control select2" name="koneksi" id="koneksi">
                  <option value="LAN">LAN</option>
                  <option value="WIFI">WIFI</option>
                </select>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Tipe Koneksi</b></label>
                <select class="form-control select2" name="tipe_koneksi" id="tipe_koneksi">
                  <option value="Internet">Internet</option>
                  <option value="Intranet">Intranet</option>
                </select>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Mac Adress</b></label>
                <input type="text" class="form-control" name="mac_adress" placeholder="Mac Adress" required>
              </div>
              <?php } ?>
              <div class="form-group">            
                <label class="col-form-label"><b>Detail Lokasi</b></label>
                <input type="text" class="form-control" name="detail_lokasi" placeholder="Detail Lokasi" required>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Tipe User</b></label>
                <select class="form-control select2" name="tipe_user" id="tipe_user">
                </select>
              </div>
              <div class="form-group" id="form_nik">            
                <label class="col-form-label"><b>NIK</b></label>
                <select class="form-control select2" name="nik" id="nik">
                </select>
              </div>
              <div class="form-group" id="form_nama_user">            
                <label class="col-form-label"><b>Pengguna</b></label>
                <input type="text" class="form-control" name="nama_user" placeholder="Nama User">
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Serial Number</b></label>
                <input type="text" class="form-control" name="sn" placeholder="Serial Number Aset" required>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Keterangan</b></label>
                <textarea class="form-control" name="remark" placeholder="Keterangan"></textarea>
                <input type="hidden" name="status_keterangan">
              </div>
            </div>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" id="savebarang" onclick="savebarang()" class="btn btn-primary">Simpan</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div> <!-- medium modal -->