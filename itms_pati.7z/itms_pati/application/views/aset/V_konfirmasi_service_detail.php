<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Detail Konfirmasi Barang Service</h2>
              <div class="row my-4">
                <div class="col-md-12">                 
                  <div class="card shadow">
                    <?php if($this->session->flashdata('status') != null){
                      echo '<div class="alert alert-'.$this->session->flashdata('status').'" role="alert">
                            <span class="fe fe-alert-circle fe-16 mr-2"></span>'.$this->session->flashdata('msg').'</div>';
                    }?>
                    <div class="card-body">
                    <?php echo form_open('c_aset/proses_terima_service');?>
                      <div class="col-md-5">
                        <div class="form-group row">
                          <label for="inputEmail3" class="col-sm-4 col-form-label"><b>Tanggal Terima</b></label>
                          <div class="col-sm-8">
                            <input type="text" class="form-control drgpicker" name="tgl_terima" id="tgl_terima" placeholder="Tanggal Terima" required>
                            <input type="hidden" name="id_po" value="<?php echo $id_po;?>">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label for="inputEmail3" class="col-sm-4 col-form-label"><b>Surat Jalan</b></label>
                          <div class="col-sm-8">
                            <input type="text" class="form-control " name="surat_jalan" id="surat_jalan" placeholder="Surat Jalan" required>
                          </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-8 ml-sm-auto">
                              <button class="btn mb-2 btn-info btn-sm" type="submit" id="btn_terima">Terima</button>
                            </div>
                        </div>
                      </div>
                      <table class="table table-bordered table-hover mb-0 datatables" cellspacing="0" width="100%" id="dataTable-1">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th style="position: sticky; top: 0;"><input type="checkbox" id="select_all_service"></th>
                            <th style="position: sticky; top: 0;">No</th>
                            <th style="position: sticky; top: 0;">PO</th>
                            <th style="position: sticky; top: 0;">QR</th>
                            <th style="position: sticky; top: 0;">Barang</th>
                            <th style="position: sticky; top: 0;">Vendor</th>
                            <th style="position: sticky; top: 0;">Biaya Total</th>
                            <th style="position: sticky; top: 0;">Keterangan</th>
                            <th style="position: sticky; top: 0;">Diupdate</th>                           
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">
                          <?php
                            $no = 1;
                            foreach($data as $dt){
                              echo '
                              <tr>
                                <td><input type="checkbox" name="select_all[]" value="'.$dt->id_stok.';'.$dt->id_supplier.'"></td>
                                <td>'.$no.'</td>
                                <td>'.$dt->no_po.'</td>
                                <td>'.$dt->id_stok.'</td>
                                <td>'.$dt->nama_model.'</td>
                                <td>'.$dt->nama_supplier.'</td>
                                <td>'.$dt->ppn.'</td>
                                <td>'.$dt->keterangan.'</td>
                                <td>'.$dt->updated_at.'</td>
                              </tr>
                              ';
                              $no++;
                            }
                          ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.checkboxes.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script>
        $('#dataTable-1').DataTable({
            autoWidth: true,
            ordering: false
        });

        $('#select_all_service').click(function(e){
            var table= $(e.target).closest('table');
            $('td input:checkbox',table).prop('checked',this.checked);
        });

        $('.drgpicker').daterangepicker(
            {
            singleDatePicker: true,
            timePicker: false,
            showDropdowns: true,
            locale:
            {
            format: 'YYYY-MM-DD'
            }
        });
    </script>
  </body>
</html>
