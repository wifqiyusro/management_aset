<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Detail Konfirmasi PO</h2>
              <div class="row my-4">
                <div class="col-md-12">
                  <!-- <button type="button" class="btn mb-2 btn-info" onclick="terima_rental()">Terima Rental</button> -->
                  <div class="card shadow">
                    <?php if($this->session->flashdata('status') != null){
                      echo '<div class="alert alert-'.$this->session->flashdata('status').'" role="alert">
                            <span class="fe fe-alert-circle fe-16 mr-2"></span>'.$this->session->flashdata('msg').'</div>';
                    }?>
                    <div class="card-body">
                      <?php echo form_open('c_aset/proses_terima_po');?>
                      <div class="col-md-5">
                        <div class="form-group row">
                          <label for="inputEmail3" class="col-sm-4 col-form-label"><b>Tanggal Datang</b></label>
                          <div class="col-sm-8">
                            <input type="text" class="form-control drgpicker" name="tgl_dtg" id="tgl_dtg" placeholder="Tanggal Datang" required>
                            <input type="hidden" name="id_po" value="<?php echo $id_po;?>">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label for="inputEmail3" class="col-sm-4 col-form-label"><b>Surat Jalan</b></label>
                          <div class="col-sm-8">
                            <input type="text" class="form-control " name="surat_jalan" id="surat_jalan" placeholder="Surat Jalan" required>
                          </div>
                        </div>
                        <div class="form-group row">
                          <label for="inputEmail3" class="col-sm-4 col-form-label"><b>Keterangan</b></label>
                          <div class="col-sm-8">
                            <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan"></textarea>
                          </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-8 ml-sm-auto">
                              <button class="btn mb-2 btn-info btn-sm" type="submit" id="btn_terima">Terima</button>
                            </div>
                        </div>
                      </div>
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="table_konfirm_po" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th><input type="checkbox" id="select_all"></th>
                            <th>No</th>
                            <th>PO</th>
                            <th>Tanggal PO</th>
                            <th>Jenis Barang</th>
                            <th>Nama Model</th>
                            <th>Kode EPTE</th>
                            <th>Kode FA</th>
                            <th>Kurs</th>
                            <th>Harga</th>
                            <th>Harga+PPN</th>
                            <!-- <th>Harga+PPh</th> -->
                            <th>Alokasi</th>
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">                          
                        </tbody>
                      </table>
                      <?php echo form_close();?>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.checkboxes.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        table = $('#table_konfirm_po').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_aset/get_data_konfirm_po/'.$id_po.'')?>",
            "type": "POST"
          }          
        });
      });

      $('#select_all').click(function(e){
        var table= $(e.target).closest('table');
        $('td input:checkbox',table).prop('checked',this.checked);
      });

      $('.drgpicker').daterangepicker(
      {
        singleDatePicker: true,
        timePicker: false,
        showDropdowns: true,
        locale:
        {
          format: 'YYYY-MM-DD'
        }
      });

      function reload_table(){
        table.ajax.reload(null,false);
      }     

    </script>
  </body>
</html>
