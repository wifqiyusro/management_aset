      <main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Transaksi Pindah Lokasi</h2>
              <div class="card shadow mb-4">
                <?php if($this->session->flashdata('status') != null){
                  echo '<div class="alert alert-'.$this->session->flashdata('status').'" role="alert">
                        <span class="fe fe-alert-circle fe-16 mr-2"></span>'.$this->session->flashdata('msg').'</div>';
                }?>
                <?php echo form_open('c_aset/proses_pindah_lokasi');?>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group mb-3">
                        <label><b>QR</b></label>
                        <input type="text" class="form-control" name="id_stok" id="id_stok_pl" placeholder="QR Code" required>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Jenis Barang</b></label>
                        <input type="text" class="form-control" name="nama_jenis_barang" id="nama_jenis_barang" placeholder="Jenis Barang" readonly>
                        <input type="hidden" name="id_jenis_barang" id="id_jenis_barang">
                        <input type="hidden" name="label_jns_barang" id="label_jns_barang">
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Nama Model</b></label>
                        <input type="text" class="form-control" name="nama_model" id="nama_model" placeholder="Model Barang" readonly>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Supplier</b></label>
                        <input type="text" class="form-control" name="nama_supplier" id="nama_supplier" placeholder="Supplier" readonly>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Kode Aset</b></label>
                        <input type="text" class="form-control" name="id_aset" id="id_aset" placeholder="Kode Aset" readonly>
                      </div>
                    </div> <!-- /.col -->
                    <div class="col-md-6">
                      <div class="form-group mb-3">
                        <label><b>Lokasi</b></label>
                        <select class="form-control select2" name="lokasi" id="lokasi" style="width: 100%">
                            <option value=""></option>
                          <?php foreach($lokasi as $data){
                            echo '<option value='.$data->id_lokasi.'>'.$data->nama_lokasi.'</option>';
                          }?>
                        </select>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Detail Lokasi</b></label>
                        <input type="text" class="form-control" name="detail_lokasi" id="detail_lokasi" placeholder="Detail Lokasi" required>
                      </div>
                      <div class="form-group mb-3" id="form_tipe_user">
                        <label><b>Tipe User</b></label>
                        <select class="form-control select2" name="tipe_user" id="tipe_user" style="width: 100%">
                          <option value=""></option>
                          <option value="nik">NIK</option>
                          <option value="non_nik">NON NIK</option>
                        </select>
                      </div>
                      <div class="form-group mb-3" id="form_nik">
                        <label><b>Karyawan</b></label>
                        <select class="form-control select2" name="nik" id="nik" style="width: 100%">
                          <option value=""></option>
                        </select>
                      </div>
                      <div class="form-group mb-3" id="form_nama_user">
                        <label><b>Non Karyawan</b></label>
                        <input type="text" class="form-control" name="nama_user" id="nama_user" placeholder="Non Karyawan">
                      </div>  
                      <div class="form-group mb-3">
                        <label><b>Tanggal Pindah</b></label>
                        <input type="text" class="form-control drgpicker" name="tanggal_pindah" id="tanggal_pindah" placeholder="Tanggal Pindah" required>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Pemindah</b></label>
                        <input type="text" class="form-control" name="pemindah" id="pemindah" placeholder="Pemindah" required>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Keterangan</b></label>
                        <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan"></textarea>
                      </div>
                      <div class="form-group mb-3">
                        <button class="btn mb-2 btn-info btn-sm">Simpan</button>
                      </div>
                    </div>
                  </div>
                </div>
                <?php echo form_close();?>
              </div> <!-- / .card -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      $('.drgpicker').daterangepicker(
      {
        singleDatePicker: true,
        timePicker: false,
        showDropdowns: true,
        locale:
        {
          format: 'YYYY-MM-DD'
        }
      });
      $('.time-input').timepicker(
      {
        'scrollDefault': 'now',
        'zindex': '9999' /* fix modal open */
      });

      $('.select2').select2(
      {
        theme: 'bootstrap4',
        placeholder: '--- Pilih Salah Satu ---'
      });

      $(function(){
        $('#nik').select2({
        theme: 'bootstrap4',
        placeholder : '--- Pilih Karyawan ---',
        ajax: {
          dataType: 'JSON',
          url: '<?=site_url('c_aset/get_karyawan_2')?>',
          type: "POST",
          delay: 250,
          data: function(params) {
            return {
              searchTerm: params.term
            }
          },
          processResults: function (response) {
              return {
                results: response
              };
          }
        },
        cache: true
        });
      });

      $('#form_nik').hide();
      $('#form_nama_user').hide();

      $("#tipe_user").change(function(){
            if($("#tipe_user").val() == 'nik'){
              $("#form_nik").show();
              $("#nama_user").val('');
              $("#form_nama_user").hide();
            }else{
              $("#nik").val('');
              $("#form_nik").hide();
              $("#form_nama_user").show();
            }
      });

      $('#id_stok_pl').change(function(){
        $.ajax({
          url:"<?php echo site_url('c_aset/cek_status_pl/')?>"+$('#id_stok_pl').val(),
          success : function(o) {
            console.log(o)         
              if(o.status=='ok'){
                var data = o.data
                $('#id_jenis_barang').val(data.id_jenis_barang);
                $('#nama_jenis_barang').val(data.nama_jenis_barang);
                $('#label_jns_barang').val(data.label_jns_barang);
                $('#nama_model').val(data.nama_model);
                $('#nama_supplier').val(data.nama_supplier);
                $('#id_aset').val(data.id_aset);
              }else{
                alert(o.msg);
                location.reload();              
              }
          },
          error : function(data) {
          // do something
          console.log(data)
        }
        });
      });
    </script>
  </body>
</html>