<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Management User</h2>
              <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                  <button type="button" class="btn mb-2 btn-success" onclick="add_user()">Tambah User</button>
                  <div class="card shadow">
                    <div class="card-body">
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="table_user" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th>No</th>
                            <th>ID User</th>
                            <th>Nama User</th>
                            <th>Username</th>
                            <th>Level</th>
                            <th>Created_at</th>
                            <th>Updated_at</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        table = $('#table_user').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_user/get_data_user')?>",
            "type": "POST"
          },
        });
      });

      function reload_table(){
        table.ajax.reload(null,false);
      }

      //JS add user
    function add_user(){
        save_method = 'add_user';
        $('#form_user')[0].reset();
        $('.select2').select2({
          placeholder: '--- Pilih Level User ---',
          theme: 'bootstrap4'
        });
        $('#level').val(null).trigger('change');
        $('.form-group').removeClass('has-error'); // clear error class
        $('#user_form').modal('show'); // show bootstrap modal
        $('#username').show();
        $('#password').show();
        $('.modal-title').text('Form Tambah User'); // Set Title to Bootstrap modal title
    }

    function edit_user(id_user){
        save_method = 'edit_user';
        $('#form_user')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class

        $.ajax({
            url : "<?php echo site_url('c_user/edit_user_')?>/"+id_user,
            type: "GET",
            dataType: "JSON",
            success: function(data){     
                $('[name="id_user"]').val(data.id_user);
                $('[name="nama_user"]').val(data.nama_user);
                $('#level').val(data.level).select2({theme: 'bootstrap4'});               
                $('#user_form').modal('show'); // show bootstrap modal when complete loaded
                $('#username').hide();
                $('#password').hide();
                $('.modal-title').text('Form Edit User'); // Set title to Bootstrap modal title     
            },
            error: function (jqXHR, textStatus, errorThrown){
                alert('Gagal menampilkan data user');
            }
        });
    }

    //JS save user
    function saveuser(){
        $('#saveuser').text('saving...'); //change button text
        $('#saveuser').attr('disabled',true); //set button disable 
        var url;
     
        if(save_method == 'add_user') {
            url = "<?php echo site_url('c_user/add_user_process')?>";
        } else {
            url = "<?php echo site_url('c_user/update_user_process')?>";
        }
     
        // ajax adding data to database
        $.ajax({
            url : url,
            type: "POST",
            data: $('#form_user').serialize(),
            dataType: "JSON",
            success: function(data){     
                if(data.status) //if success close modal and reload ajax table
                {
                    $('#user_form').modal('hide');
                    reload_table();
                }     
                $('#saveuser').text('simpan'); //change button text
                $('#saveuser').attr('disabled',false); //set button enable
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Gagal edit / tambah data user');
                $('#saveuser').text('simpan'); //change button text
                $('#saveuser').attr('disabled',false); //set button enable
            }
        });
    }

    function reset_pass(id_user){
        $('#form_reset')[0].reset();
        $('.form-group').removeClass('has-error');

        $.ajax({
            url : "<?php echo site_url('c_user/reset_password')?>/"+id_user,
            type: "GET",
            dataType: "JSON",
            success: function(data){     
                $('[name="id_user"]').val(data.id_user);
                $('[name="nama_user"]').val(data.nama_user);
                $('[name="username"]').val(data.username);               
                $('#reset_form').modal('show'); // show bootstrap modal when complete loaded
                $('.modal-title').text('Reset Password'); // Set title to Bootstrap modal title     
            },
            error: function (jqXHR, textStatus, errorThrown){
                alert('Gagal menampilkan data user');
            }
        });
    }

    function resetPass(){
        $('#btnReset').text('updating...'); //change button text
        $('#btnReset').attr('disabled',true); //set button disable
        
        $.ajax({
            url : "<?php echo site_url('c_user/reset_pass_process')?>",
            type: "POST",
            data: $('#form_reset').serialize(),
            dataType: "JSON",
            success: function(data){     
                if(data.status) //if success close modal and reload ajax table
                {
                    $('#reset_form').modal('hide');
                    reload_table();
                }     
                $('#btnReset').text('Update'); //change button text
                $('#btnReset').attr('disabled',false); //set button enable
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error tambah / update data');
                $('#btnReset').text('Update'); //change button text
                $('#btnReset').attr('disabled',false); //set button enable
            }
        });         
    }

    function delete_user(id_user){
        if(confirm('Apakah anda yakin menghapus user ini ?')){
            // ajax delete data to database
            $.ajax({
                url : "<?php echo site_url('c_user/delete_user_process')?>/"+id_user,
                type: "POST",
                dataType: "JSON",
                success: function(data){
                    //if success reload ajax table
                    // $('#user_form').modal('hide');
                    reload_table();
                },
                error: function (jqXHR, textStatus, errorThrown){
                    alert('Gagal menghapus data user');
                }
            });     
        }
    }

    </script>
  </body>
</html>

<div class="modal fade" id="user_form" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel"></h5>
      </div>
      <div class="modal-body">
        <form action="#" id="form_user">
          <div class="form-group">
            <label class="col-form-label"><b>Nama User</b></label>
            <input type="hidden" name="id_user">
            <input type="text" class="form-control" name="nama_user" placeholder="Nama user" required>
          </div>
          <div class="form-group" id="username">
            <label class="col-form-label"><b>Username</b></label>
            <input type="text" class="form-control" name="username" placeholder="Username" required>
          </div>
          <div class="form-group" id="password">
            <label class="col-form-label"><b>Password</b></label>
            <input type="password" class="form-control" name="password" placeholder="*****" required>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Level</b></label>
            <select class="form-control select2" name="level" id="level">
                <option value=""></option>
                <option value="1">Administrator</option>
                <option value="2">PIC Aset</option>
                <option value="3">User</option>
                <option value="4">Report</option>
                <option value="5">Nonaktif</option>
            </select>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" id="saveuser" onclick="saveuser()" class="btn mb-2 btn-primary">Simpan</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="reset_form" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel">Reset Password</h5>
      </div>
      <div class="modal-body">
        <form action="#" id="form_reset">
          <div class="form-group">
            <label class="col-form-label"><b>Nama User</b></label>
            <input type="hidden" name="id_user">
            <input type="text" class="form-control" name="nama_user" disabled>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Username</b></label>
            <input type="text" class="form-control" name="username" disabled>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Password</b></label>
            <input type="password" class="form-control" name="password" placeholder="Password Baru" required>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" id="btnReset" onclick="resetPass()" class="btn mb-2 btn-primary">Reset</button>
      </div>
    </div>
  </div>
</div>