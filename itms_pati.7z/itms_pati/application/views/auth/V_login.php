<!doctype html>
<html lang="en">
     <head>
        <meta charset="UTF-8">
        <!-- For IE -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- For Resposive Device -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>IT-MS HWI Pati</title>
        <!-- Favicon -->
        <link rel="icon" href="<?php echo base_url();?>assets/avatars/logo.jpg">
        <!-- Bootstrap  -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
        <!-- Main style sheet -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style.css">
        <!-- Fix Internet Explorer ______________________________________-->
        <!--[if lt IE 9]>
        <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
    </head>
    <body>
        <!-- Login Page -->
        <div class="container-fluid login-1">
            <div class="container">
                <div class="login-form">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <div class="img-box">
                                <img src="<?php echo base_url();?>assets/images/login-img.png" class="back-img" title="login" alt="welcome image">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="login-box">
                                <?php echo form_open('c_user/proses_login');?>
                                    <div class="form-group">
                                        <h4 class="login-title">Login Page</h4>
                                        <p class="login-p">IT Management System HWI Pati</p>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" name="username" placeholder="Username" class="form-control" required>
                                        <input type="password" name="password" placeholder="*******" class="form-control" required>
                                    </div>
                                    <center><b><?php echo $this->session->flashdata('error_msg'); ?></b></center>
                                    <div class="form-group text-center">
                                        <button type="submit" class="btn btn-primary">Login</button>
                                    </div>
                                <?php echo form_close();?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Login Page -->
    </body>
</html>