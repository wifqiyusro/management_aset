      <main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Input Barang Surat Jalan</h2>
              <div class="card shadow mb-4">
              <?php if($this->session->flashdata('status') != null){
                  echo '<div class="alert alert-'.$this->session->flashdata('status').'" role="alert">
                        <span class="fe fe-alert-circle fe-16 mr-2"></span>'.$this->session->flashdata('msg').'</div>';
                }?>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Surat Jalan</b></label>
                        <div class="col-sm-9">
                        <select class="form-control select2" style="width: 100%" name="surat_jalan" id="surat_jalan">
                          <option value="0">-- Pilih Salah Satu --</option>
                          <?php foreach($surat_jalan as $data){
                              echo"<option value=".$data->id_surat_jalan.">".$data->surat_jalan."</option>";
                          }?>
                        </select>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Packing List</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="packing_list" id="packing_list" placeholder="Packing List" readonly>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Tanggal</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="tanggal" id="tanggal" placeholder="Tanggal Surat Jalan" readonly>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Vendor</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="nama_supplier" id="nama_supplier" placeholder="Nama Vendor" readonly>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Keterangan</b></label>
                        <div class="col-sm-9">
                            <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan" readonly></textarea>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>QR</b></label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" name="id_stok_b" id="id_stok_b" placeholder="QR Aset" autofocus="autofocus">
                        </div>
                      </div>                                          
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Barang</b></label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" name="nama_model" id="nama_model" placeholder="Model Barang" autofocus="autofocus" readonly>
                          <input type="hidden" name="nama_jenis_barang" id="nama_jenis_barang">
                          <input type="hidden" name="no_po" id="no_po">
                        </div>
                      </div>                                            
                    </div> <!-- /.col -->
                    <div class="col-md-6">
                      <div class="form-group row">
                          <label class="col-sm-3 col-form-label"><b>SN</b></label>
                          <div class="col-sm-9">
                              <input type="text" class="form-control" name="sn" id="sn" placeholder="Serial Number" autofocus="autofocus" readonly>
                          </div>
                      </div> 
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Kategori</b></label>
                        <div class="col-sm-9">
                        <select class="form-control select2" style="width: 100%" name="kategori" id="kategori">
                          <option value="0">Service</option>
                          <option value="1">Return</option>
                        </select>
                        </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-sm-3 col-form-label"><b>Keterangan</b></label>
                          <div class="col-sm-9">
                          <textarea class="form-control" name="keterangan_barang" id="keterangan_barang" placeholder="Keterangan"></textarea>
                          </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Netto (Kg)</b></label>
                        <div class="col-sm-9">
                          <input type="number" class="form-control" name="netto" id="netto" placeholder="Netto" required>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Gross (Kg)</b></label>
                        <div class="col-sm-9">
                          <input type="number" class="form-control" name="gross" id="gross" placeholder="Gross" required>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Volume (m3)</b></label>
                        <div class="col-sm-9">
                          <input type="number" class="form-control" name="volume" id="volume" placeholder="Volume" required>
                        </div>
                      </div>                  
                      <div class="form-group mb-3">
                        <button class="btn mb-2 btn-info btn-sm" style="float:right;" id="input_barang_sj">Tambah Barang</button>
                        <button class="btn mb-2 btn-success btn-sm" style="float:left;" onclick="non_aset()">+ Non Aset</button>
                      </div>
                    </div>
                  </div>
                <table class="table table-bordered table-hover mb-0" cellspacing="0" width="100%">
                    <thead class="thead-dark" style="text-align: center;">
                        <tr>
                          <th>Jenis Barang</th>
                          <th>Barang</th>
                          <th>Unit</th>
                          <th>Qty</th>
                          <th>Kode</th>
                          <th>PO / Proyek</th>
                          <th>Kategori</th>
                          <th>Keterangan</th>
                          <th>Netto (Kg)</th>
                          <th>Gross (Kg)</th>
                          <th>Volume (m3)</th>
                          <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="tampil_data_surat_jalan">
                    </tbody>
                </table>
                <div class="row">
                  <div class="col-md-12">
                    <br><button type="button" class="btn mb-2 btn-danger btn-sm" style="float:right;" onclick="konfirm_sj()">Konfirm Surat Jalan</button>
                  </div>
                  </div>                
                </div>                
              </div> <!-- / .card -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      $(document).ready(function(){
        $('.select2').select2(
        {
          theme: 'bootstrap4',
        });
      });
      $('#surat_jalan').change(function(){
        $.ajax({
          url:"<?php echo site_url('c_surat_jalan/cek_surat_jalan/')?>"+$('#surat_jalan').val(),
          success : function(o) {
            console.log(o)         
              if(o.status=='ok'){
                var data = o.data
                $('#id_surat_jalan').val(data.id_surat_jalan);
                $('#packing_list').val(data.packing_list);
                $('#tanggal').val(data.tanggal);
                $('#nama_supplier').val(data.nama_supplier);
                $('#keterangan').val(data.keterangan);
                tampil_data_surat_jalan();
              }else{
                alert(o.msg);
                location.reload();              
              }
          },
          error : function(data) {
          // do something
          console.log(data)
        }
        });
      });
      
      $('#id_stok_b').change(function(){
        $.ajax({
          url:"<?php echo site_url('c_surat_jalan/cek_data_bi/')?>"+$('#id_stok_b').val(),
          success : function(o) {
            console.log(o)         
              if(o.status=='ok'){
                var data = o.data
                $('#nama_jenis_barang').val(data.nama_jenis_barang);
                $('#nama_model').val(data.nama_model);
                $('#id_stok_b').val(data.id_stok);
                $('#sn').val(data.sn);
                if(data.jenis_aset == '0' || data.jenis_aset == '1'){
                  $('#no_po').val(data.no_po);
                }else{
                  $('#no_po').val(data.nama_proyek);
                }
              }else{
                alert(o.msg);
                $('#nama_jenis_barang').val('');
                $('#nama_model').val('');
                $('#id_stok_b').val('');
                $('#sn').val('');
                $('#no_po').val('');
                $('#nama_jenis_barang').focus();
                $('#nama_model').focus();
                $('#id_stok_b').focus();
                $('#sn').focus();
                $('#no_po').focus();                                
              }
          },
          error : function(data) {
          // do something
          console.log(data)
        }
        });
      });

      $('#input_barang_sj').on('click',function(){       
        var id_stok_b = $('#id_stok_b').val();
        var surat_jalan = $('#surat_jalan').val();
        var nama_jenis_barang = $('#nama_jenis_barang').val();
        var nama_model = $('#nama_model').val();
        var sn = $('#sn').val();
        var no_po = $('#no_po').val();
        var kategori = $('#kategori').val();
        var keterangan_barang = $('#keterangan_barang').val();
        var netto = $('#netto').val();
        var gross = $('#gross').val();
        var volume = $('#volume').val();

        if(surat_jalan == '0' || id_stok_b == ''){
          alert("Surat jalan / QR aset belum dipilih");
        }else{
          $.ajax({
            type : "POST",
            url  : "<?php echo base_url('index.php/c_surat_jalan/tambah_barang_sj')?>",
            dataType : "JSON",
            data : {surat_jalan:surat_jalan,nama_jenis_barang:nama_jenis_barang,nama_model:nama_model,sn:sn,id_stok_b:id_stok_b,no_po:no_po,kategori:kategori,keterangan_barang:keterangan_barang,
            netto:netto,gross:gross,volume:volume},
            success : function(data){
                console.log(data)
                if(data.status=='ok'){
                  $('#nama_jenis_barang').val('');
                  $('#nama_model').val('');
                  $('#id_stok_b').val('');
                  $('#sn').val('');
                  $('#no_po').val('');
                  $('#keterangan_barang').val('');
                  $('#netto').val('');
                  $('#gross').val('');
                  $('#volume').val('');
                  $('#nama_jenis_barang').focus();
                  $('#nama_model').focus();
                  $('#id_stok_b').focus();
                  $('#sn').focus();
                  $('#no_po').focus();
                  $('#keterangan_barang').focus();
                  $('#netto').focus();
                  $('#gross').focus();
                  $('#volume').focus();
                  tampil_data_surat_jalan();
                }else{
                  alert(data.msg);
                  $('#nama_jenis_barang').val('');
                  $('#nama_model').val('');
                  $('#id_stok_b').val('');
                  $('#sn').val('');
                  $('#no_po').val('');
                  $('#keterangan_barang').val('');
                  $('#netto').val('');
                  $('#gross').val('');
                  $('#volume').val('');
                  $('#nama_jenis_barang').focus();
                  $('#nama_model').focus();
                  $('#id_stok_b').focus();
                  $('#sn').focus();
                  $('#no_po').focus();
                  $('#keterangan_barang').focus();  
                  $('#netto').focus();
                  $('#gross').focus();
                  $('#volume').focus();           
                }
            },
            error : function(data){
                console.log(data)
            }
          });
        }
      });

      tampil_data_surat_jalan();
      function tampil_data_surat_jalan(){

        $.ajax({
          type : 'ajax',
          url  : '<?php echo site_url('c_surat_jalan/datatabel/')?>'+$('#surat_jalan').val(),
          async : false,
          dataType : 'json',
          success : function(data){
            var html = '';
            var i;
            for(i=0; i<data.length; i++){
              html +='<tr>'+
                        '<td style="text-align:center;">'+data[i].nama_jenis_barang+'</td>'+
                        '<td>'+data[i].nama_model+'</td>'+
                        '<td style="text-align:center;">'+data[i].unit+'</td>'+
                        '<td style="text-align:center;">'+data[i].qty+'</td>'+                        
                        '<td style="text-align:center;">'+data[i].qr+'</td>'+
                        '<td style="text-align:center;">'+data[i].no_po+'</td>'+
                        '<td style="text-align:center;">'+data[i].kategori_sj+'</td>'+
                        '<td style="text-align:center;">'+data[i].keterangan+'</td>'+
                        '<td style="text-align:center;">'+data[i].netto+'</td>'+
                        '<td style="text-align:center;">'+data[i].gross+'</td>'+
                        '<td style="text-align:center;">'+data[i].volume+'</td>'+
                        '<td style="text-align:center;">'+
                          '<a href="javascript:;" class="btn mb-1 btn-danger btn-sm hapus_barang" id_sj="'+data[i].id_surat_jalan+'" qr="'+data[i].qr+'"><span class="fe fe-trash fe-16"></span></a>'+
                        '</td>'+
                      '</tr>';
            }
            $('#tampil_data_surat_jalan').html(html);
          }
        });
      }

      $('#tampil_data_surat_jalan').on('click','.hapus_barang',function(){
        var id_sj = $(this).attr('id_sj');
        var qr = $(this).attr('qr');
        $('#ModalHapus').modal('show');
        $('[name="id_surat_jalan"]').val(id_sj);
        $('[name="id_stok"]').val(qr);
      });

      function btn_hapus(){
        $.ajax({
            url : "<?php echo base_url('index.php/c_surat_jalan/hapus_barang');?>",
            type: "POST",
            data: $('#form_hapus').serialize(),
            dataType: "JSON",
            success: function(data){     
              $('#ModalHapus').modal('hide');
              tampil_data_surat_jalan();
            }
        });
      }

      function non_aset(){
        $('#form_barang_nonaset')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class
        $('#modal_nonaset').modal('show'); // show bootstrap modal
        $('.modal-title').text('Tambah Barang Non Aset'); // Set Title to Bootstrap modal title
        var sj_na = $('#surat_jalan').val();
        $('[name="sj_na"]').val(sj_na);
      }

      function tambahbarang_na(){
        $('#tambahbarang_na').text('menambahkan...'); //change button text
        $('#tambahbarang_na').attr('disabled',true); //set button disable
     
        // ajax adding data to database
        $.ajax({
            url : "<?php echo site_url('c_surat_jalan/tambah_barang_na')?>",
            type: "POST",
            data: $('#form_barang_nonaset').serialize(),
            dataType: "JSON",
            success: function(data){     
                if(data.status) //if success close modal and reload ajax table
                {
                    $('#modal_nonaset').modal('hide');
                    tampil_data_surat_jalan();
                }     
                $('#tambahbarang_na').text('Tambah Barang'); //change button text
                $('#tambahbarang_na').attr('disabled',false); //set button enable
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Gagal menambahkan barang non aset');
                $('#tambahbarang_na').text('Tambah Barang'); //change button text
                $('#tambahbarang_na').attr('disabled',false); //set button enable
            }
        });
      }

      function konfirm_sj(){
        var konfirm_sj = $('#surat_jalan').val();
        if(konfirm_sj == '0'){
          $('#modal_konfirm').modal('hide');
          alert('Surat jalan belum dipilih');
        }else{
          $('#form_konfirm')[0].reset();
          $('.form-group').removeClass('has-error'); // clear error class
          $('#modal_konfirm').modal('show'); // show bootstrap modal
          $('.modal-title').text('Konfirmasi Surat Jalan'); // Set Title to Bootstrap modal title        
          $('[name="konfirm_sj"]').val(konfirm_sj);
        }
      }

      function btn_konfirm(){
        $.ajax({
          url : "<?php echo base_url('index.php/c_surat_jalan/konfirmasi_sj');?>",
          type : "POST",
          dataType : "JSON",
          data: $('#form_konfirm').serialize(),
          success : function(data){
            $('#modal_konfirm').modal('hide');
            window.location.reload();
          }
        });
      }

    </script>
  </body>
  
<div class="modal fade" id="ModalHapus" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel">Hapus Barang</h5>
      </div>
      <div class="modal-body">
        <form id="form_hapus">
          Apakah anda yakin ingin menghapus barang ini ?
          <input type="hidden" name="id_surat_jalan" id="sj">
          <input type="hidden" name="id_stok" id="id_stok">
        </form>
      </div>      
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" class="btn mb-2 btn-danger" onclick="btn_hapus()">Hapus</button>
    </div>
    </div>
  </div>
</div>

<!-- Modal Non Aset -->
<div id="modal_nonaset" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel"></h5>
      </div>
      <div class="modal-body">
        <form action="#" id="form_barang_nonaset">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">            
                <label class="col-form-label"><b>Jenis Barang</b></label>
                <input type="text" class="form-control" name="jenis_barang_na" placeholder="Jenis Barang" required>
                <input type="hidden" name="sj_na">
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Barang</b></label>
                <input type="text" class="form-control" name="nama_model_na" placeholder="Nama Barang" required>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Serial Number</b></label>
                <input type="text" class="form-control" name="sn_na" placeholder="Serial Number" required>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Qty</b></label>
                <input type="number" class="form-control" name="qty_na" placeholder="Qty" required>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>No PO</b></label>
                <input type="text" class="form-control" name="no_po_na" placeholder="No PO" required>
              </div>
                     
            </div>
            <div class="col-md-6">
              <div class="form-group">            
                <label class="col-form-label"><b>Kategori</b></label>
                <select class="form-control select2" name="kategori_na">
                  <option value="0">Service</option>
                  <option value="1">Return</option>
                </select>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Keterangan</b></label>
                <textarea class="form-control" name="keterangan_na" placeholder="Keterangan"></textarea>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Netto (Kg)</b></label>
                <input type="text" class="form-control" name="netto_na" placeholder="Netto" required>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Gross (Kg)</b></label>
                <input type="text" class="form-control" name="gross_na" placeholder="Gross" required>
              </div>
              <div class="form-group">            
                <label class="col-form-label"><b>Volume (m3)</b></label>
                <input type="text" class="form-control" name="volume_na" placeholder="Volume" required>
              </div>
            </div>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" id="tambahbarang_na" onclick="tambahbarang_na()" class="btn btn-primary">Tambah Barang</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div> <!-- medium modal -->

<div class="modal fade" id="modal_konfirm" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel"></h5>
      </div>
      <div class="modal-body">
        <form id="form_konfirm">
          Apakah data surat jalan ini sudah benar ?
          <input type="hidden" name="konfirm_sj">
        </form>
      </div>      
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" class="btn mb-2 btn-danger" onclick="btn_konfirm()">Ya</button>
    </div>
    </div>
  </div>
</div>

</html>

