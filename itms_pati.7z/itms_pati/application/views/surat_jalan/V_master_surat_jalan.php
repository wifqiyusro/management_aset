<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Master Surat Jalan</h2>
              <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                  <?php if($this->session->userdata('level_a')=='1' || $this->session->userdata('level_a')=='2'){?>
                  <button type="button" class="btn mb-2 btn-success" onclick="add_surat_jalan()">Tambah Surat Jalan</button>
                  <?php } ?>
                  <div class="card shadow">
                    <div class="card-body">
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="table_surat_jalan" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th>No</th>
                            <th>Surat Jalan</th>
                            <th>Packing List</th>
                            <th>Tanggal</th>
                            <th>Vendor / Supplier</th>
                            <th>Pengirim</th>
                            <th>Status</th>
                            <th>Keterangan</th>
                            <th>Created at</th>
                            <th>Updated at</th>
                            <th>Aksi</th>
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        table = $('#table_surat_jalan').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_surat_jalan/get_master_surat_jalan')?>",
            "type": "POST"
          },
        });

      });

      function reload_table(){
        table.ajax.reload(null,false);
      }

      //JS add user
    function add_surat_jalan(){
        save_method = 'add_surat_jalan';
        $('#form_surat_jalan')[0].reset();
        $('.select2').select2({
          placeholder: '--- Pilih Vendor ---',
          theme: 'bootstrap4'
        });
        $('#supplier').val(null).trigger('change');
        $('.form-group').removeClass('has-error'); // clear error class
        $('#surat_jalan_form').modal('show'); // show bootstrap modal
        $('.modal-title').text('Form Tambah Master Surat Jalan'); // Set Title to Bootstrap modal title
    }

    function edit_surat_jalan(id_surat_jalan){
        save_method = 'edit_surat_jalan';
        $('#form_surat_jalan')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class

        $.ajax({
            url : "<?php echo site_url('c_surat_jalan/edit_surat_jalan_')?>/"+id_surat_jalan,
            type: "GET",
            dataType: "JSON",
            success: function(data){     
                $('[name="id_surat_jalan"]').val(data.id_surat_jalan);
                $('[name="surat_jalan"]').val(data.surat_jalan);
                $('[name="packing_list"]').val(data.packing_list);
                $('[name="tanggal"]').val(data.tanggal); 
                $('#supplier').val(data.supplier).select2({theme: 'bootstrap4'});
                $('[name="pengirim"]').val(data.pengirim);
                $('[name="keterangan"]').val(data.keterangan);               
                $('#surat_jalan_form').modal('show'); // show bootstrap modal when complete loaded
                $('.modal-title').text('Form Edit Master surat jalan'); // Set title to Bootstrap modal title     
            },
            error: function (jqXHR, textStatus, errorThrown){
                alert('Gagal menampilkan data master surat jalan');
            }
        });
    }

    //JS save user
    function savesuratjalan(){
        $('#savesuratjalan').text('saving...'); //change button text
        $('#savesuratjalan').attr('disabled',true); //set button disable 
        var url;
     
        if(save_method == 'add_surat_jalan') {
            url = "<?php echo site_url('c_surat_jalan/add_surat_jalan_process')?>";
        } else {
            url = "<?php echo site_url('c_surat_jalan/update_surat_jalan_process')?>";
        }
     
        // ajax adding data to database
        $.ajax({
            url : url,
            type: "POST",
            data: $('#form_surat_jalan').serialize(),
            dataType: "JSON",
            success: function(data){     
                if(data.status) //if success close modal and reload ajax table
                {
                    $('#surat_jalan_form').modal('hide');
                    reload_table();
                }     
                $('#savesuratjalan').text('simpan'); //change button text
                $('#savesuratjalan').attr('disabled',false); //set button enable
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Gagal edit / tambah data master surat jalan');
                $('#savesuratjalan').text('simpan'); //change button text
                $('#savesuratjalan').attr('disabled',false); //set button enable
            }
        });
    }
    </script>
  </body>
</html>

<div class="modal fade" id="surat_jalan_form" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel"></h5>
      </div>
      <div class="modal-body">
        <form action="#" id="form_surat_jalan">
          <div class="form-group">
            <label class="col-form-label"><b>Surat Jalan</b></label>
            <input type="text" class="form-control" name="surat_jalan" placeholder="No Surat Jalan" required>
            <input type="hidden" name="id_surat_jalan" id="id_surat_jalan">
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Packing List</b></label>
            <input type="text" class="form-control" name="packing_list" placeholder="Packing List" required>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Tanggal</b></label>
            <input type="date" class="form-control" name="tanggal" placeholder="Tanggal Surat Jalan" required>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Vendor / Supplier</b></label>
            <select class="form-control select2" name="supplier" id="supplier">
                <option value=""></option>
                <?php foreach($supplier as $dt){
                    echo '<option value='.$dt->id_supplier.'>'.$dt->nama_supplier.'</option>';
                }?>
            </select>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Pengirim</b></label>
            <input type="text" class="form-control" name="pengirim" placeholder="Pengirim" required>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Keterangan</b></label>
            <textarea class="form-control" name="keterangan" placeholder="Keterangan" required></textarea>
          </div>          
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" id="savesuratjalan" onclick="savesuratjalan()" class="btn mb-2 btn-primary">Simpan</button>
      </div>
    </div>
  </div>
</div>