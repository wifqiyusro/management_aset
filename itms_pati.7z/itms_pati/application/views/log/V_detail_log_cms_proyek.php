<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Detail Log Consumable Proyek</h2>
              <div class="row my-4">
                <div class="col-md-12">
                  <div class="card shadow">
                    <div class="card-body">
                      <div class="col-md-5">
                        <form class="form-horizontal" id="filter" method="post">
                        <div class="form-group row">
                          <label for="inputEmail3" class="col-sm-5 col-form-label"><b>Nama Barang</b></label>
                          <label for="inputEmail3" class="col-sm-7 col-form-label"><b><?php echo $data->nama_barang;?></b></label>
                          <input type="hidden" name="kode_barang" id="kode_barang" value="<?php echo $kode_barang?>">
                        </div>
                        <div class="form-group row">
                          <label for="inputEmail3" class="col-sm-5 col-form-label"><b>Stok Terakhir</b></label>
                          <label for="inputEmail3" class="col-sm-7 col-form-label"><b><?php echo $data->stok;?></b> <b><?php echo $data->satuan;?></b></label>
                        </div>
                        <div class="form-group row">
                          <label for="inputEmail3" class="col-sm-5 col-form-label"><b>Tanggal Mulai</b></label>
                          <div class="col-sm-7">
                                <input type="date" class="form-control" name="tgl_mulai" id="tgl_mulai" placeholder="Tanggal Mulai">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label for="inputEmail3" class="col-sm-5 col-form-label"><b>Tanggal Selesai</b></label>
                          <div class="col-sm-7">
                                <input type="date" class="form-control" name="tgl_selesai" id="tgl_selesai" placeholder="Tanggal Selesai">
                          </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-7 ml-sm-auto">
                                <button class="btn mb-2 btn-info btn-sm" type="button" id="btn_filter">Filter</button>
                                <button class="btn mb-2 btn-success btn-sm" type="button" onclick="getExcel()">Export</button>
                                <button class="btn mb-2 btn-secondary btn-sm" type="button" id="btn_reset">Reset</button>
                            </div>
                        </div>
                        </form>
                      </div>
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="detail_log_cms_proyek" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th>No</th>
                            <th>Aktivitas</th>
                            <th>Jml Transaksi</th>
                            <!-- <th>Sisa</th> -->
                            <th>Satuan</th>
                            <th>Tanggal</th>
                            <th>Surat Jalan</th>
                            <th>User</th>
                            <th>Keterangan</th>
                            <th>Created at</th>
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.checkboxes.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        table = $('#detail_log_cms_proyek').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_cms_proyek/get_detail_log_cms_proyek/'.$kode_barang);?>",
            "type": "POST",
            "data": function(data){
                data.tgl_mulai = $('#tgl_mulai').val();
                data.tgl_selesai = $('#tgl_selesai').val();
            }
          }          
        });
      });

      // $('.drgpicker').datepicker(
      // {
      //   singleDatePicker: true,
      //   timePicker: false,
      //   showDropdowns: true,
      //   locale:
      //   {
      //     format: 'YYYY-MM-DD'
      //   }
      // });

      $('#btn_filter').click(function(){ //button filter event click
        table.ajax.reload();  //just reload table
      });

      $('#btn_reset').click(function(){ //button reset event click
        $('#filter')[0].reset();
        table.ajax.reload();  //just reload table
      });
      
      function getExcel(){
        var kode_barang = $('#kode_barang').val();
        var tgl_mulai = ($('#tgl_mulai').val()?$('#tgl_mulai').val():'-');
        var tgl_selesai = ($('#tgl_selesai').val()?$('#tgl_selesai').val():'-');    
        window.open("<?php echo site_url('c_cms_proyek/export_detail_log_cms_proyek/');?>"+kode_barang+'/'+tgl_mulai+'/'+tgl_selesai,"_blank");
      }

    </script>
  </body>
</html>
