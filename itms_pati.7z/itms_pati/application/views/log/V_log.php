<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <!-- <h2 class="page-title">Daftar Aset</h2> -->
              <div class="row">
                <div class="col-md-12 mb-4">
                  <div class="accordion accordion-boxed" id="accordion2">
                    <div class="card shadow">
                      <div class="card-header" id="headingOne">
                        <a role="button" href="#collapseOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                          <strong>ASET IT DEPARTEMENT</strong>
                        </a>
                      </div>
                      <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion2">
                        <div class="card-body">
                          <?php
                            foreach ($aset as $dt) {
                              $url = base_url().'index.php/c_aset/detail_aset/'.$dt->kode;
                                $label = $dt->nama_aset;                                  
                                  echo 
                                    anchor($url,$label,array('class'=>'btn mb-2 btn-info btn-sm'));
                                  echo ' ';
                            }
                          ?>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow">
                      <div class="card-header" id="headingTwo">
                        <a role="button" href="#collapseTwo" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTow">
                          <strong>HISTORY : <?php echo $nama_model;?></strong>
                        </a>
                      </div>
                      <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#accordion2">
                        <div class="card-body">
                          <div class="row">
                            <div class="col-md-6">
                              <table class="table table-bordered table-striped">
                                <tbody>
                                  <tr>
                                    <td><b>Jenis Barang</b></td>
                                    <td><?php echo $cek_nama->nama_aset;?></td>
                                  </tr>
                                  <?php if($jenis_aset == '0' || $jenis_aset == '1'){?>
                                  <tr>
                                    <td><b>No PO/Rental</b></td>
                                    <td><?php echo $transaksi->no_po;?></td>
                                  </tr>
                                  <tr>
                                    <td><b>Tanggal PO/Rental</b></td>
                                    <td><?php echo $transaksi->tanggal_po;?></td>
                                  </tr>
                                  <?php }else{ ?>
                                  <tr>
                                    <td><b>Nama Proyek</b></td>
                                    <td><?php echo $transaksi->nama_proyek;?></td>
                                  </tr>
                                  <tr>
                                    <td><b>Tanggal Proyek</b></td>
                                    <td><?php echo $transaksi->tanggal;?></td>
                                  </tr>
                                  <?php } ?>
                                  <tr>
                                    <td><b>Kode Aset</b></td>
                                    <td><?php echo $cek_nama->id_aset;?></td>
                                  </tr>
                                  <tr>
                                    <td><b>Supplier</b></td>
                                    <td><?php echo $cek_nama->nama_supplier;?></td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                          </div>
                          <table class="table table-bordered table-hover mb-0 datatables" id="table_log" cellspacing="0" width="100%">
                            <thead style="text-align: center;" class="thead-dark">
                              <tr>
                                <th>No</th>
                                <th>Status</th>
                                <th>Vendor</th>
                                <th>Tanggal</th>
                                <th>No PO / Surat Jalan</th>
                                <th>Keterangan</th>
                                <th>Created at</th>
                              </tr>
                            </thead>
                            <tbody style="text-align: center;">                          
                            </tbody>
                          </table>
                          <!-- </div>  --><!-- end section -->                          
                        </div>
                      </div>                      
                    </div>
                  </div>
                </div>
              </div> <!-- end section -->
            </div> <!-- .col-12 -->                
                <!-- <div class="col-md-12 mb-4">
                  <div class="card shadow">                    
                    <div class="card-body">                     
                    </div> 
                  </div> 
                </div>  -->
              </div>
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script>
      var table;
      $(document).ready(function(){
        table = $('#table_log').DataTable({
          "processing":true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide":true,
          "ordering":false,
          "order":[],
          "ajax":{
            "url": "<?php echo site_url('c_log/get_data_log/'.$id_stok.'/'.$jenis_aset);?>",
            "type":"POST"
          },
        });
      });

      //JS reload table
      function reload_table(){
        table.ajax.reload(null,false); //reload datatable ajax 
      }
     

      window.dataLayer = window.dataLayer || [];

      function gtag()
      {
        dataLayer.push(arguments);
      }
      gtag('js', new Date());
      gtag('config', 'UA-56159088-1');
    </script>
  </body>
</html>
