      <main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Transaksi Consumable Proyek</h2>
              <div class="card shadow mb-4">
                <?php if($this->session->flashdata('status') != null){
                  echo '<div class="alert alert-'.$this->session->flashdata('status').'" role="alert">
                        <span class="fe fe-alert-circle fe-16 mr-2"></span>'.$this->session->flashdata('msg').'</div>';
                }?>
                <?php echo form_open('c_cms_proyek/proses_transaksi');?>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group mb-3">
                        <label><b>Jenis Transaksi</b></label>
                        <select class="form-control select2" name="jenis_transaksi" id="jenis_transaksi" style="width: 100%">
                          <option value="">-- Pilih Transaksi --</option>
                          <option value="2">Masuk</option>
                          <option value="3">Keluar</option>
                          <option value="4">Kembali</option>
                        </select>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Nama Barang</b></label>
                        <select class="form-control select2" name="kode_barang" id="kode_barang" style="width: 100%">
                            <option value="">-- Pilih Barang --</option>
                          <?php foreach($data as $dt){
                            echo '<option value='.$dt->kode_barang.'>'.$dt->nama_barang.'</option>';
                          }?>
                        </select>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Stok</b></label>
                        <input type="text" class="form-control" name="stok" id="stok" placeholder="Stok" readonly>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Satuan</b></label>
                        <input type="text" class="form-control" name="satuan" id="satuan" placeholder="Satuan" readonly>
                      </div>
                      <div class="form-group mb-3" id="surat_jalan">
                        <label><b>Surat Jalan</b></label>
                        <input type="text" name="no_surat_jalan" id="no_surat_jalan" class="form-control" placeholder="No Surat Jalan">
                      </div>
                    </div> <!-- /.col -->
                    <div class="col-md-6">
                      <div class="form-group mb-3">
                        <label><b>Jumlah</b></label>
                        <input type="number" class="form-control" name="jumlah" id="jumlah" placeholder="Jumlah" required>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>User</b></label>
                        <input type="text" class="form-control" name="pengguna" id="pengguna" placeholder="User" required>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Tanggal Transaksi</b></label>
                        <input type="text" class="form-control drgpicker" name="tanggal" id="tanggal" placeholder="Tanggal Transaksi" required>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Keterangan</b></label>
                        <textarea class="form-control" name="keperluan" id="keperluan" placeholder="Keterangan" required></textarea>
                      </div>
                      <div class="form-group mb-3">
                        <button class="btn mb-2 btn-info btn-sm">Simpan</button>
                      </div>
                    </div>
                  </div>
                </div>
                <?php echo form_close();?>
              </div> <!-- / .card -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">

      $("#kode_barang").change(function(){
          $.ajax({
            url:"<?php echo site_url('c_cms_proyek/get_detail_barang/');?>"+$('#kode_barang').val(),
            success : function(o){
              console.log(o)
              if(o.status=='ok'){
                var data = o.data
                $('#stok').val(data.stok);
                $('#satuan').val(data.satuan);
              }else{
                alert(o.msg)
                location.reload();
              }
            },
            error : function(data) {
            console.log(data)
            }
          });
      });

      $('#surat_jalan').hide();

      $('#jenis_transaksi').change(function(){
        if($('#jenis_transaksi').val() == '2'){
            $('#surat_jalan').show();
        }else{
            $('#surat_jalan').hide();
        }
      });

      $('#jumlah').change(function(){
        $.ajax({
          url : "<?php echo site_url('c_cms_proyek/cek_status_jumlah/');?>"+$('#kode_barang').val()+'/'+$('#jumlah').val()+'/'+$('#jenis_transaksi').val(),
          success : function(o) {
            console.log(o)         
              if(o.status=='ok'){
                         
              }else{
                alert(o.msg);
                location.reload();              
              }
          },
          error : function(data) {
          // do something
          console.log(data)
        }
        });
      });

      $('.drgpicker').daterangepicker(
      {
        singleDatePicker: true,
        timePicker: false,
        showDropdowns: true,
        locale:
        {
          format: 'YYYY-MM-DD'
        }
      });

      $('.select2').select2(
      {
        theme: 'bootstrap4',
      });
    </script>
  </body>
</html>