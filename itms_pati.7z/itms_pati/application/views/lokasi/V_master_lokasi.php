<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Master Lokasi</h2>
              <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                  <?php if($this->session->userdata('level_a')=='1' || $this->session->userdata('level_a')=='2'){?>
                  <button type="button" class="btn mb-2 btn-success" onclick="add_lokasi()">Tambah Lokasi</button>
                  <?php } ?>
                  <div class="card shadow">
                    <div class="card-body">
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="table_lokasi" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th>No</th>
                            <th>Nama Lokasi</th>
                            <th>Kode Label</th>
                            <th>Created at</th>
                            <th>Updated at</th>
                            <th>Aksi</th>
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        table = $('#table_lokasi').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_lokasi/get_master_lokasi')?>",
            "type": "POST"
          },
        });
      });

      function reload_table(){
        table.ajax.reload(null,false);
      }

      //JS add user
    function add_lokasi(){
        save_method = 'add_lokasi';
        $('#form_lokasi')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class
        $('#lokasi_form').modal('show'); // show bootstrap modal
        $('.modal-title').text('Form Tambah Master Lokasi'); // Set Title to Bootstrap modal title
    }

    function edit_lokasi(id_lokasi){
        save_method = 'edit_lokasi';
        $('#form_lokasi')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class

        $.ajax({
            url : "<?php echo site_url('c_lokasi/edit_lokasi_')?>/"+id_lokasi,
            type: "GET",
            dataType: "JSON",
            success: function(data){     
                $('[name="id_lokasi"]').val(data.id_lokasi);
                $('[name="nama_lokasi"]').val(data.nama_lokasi);
                $('[name="label"]').val(data.label);          
                $('#lokasi_form').modal('show'); // show bootstrap modal when complete loaded
                $('.modal-title').text('Form Edit Master Lokasi'); // Set title to Bootstrap modal title     
            },
            error: function (jqXHR, textStatus, errorThrown){
                alert('Gagal menampilkan data master lokasi');
            }
        });
    }

    //JS save user
    function savelokasi(){
        $('#savelokasi').text('saving...'); //change button text
        $('#savelokasi').attr('disabled',true); //set button disable 
        var url;
     
        if(save_method == 'add_lokasi') {
            url = "<?php echo site_url('c_lokasi/add_lokasi_process')?>";
        } else {
            url = "<?php echo site_url('c_lokasi/update_lokasi_process')?>";
        }
     
        // ajax adding data to database
        $.ajax({
            url : url,
            type: "POST",
            data: $('#form_lokasi').serialize(),
            dataType: "JSON",
            success: function(data){     
                if(data.status) //if success close modal and reload ajax table
                {
                    $('#lokasi_form').modal('hide');
                    reload_table();
                }     
                $('#savelokasi').text('simpan'); //change button text
                $('#savelokasi').attr('disabled',false); //set button enable
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Gagal edit / tambah data master lokasi');
                $('#savelokasi').text('simpan'); //change button text
                $('#savelokasi').attr('disabled',false); //set button enable
            }
        });
    }
    </script>
  </body>
</html>

<div class="modal fade" id="lokasi_form" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel"></h5>
      </div>
      <div class="modal-body">
        <form action="#" id="form_lokasi">
          <div class="form-group">
            <label class="col-form-label"><b>Nama Lokasi</b></label>
            <input type="text" class="form-control" name="nama_lokasi" placeholder="Nama Lokasi" required>
            <input type="hidden" name="id_lokasi" id="id_lokasi">
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Label Lokasi</b></label>
            <input type="text" class="form-control" name="label" placeholder="Label Lokasi" required>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" id="savelokasi" onclick="savelokasi()" class="btn mb-2 btn-primary">Simpan</button>
      </div>
    </div>
  </div>
</div>