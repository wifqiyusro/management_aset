      <main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <div class="row">
                <div class="col-md-6 col-xl-2 mb-4">
                  <div class="card shadow mb-1">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-3 text-center">
                          <span class="circle circle-sm bg-primary">
                            <i class="fe fe-16 fe-shopping-cart text-white mb-0"></i>
                          </span>
                        </div>
                        <div class="col pr-0">
                          <p class="small text-muted mb-0">Stok</p>
                          <span class="h3 mb-0"><?php echo $stok;?></span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-xl-2 mb-4">
                  <div class="card shadow mb-1">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-3 text-center">
                          <span class="circle circle-sm bg-success">
                            <i class="fe fe-16 fe-check-square text-white mb-0"></i>
                          </span>
                        </div>
                        <div class="col pr-0">
                          <p class="small text-muted mb-0">Terpasang</p>
                          <span class="h3 mb-0"><?php echo $pasang;?></span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-xl-2 mb-4">
                  <div class="card shadow mb-1">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-3 text-center">
                          <span class="circle circle-sm bg-warning">
                            <i class="fe fe-16 fe-x-octagon text-white mb-0"></i>
                          </span>
                        </div>
                        <div class="col pr-0">
                          <p class="small text-muted mb-0">Rusak di IT</p>
                          <span class="h3 mb-0"><?php echo $rusak_it;?></span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-xl-2 mb-4">
                  <div class="card shadow mb-1">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-3 text-center">
                          <span class="circle circle-sm bg-danger">
                            <i class="fe fe-16 fe-tool text-white mb-0"></i>
                          </span>
                        </div>
                        <div class="col pr-0">
                          <p class="small text-muted mb-0">Rusak di Vendor</p>
                          <span class="h3 mb-0"><?php echo $rusak_vendor;?></span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-xl-2 mb-4">
                  <div class="card shadow mb-1">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-3 text-center">
                          <span class="circle circle-sm bg-info">
                            <i class="fe fe-16 fe-list text-white mb-0"></i>
                          </span>
                        </div>
                        <div class="col pr-0">
                          <p class="small text-muted mb-0">Total Aset</p>
                          <span class="h3 mb-0"><?php echo $all;?></span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-xl-2 mb-4">
                  <div class="card shadow mb-1">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-3 text-center">
                          <span class="circle circle-sm bg-secondary">
                            <i class="fe fe-16 fe-user text-white mb-0"></i>
                          </span>
                        </div>
                        <div class="col pr-0">
                          <p class="small text-muted mb-0">User System</p>
                          <span class="h3 mb-0"><?php echo $user;?></span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">                
                <div class="col-md-12 col-lg-6">
                  <div class="card shadow">
                    <div class="card-header">
                      <strong class="card-title">Informasi Log Aset</strong>
                      <a class="float-right small text-muted" href="<?php echo base_url();?>index.php/c_log/log_barang">View all</a>
                    </div>
                      <div class="card-body">
                        <div class="list-group list-group-flush my-n3">
                          <?php foreach($data as $dt){?>
                          <div class="list-group-item">
                            <div class="row align-items-center">
                              <div class="col-auto">
                                <?php if($dt->status_log=='0'){
                                  echo '<span class="circle circle-sm bg-primary"><i class="fe fe-shopping-cart fe-16 text-white"></i></span>';
                                }elseif($dt->status_log=='1'){
                                  echo '<span class="circle circle-sm bg-success"><i class="fe fe-check-square fe-16 text-white"></i></span>';
                                }elseif($dt->status_log=='3'){
                                  echo '<span class="circle circle-sm bg-warning"><i class="fe fe-home fe-16 text-white"></i></span>';
                                }else{
                                  echo '<span class="circle circle-sm bg-danger"><i class="fe fe-tool fe-16 text-white"></i></span>';
                                }?>
                              </div>
                              <div class="col">
                                <small><strong><?php echo $dt->created_at;?></strong></small>
                                <div class="mb-2 text-muted small"><?php echo $dt->nama_model.' <strong>['.$dt->id_stock.']</strong> '.$dt->keterangan;?></div>
                                <?php if($dt->status_log == '0'){                                  
                                  echo '<span class="badge badge-pill badge-primary">Stok</span>';
                                }elseif($dt->status_log == '1'){
                                  echo '<span class="badge badge-pill badge-success">Terpasang</span>';
                                }elseif($dt->status_log == '3'){
                                  echo '<span class="badge badge-pill badge-warning">Rusak IT</span>';
                                }else{
                                  echo '<span class="badge badge-pill badge-danger">Rusak Vendor</span>';
                                }?>
                                
                              </div>
                              <div class="col-auto pr-0">
                                <small class="fe fe-more-vertical fe-16 text-muted"></small>
                              </div>
                            </div> <!-- / .row -->
                          </div><!-- / .list-group-item -->
                          <?php } ?>
                        </div> <!-- / .list-group -->
                      </div> <!-- / .card-body -->
                    </div> <!-- / .card -->
                </div> <!-- Striped rows -->
                <div class="col-md-12 col-lg-6">
                  <div class="card shadow">
                    <div class="card-header">
                      <strong class="card-title">Waiting Barang PO</strong>
                      <a class="float-right small text-muted" href="<?php echo base_url();?>index.php/c_aset/konfirmasi_po">View all</a>
                    </div>
                      <div class="card-body">
                        <div class="list-group list-group-flush my-n3">
                          <?php if($po > 0){
                            echo '
                              <div class="list-group-item">
                                <div class="row align-items-center">
                                  <div class="col-auto">
                                    <span class="fe fe-inbox fe-24"></span>
                                  </div>
                                  <div class="col">
                                    <small>'.$po.' PO aset perlu dikonfirmasi</small>
                                  </div>
                                </div>
                              </div>
                            ';
                          }else{
                            echo '-';
                          }?>                          
                        </div> <!-- / .list-group -->
                      </div> <!-- / .card-body -->
                  </div> <!-- / .card -->
                  <div class="card shadow">
                    <div class="card-header">
                      <strong class="card-title">Waiting Barang Rental</strong>
                      <a class="float-right small text-muted" href="<?php echo base_url();?>index.php/c_aset/konfirmasi_rental">View all</a>
                    </div>
                      <div class="card-body">
                        <div class="list-group list-group-flush my-n3">
                          <?php if($rental > 0){
                            echo '
                              <div class="list-group-item">
                                <div class="row align-items-center">
                                  <div class="col-auto">
                                    <span class="fe fe-inbox fe-24"></span>
                                  </div>
                                  <div class="col">
                                    <small>'.$rental.' PO rental perlu dikonfirmasi</small>
                                  </div>
                                </div>
                              </div>
                            ';
                          }else{
                            echo '-';
                          }?>     
                        </div> <!-- / .list-group -->
                    </div> <!-- / .card-body -->
                  </div> <!-- / .card -->
                  <div class="card shadow">
                    <div class="card-header">
                      <strong class="card-title">Waiting Barang Consumable</strong>
                      <a class="float-right small text-muted" href="<?php echo base_url();?>index.php/c_cms/konfirmasi_cms">View all</a>
                    </div>
                      <div class="card-body">
                        <div class="list-group list-group-flush my-n3">
                          <?php if($cms > 0){
                            echo '
                              <div class="list-group-item">
                                <div class="row align-items-center">
                                  <div class="col-auto">
                                    <span class="fe fe-inbox fe-24"></span>
                                  </div>
                                  <div class="col">
                                    <small>'.$cms.' PO konsumable perlu dikonfirmasi</small>
                                  </div>
                                </div>
                              </div>
                            ';
                          }else{
                            echo '-';
                          }?>
                        </div> <!-- / .list-group -->
                    </div> <!-- / .card-body -->
                  </div> <!-- / .card -->
                  <div class="card shadow">
                    <div class="card-header">
                      <strong class="card-title">Karyawan Resign</strong>
                      <a class="float-right small text-muted" href="<?php echo base_url();?>index.php/c_karyawan/karyawan_resign">View all</a>
                    </div>
                      <div class="card-body">
                        <?php if($jml_resign > 0){?>                       
                        <table class="table table-bordered table-hover mb-0 datatables" id="table_detail_aset" cellspacing="0" width="100%">
                          <thead class="thead-dark" style="text-align: center;">
                            <tr>
                              <th>No</th>
                              <th>NIK</th>
                              <th>Nama</th>
                              <th>Departement</th>
                              <th>Gedung</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                              $no = 1;
                              foreach($karyawan as $dt){
                                echo '
                                  <tr>
                                    <td>'.$no.'</td>
                                    <td>'.$dt->nik.'</td>
                                    <td>'.$dt->NAME.'</td>
                                    <td>'.$dt->DEPARTEMENT.'</td>
                                    <td>'.$dt->NAMA_GEDUNG.'</td>
                                  </tr>
                                '; $no++;
                              }
                            ?>         
                          </tbody>
                        </table>
                        <?php }else{
                          echo '-';
                        }?>                        
                      </div>
                    </div> 
                  </div>
                </div> <!-- Striped rows -->
              </div> <!-- .row-->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/d3.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/topojson.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/datamaps.all.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/datamaps-zoomto.js"></script>
    <script src="<?php echo base_url();?>assets/js/datamaps.custom.js"></script>
    <script src="<?php echo base_url();?>assets/js/Chart.min.js"></script>
    <script>
      /* defind global options */
      Chart.defaults.global.defaultFontFamily = base.defaultFontFamily;
      Chart.defaults.global.defaultFontColor = colors.mutedColor;
    </script>
    <script src="<?php echo base_url();?>assets/js/gauge.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.sparkline.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/apexcharts.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/apexcharts.custom.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.mask.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.steps.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.validate.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/dropzone.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/uppy.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/quill.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script>
      $('.select2').select2(
      {
        theme: 'bootstrap4',
      });
      $('.select2-multi').select2(
      {
        multiple: true,
        theme: 'bootstrap4',
      });
      $('.drgpicker').daterangepicker(
      {
        singleDatePicker: true,
        timePicker: false,
        showDropdowns: true,
        locale:
        {
          format: 'MM/DD/YYYY'
        }
      });
      $('.time-input').timepicker(
      {
        'scrollDefault': 'now',
        'zindex': '9999' /* fix modal open */
      });
      /** date range picker */
      if ($('.datetimes').length)
      {
        $('.datetimes').daterangepicker(
        {
          timePicker: true,
          startDate: moment().startOf('hour'),
          endDate: moment().startOf('hour').add(32, 'hour'),
          locale:
          {
            format: 'M/DD hh:mm A'
          }
        });
      }
      var start = moment().subtract(29, 'days');
      var end = moment();

      function cb(start, end)
      {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
      }
      $('#reportrange').daterangepicker(
      {
        startDate: start,
        endDate: end,
        ranges:
        {
          'Today': [moment(), moment()],
          'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days': [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month': [moment().startOf('month'), moment().endOf('month')],
          'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
      }, cb);
      cb(start, end);
      $('.input-placeholder').mask("00/00/0000",
      {
        placeholder: "__/__/____"
      });
      $('.input-zip').mask('00000-000',
      {
        placeholder: "____-___"
      });
      $('.input-money').mask("#.##0,00",
      {
        reverse: true
      });
      $('.input-phoneus').mask('(000) 000-0000');
      $('.input-mixed').mask('AAA 000-S0S');
      $('.input-ip').mask('0ZZ.0ZZ.0ZZ.0ZZ',
      {
        translation:
        {
          'Z':
          {
            pattern: /[0-9]/,
            optional: true
          }
        },
        placeholder: "___.___.___.___"
      });
      // editor
      var editor = document.getElementById('editor');
      if (editor)
      {
        var toolbarOptions = [
          [
          {
            'font': []
          }],
          [
          {
            'header': [1, 2, 3, 4, 5, 6, false]
          }],
          ['bold', 'italic', 'underline', 'strike'],
          ['blockquote', 'code-block'],
          [
          {
            'header': 1
          },
          {
            'header': 2
          }],
          [
          {
            'list': 'ordered'
          },
          {
            'list': 'bullet'
          }],
          [
          {
            'script': 'sub'
          },
          {
            'script': 'super'
          }],
          [
          {
            'indent': '-1'
          },
          {
            'indent': '+1'
          }], // outdent/indent
          [
          {
            'direction': 'rtl'
          }], // text direction
          [
          {
            'color': []
          },
          {
            'background': []
          }], // dropdown with defaults from theme
          [
          {
            'align': []
          }],
          ['clean'] // remove formatting button
        ];
        var quill = new Quill(editor,
        {
          modules:
          {
            toolbar: toolbarOptions
          },
          theme: 'snow'
        });
      }
      // Example starter JavaScript for disabling form submissions if there are invalid fields
      (function()
      {
        'use strict';
        window.addEventListener('load', function()
        {
          // Fetch all the forms we want to apply custom Bootstrap validation styles to
          var forms = document.getElementsByClassName('needs-validation');
          // Loop over them and prevent submission
          var validation = Array.prototype.filter.call(forms, function(form)
          {
            form.addEventListener('submit', function(event)
            {
              if (form.checkValidity() === false)
              {
                event.preventDefault();
                event.stopPropagation();
              }
              form.classList.add('was-validated');
            }, false);
          });
        }, false);
      })();
    </script>
    <script>
      var uptarg = document.getElementById('drag-drop-area');
      if (uptarg)
      {
        var uppy = Uppy.Core().use(Uppy.Dashboard,
        {
          inline: true,
          target: uptarg,
          proudlyDisplayPoweredByUppy: false,
          theme: 'dark',
          width: 770,
          height: 210,
          plugins: ['Webcam']
        }).use(Uppy.Tus,
        {
          endpoint: 'https://master.tus.io/files/'
        });
        uppy.on('complete', (result) =>
        {
          console.log('Upload complete! We’ve uploaded these files:', result.successful)
        });
      }
    </script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];

      function gtag()
      {
        dataLayer.push(arguments);
      }
      gtag('js', new Date());
      gtag('config', 'UA-56159088-1');
    </script>
  </body>
</html>