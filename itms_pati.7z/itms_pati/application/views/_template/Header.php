<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo base_url();?>assets/avatars/logo.jpg">
    <title>ITMS HWI Pati</title>
    <!-- Simple bar CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/simplebar.css">
    <!-- Fonts CSS -->
    <link href="https://fonts.googleapis.com/css2?family=Overpass:ital,wght@0,100;0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <!-- Icons CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/feather.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/select2.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/dropzone.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/uppy.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery.steps.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery.timepicker.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/quill.snow.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/dataTables.bootstrap4.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/dataTables.checkboxes.css">
    <!-- Date Range Picker CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/daterangepicker.css">
    <!-- App CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/app-light.css" id="lightTheme">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/app-dark.css" id="darkTheme">
  </head>
  <body class="horizontal light  ">
    <div class="wrapper">
      <nav class="navbar navbar-expand-lg navbar-light bg-white flex-row border-bottom shadow">
        <div class="container-fluid">
          <button class="navbar-toggler mt-2 mr-auto toggle-sidebar text-muted">
            <i class="fe fe-menu navbar-toggler-icon"></i>
          </button>
          <div class="navbar-slide bg-white ml-lg-4" id="navbarSupportedContent">
            <a href="#" class="btn toggle-sidebar d-lg-none text-muted ml-2 mt-3" data-toggle="toggle">
              <i class="fe fe-x"><span class="sr-only"></span></i>
            </a>
            <ul class="navbar-nav mr-auto">
              <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url();?>index.php/welcome">
                  <span class="fe fe-home fe-16"></span>
                </a>
              </li>
              <li class="nav-item dropdown more">
                <a class="dropdown-toggle nav-link" href="#" id="moreDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <span class="ml-lg-2">Master Data</span>
                </a>
                <ul class="dropdown-menu" aria-labelledby="moreDropdown">
                  <li class="nav-item dropdown">
                    <a class="dropdown-toggle nav-link pl-lg-2" href="#" data-toggle="collapse" id="pagesDropdown" aria-expanded="false">
                      <span class="ml-1">Master Aset</span>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="pagesDropdown">
                      <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_jenis_barang/kelompok_aset"><span class="ml-1">Kelompok Aset</span></a>
                      <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_jenis_barang"><span class="ml-1">Jenis Barang</span></a>
                      <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_barang"><span class="ml-1">Barang</span></a>
                      <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_proyek"><span class="ml-1">Proyek</span></a>
                      <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_supplier"><span class="ml-1">Supplier</span></a>
                      <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_lokasi"><span class="ml-1">Lokasi</span></a>
                    </ul>
                  </li>
                  <li class="nav-item dropdown">
                    <a class="dropdown-toggle nav-link pl-lg-2" href="#" data-toggle="collapse" id="authDropdown" aria-expanded="false">
                      <span class="ml-1">Master Consumable</span>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="authDropdown">
                      <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_cms/kategori_cms"><span class="ml-1">Kategori Consumable</span></a>
                      <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_cms"><span class="ml-1">Consumable</span></a>
                      <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_cms_proyek"><span class="ml-1">Consumable Proyek</span></a>    
                    </ul>
                  </li>
                  
                  <li class="nav-item dropdown">
                    <a class="dropdown-toggle nav-link pl-lg-2" href="#" data-toggle="collapse" id="layoutsDropdown" aria-expanded="false">
                      <span class="ml-1">Master PO</span>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="layoutsDropdown">
                      <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_po"><span class="ml-1">Aset</span></a>
                      <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_po/po_cms"><span class="ml-1">Consumable</span></a>
                      <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_po/po_service"><span class="ml-1">Service</span></a>
                    </ul>
                  </li>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_surat_jalan"><span class="ml-1">Master Surat Jalan</span></a>
                </ul>
              </li>              
              <?php if($this->session->userdata('level_a')=='1' || $this->session->userdata('level_a')=='2'){?>
              <li class="nav-item dropdown">
                <a href="#" id="ui-elementsDropdown" class="dropdown-toggle nav-link" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <span class="ml-lg-2">Input Barang</span>
                </a>
                <ul class="dropdown-menu" aria-labelledby="moreDropdown">
                  <li class="nav-item dropdown">
                    <a class="dropdown-toggle nav-link pl-lg-2" href="#" data-toggle="collapse" id="pagesDropdown" aria-expanded="false">
                      <span class="ml-1">PO</span>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="pagesDropdown">
                      <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_aset/input_barang_po"><span class="ml-1">Aset</span></a>
                      <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_aset/input_barang_cms"><span class="ml-1">Consumable</span></a>
                      <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_aset/input_barang_service"><span class="ml-1">Service</span></a>
                    </ul>
                    <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_aset/input_barang_rental"><span class="ml-1">Rental</span></a>
                    <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_aset/input_barang_proyek"><span class="ml-1">Projek</span></a>
                    <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_surat_jalan/input_surat_jalan"><span class="ml-1">Surat Jalan</span></a>
                  </li>
                </ul>
              </li>
              <li class="nav-item dropdown">
                <a href="#" id="ui-elementsDropdown" class="dropdown-toggle nav-link" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <span class="ml-lg-2">Konfirmasi Barang</span>
                </a>
                <div class="dropdown-menu" aria-labelledby="ui-elementsDropdown">
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_aset/konfirmasi_po"><span class="ml-1">PO</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_aset/konfirmasi_rental"><span class="ml-1">Rental</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_cms/konfirmasi_cms"><span class="ml-1">Consumable</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_aset/konfirmasi_service"><span class="ml-1">Service</span></a>
                </div>
              </li>
              <?php } 
                if($this->session->userdata('level_a')=='1' || $this->session->userdata('level_a')=='2' || $this->session->userdata('level_a')=='3'){
              ?>
              <li class="nav-item dropdown">
                <a href="#" id="ui-elementsDropdown" class="dropdown-toggle nav-link" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <span class="ml-lg-2">Transaksi Aset</span>
                </a>
                <div class="dropdown-menu" aria-labelledby="ui-elementsDropdown">
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_aset/status_aset"><span class="ml-1">Status Barang</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_aset/barang_keluar"><span class="ml-1">Barang Keluar</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_aset/barang_kembali"><span class="ml-1">Barang Kembali</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_aset/pindah_lokasi"><span class="ml-1">Pindah Lokasi</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_aset/barang_rusak_it"><span class="ml-1">Rusak di IT</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_aset/barang_rusak_vendor"><span class="ml-1">Rusak di Vendor</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_aset/transfer_hwi_jepara"><span class="ml-1">Transfer HWI Jepara</span></a>
                </div>
              </li>              
              <li class="nav-item dropdown">
                <a href="#" id="ui-elementsDropdown" class="dropdown-toggle nav-link" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <span class="ml-lg-2">Transaksi Consumable</span>
                </a>
                <div class="dropdown-menu" aria-labelledby="ui-elementsDropdown">
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_cms/transaksi"><span class="ml-1">Consumable</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_cms_proyek/transaksi"><span class="ml-1">Consumable Proyek</span></a>
                </div>
              </li>
              <?php } ?>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url();?>index.php/c_aset">
                  <span class="ml-lg-2">Detail Aset</span>
                </a>
              </li>
              <li class="nav-item dropdown">
                <a href="#" id="ui-elementsDropdown" class="dropdown-toggle nav-link" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <span class="ml-lg-2">Log Barang</span>
                </a>
                <div class="dropdown-menu" aria-labelledby="ui-elementsDropdown">
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_log/log_barang"><span class="ml-1">Log Aset</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_cms/log_cms"><span class="ml-1">Log Consumable</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_cms_proyek/log_cms_proyek"><span class="ml-1">Log Consumable Proyek</span></a>
                </div>
              </li>
              <li class="nav-item dropdown">
                <a href="#" id="ui-elementsDropdown" class="dropdown-toggle nav-link" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <span class="ml-lg-2">Report Data</span>
                </a>
                <div class="dropdown-menu" aria-labelledby="ui-elementsDropdown">
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_report/summary_aset"><span class="ml-1">Summary Aset</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_report/report_po"><span class="ml-1">PO Aset</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_report/report_cms"><span class="ml-1">PO Consumable</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_report/report_service"><span class="ml-1">PO Service</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_report/report_proyek"><span class="ml-1">Proyek Aset</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_report/barang_transfer"><span class="ml-1">Aset HWI 1</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_report/surat_jalan"><span class="ml-1">Surat Jalan</span></a>
                </div>
              </li>
              <li class="nav-item dropdown">
                <a href="#" id="ui-elementsDropdown" class="dropdown-toggle nav-link" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <span class="ml-lg-2">Manag. Surat</span>
                </a>
                <div class="dropdown-menu" aria-labelledby="ui-elementsDropdown">
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_surat/kategori_surat"><span class="ml-1">Master Kategori</span></a>
                  <a class="nav-link pl-lg-2" href="<?php echo base_url();?>index.php/c_surat/master_surat"><span class="ml-1">Master Surat</span></a>
                </div>
              </li>
            </ul>
          </div>
          <ul class="navbar-nav d-flex flex-row">
            <li class="nav-item dropdown ml-lg-0">
              <a class="nav-link dropdown-toggle text-muted" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="avatar avatar-sm mt-2">
                  <img src="<?php echo base_url();?>/assets/avatars/logo_it.jpg" alt="..." class="avatar-img rounded-circle">
                </span>
              </a>
              <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                <?php if($this->session->userdata('level_a') == '1'){ ?>
                <a class="dropdown-item" href="<?php echo base_url();?>index.php/c_user/add_user">Management User</a>
                <?php } ?>
                <a class="dropdown-item" href="<?php echo base_url();?>index.php/c_user/logout">Keluar</a>
              </ul>
            </li>
          </ul>
        </div>
      </nav>