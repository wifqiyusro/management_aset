      <main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Input Barang Consumable</h2>
              <div class="card shadow mb-4">
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>PO</b></label>
                        <div class="col-sm-9">
                        <select class="form-control select2" style="width: 100%" name="id_po" id="id_po">
                          <option value="">-- Pilih Salah Satu --</option>
                          <?php foreach($po as $data){
                              echo"<option value=".$data->id_po.">".$data->no_po."</option>";
                          }?>
                        </select>
                        </div>
                      </div>
                      <input type="hidden" name="id_po_2" id="id_po_2">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Tanggal PO</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="tanggal_po" id="tanggal_po" placeholder="Tanggal PO" readonly>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Supplier</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="nama_supplier" id="nama_supplier" placeholder="Nama supplier" readonly>
                            <input type="hidden" name="id_supplier" id="id_supplier">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Keterangan</b></label>
                        <div class="col-sm-9">
                            <textarea class="form-control" name="keperluan" id="keperluan" placeholder="Keterangan" readonly></textarea>
                        </div>
                      </div>
                    </div> <!-- /.col -->
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Kategori</b></label>
                            <div class="col-sm-9">
                                <select class="form-control select2"  style="width: 100%" name="id_kategori" id="id_kategori">
                                    <option value="0">-- Pilih Salah Satu --</option>
                                    <?php foreach($kategori as $data){
                                        echo"<option value=".$data->id_kategori.">".$data->nama_kategori."</option>";
                                    }?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Barang</b></label>
                            <div class="col-sm-9">
                                <select class="form-control select2"  style="width: 100%" name="kode_barang" id="kode_barang">
                                </select>
                            </div>
                        </div>                      
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Total Barang</b></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="jumlah" id="jumlah" placeholder="Total barang" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Kurs</b></label>
                            <div class="col-sm-9">
                                <select class="form-control select2"  style="width: 100%" name="kurs" id="kurs">
                                    <option value="IDR">IDR</option>
                                    <option value="USD">USD</option>
                                    <option value="KRW">KRW</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Harga Satuan</b></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="harga" id="harga" placeholder="Harga Satuan" required>
                            </div>
                        </div>
                        <input type="hidden" name="ip" id="ip" value="<?php echo $_SERVER['REMOTE_ADDR'];?>">                      
                      <div class="form-group mb-3">
                        <button class="btn mb-2 btn-info btn-sm" style="float:right;" id="tambah_barang_cms">Tambah Barang</button>
                      </div>
                    </div>
                  </div>
                <table class="table table-bordered table-hover mb-0" cellspacing="0" width="100%">
                    <thead class="thead-dark" style="text-align: center;">
                        <tr>
                          <th>Kategori</th>
                          <th>Barang</th>
                          <th>Jumlah</th>
                          <th>Satuan</th>
                          <th>Kurs</th>
                          <th>Harga</th>
                          <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="tampil_data_cms">
                    </tbody>
                </table>
                <div class="row">
                  <div class="col-md-12">
                    <br><button type="button" class="btn mb-2 btn-danger btn-sm" style="float:right;" id="btn_proses_cms">Simpan Data</button>
                  </div>
                  </div>                
                </div>                
              </div> <!-- / .card -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      $('.drgpicker').daterangepicker(
      {
        singleDatePicker: true,
        timePicker: false,
        showDropdowns: true,
        locale:
        {
          format: 'YYYY-MM-DD'
        }
      });
      $('.time-input').timepicker(
      {
        'scrollDefault': 'now',
        'zindex': '9999' /* fix modal open */
      });

      $('.select2').select2(
      {
        theme: 'bootstrap4',
      });

      $('#id_po').change(function(){
        $.ajax({
          url:"<?php echo site_url('c_po/cek_po_cms/')?>"+$('#id_po').val(),
          success : function(o) {
            console.log(o)         
              if(o.status=='ok'){
                var data = o.data
                $('#id_po_2').val(data.id_po);
                $('#tanggal_po').val(data.tanggal_po);
                $('#id_supplier').val(data.id_supplier);
                $('#nama_supplier').val(data.nama_supplier);
                $('#keperluan').val(data.keperluan);
              }else{
                alert(o.msg);
                location.reload();              
              }
          },
          error : function(data) {
          // do something
          console.log(data)
        }
        });
      });

      $("#id_kategori").change(function(){
          var value=$(this).val();
          $.ajax({
              data:{id:value},
              success: function(respond){
                  console.log(value);
                  $("#kode_barang").html(respond);
              }
          })
      });

      $.ajaxSetup({
          type: "POST",
          url: "<?php echo base_url('index.php/c_cms/cari_barang');?>",
          cache: false,
      });

      $('#tambah_barang_cms').on('click',function(){
        var id_kategori = $('#id_kategori').val();
        var kode_barang = $('#kode_barang').val();
        var id_po = $('#id_po_2').val();
        var id_supplier = $('#id_supplier').val();
        var jumlah = $('#jumlah').val();
        var kurs = $('#kurs').val();
        var harga = $('#harga').val();
        var ip = $('#ip').val();
        $.ajax({
            type : "POST",
            url  : "<?php echo base_url('index.php/c_cms/tambah_barang_cms')?>",
            dataType : "JSON",
            data : {id_kategori:id_kategori,kode_barang:kode_barang,id_po_2:id_po,id_supplier:id_supplier,jumlah:jumlah,kurs:kurs,harga:harga,ip:ip},
            success : function(data){
                console.log(data)
                if(data.status=='ok'){
                    tampil_data_cms();
                }else{
                    alert(data.msg)
                }
            },
            error : function(data){
                console.log(data)
            }
        });
      });

      tampil_data_cms();
      function tampil_data_cms(){
        $.ajax({
          type : 'ajax',
          url  : '<?php echo base_url()?>index.php/c_cms/datatabel_cms',
          async : false,
          dataType : 'json',
          success : function(data){
            var html = '';
            var i;
            for(i=0; i<data.length; i++){
              html +='<tr>'+
                        '<td>'+data[i].nama_kategori+'</td>'+
                        '<td>'+data[i].nama_barang+'</td>'+
                        '<td style="text-align:center;">'+data[i].jumlah+'</td>'+
                        '<td style="text-align:center;">'+data[i].satuan+'</td>'+
                        '<td style="text-align:center;">'+data[i].kurs+'</td>'+                        
                        '<td style="text-align:center;">'+data[i].harga+'</td>'+
                        '<td style="text-align:center;">'+
                          '<a href="javascript:;" class="btn mb-1 btn-danger btn-sm hapus_barang_cms" kode_barang="'+data[i].kode_barang+'"><span class="fe fe-trash fe-16"></span></a>'+
                        '</td>'+
                      '</tr>';
            }
            $('#tampil_data_cms').html(html);
          }
        });
      }

      $('#tampil_data_cms').on('click','.hapus_barang_cms',function(){
        var kode_barang = $(this).attr('kode_barang');
        $('#ModalHapus').modal('show');
        $('[name="kode_barang"]').val(kode_barang);
      });

      function btn_hapus_cms(){
        $.ajax({
            url : "<?php echo base_url('index.php/c_cms/hapus_barang_cms');?>",
            type: "POST",
            data: $('#form_hapus').serialize(),
            dataType: "JSON",
            success: function(data){     
              $('#ModalHapus').modal('hide');
              tampil_data_cms();
            }
        });
      }

      $('#btn_proses_cms').on('click',function(){
        var id_po_2 = $('#id_po_2').val();
        if(id_po_2 == ""){
          alert("PO belum dipilih");
        }else{
          $('#ModalSimpan').modal('show');
          $('[name="id_po_2"]').val(id_po_2);
        }
      });

      function btn_simpan_cms(){
        var id_po_proses = $('#id_po_proses').val();
        var ip_proses =  $('#ip_proses').val();
        $.ajax({
          url : "<?php echo base_url('index.php/c_cms/simpan_transaksi_cms');?>",
          type : "POST",
          dataType : "JSON",
          data: $('#form_simpan_cms').serialize(),
          success : function(data){
            $('#ModalSimpan').modal('hide');
            hapus_tb_bantu_cms(id_po_proses,ip_proses);
            window.location.reload();
          }
        });
      }

      function hapus_tb_bantu_cms(id_po,ip){
        $.ajax({
          type : 'ajax',
          url  : '<?php echo base_url()?>index.php/c_cms/hapus_tb_bantu_cms/'+id_po+'/'+ip,
          async: false,
          dataType : 'JSON',
          success : function(data){
          }
        });
      }
    
    </script>
  </body>
  
  <div class="modal fade" id="ModalHapus" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel">Hapus Barang</h5>
      </div>
      <div class="modal-body">
        <form id="form_hapus">
          Apakah anda yakin ingin menghapus barang ini ?
          <input type="hidden" name="kode_barang" id="kode_barang_2">
        </form>
      </div>      
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" class="btn mb-2 btn-danger" onclick="btn_hapus_cms()">Hapus</button>
    </div>
    </div>
  </div>
</div>

<div class="modal fade" id="ModalSimpan" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel">Konfirmasi Barang Consumable</h5>
      </div>
      <div class="modal-body">       
          Apakah anda yakin ingin menyimpan data ini ?
          <form id="form_simpan_cms">
          <input type="hidden" name="id_po_2" id="id_po_proses">
          <input type="hidden" name="ip_2" id="ip_proses" value="<?php echo $_SERVER['REMOTE_ADDR'];?>">
          </form> 
      </div>      
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" class="btn mb-2 btn-danger" onclick="btn_simpan_cms()">Simpan</button>
      </div>
   
    </div>
  </div>
</div>
</html>

