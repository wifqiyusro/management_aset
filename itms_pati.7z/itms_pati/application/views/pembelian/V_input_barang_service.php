      <main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Input Barang Service</h2>
              <div class="card shadow mb-4">
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>PO</b></label>
                        <div class="col-sm-9">
                        <select class="form-control select2" style="width: 100%" name="id_po" id="id_po">
                          <option value="">-- Pilih Salah Satu --</option>
                          <?php foreach($po as $data){
                              echo"<option value=".$data->id_po.">".$data->no_po."</option>";
                          }?>
                        </select>
                        </div>
                      </div>
                      <input type="hidden" name="id_po_2" id="id_po_2">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Tanggal PO</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="tanggal_po" id="tanggal_po" placeholder="Tanggal PO" readonly>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Supplier</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="nama_supplier" id="nama_supplier" placeholder="Nama supplier" readonly>
                            <input type="hidden" name="id_supplier" id="id_supplier">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Telephone</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="phone" id="phone" placeholder="Telephone" readonly>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Keterangan</b></label>
                        <div class="col-sm-9">
                            <textarea class="form-control" name="keperluan" id="keperluan" placeholder="Keterangan" readonly></textarea>
                        </div>
                      </div>
                    </div> <!-- /.col -->
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>QR</b></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="id_stok_s" id="id_stok_s" placeholder="QR" autofocus="autofocus">
                            </div>
                        </div>                                          
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Barang</b></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="nama_model" id="nama_model" placeholder="Model Barang" autofocus="autofocus" readonly>
                                <input type="hidden" name="id_barang" id="id_barang" autofocus="autofocus">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>SN</b></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="sn" id="sn" placeholder="Serial Number" autofocus="autofocus" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Harga Material</b></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="harga_material" id="harga_material" placeholder="Harga material" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Harga Jasa</b></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="harga_jasa" id="harga_jasa" placeholder="Harga jasa" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Keterangan</b></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan service" required>
                            </div>
                        </div>
                        <input type="hidden" name="ip" id="ip" value="<?php echo $_SERVER['REMOTE_ADDR'];?>">                      
                      <div class="form-group mb-3">
                        <button class="btn mb-2 btn-info btn-sm" style="float:right;" id="tambah_barang_service">Tambah Barang</button>
                      </div>
                    </div>
                  </div>
                <table class="table table-bordered table-hover mb-0" cellspacing="0" width="100%">
                    <thead class="thead-dark" style="text-align: center;">
                        <tr>
                          <th>QR</th>
                          <th>Barang</th>
                          <th>SN</th>
                          <th>Harga Material</th>
                          <th>Harga Jasa</th>
                          <th>Keterangan</th>
                          <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="tampil_data_service">
                    </tbody>
                </table>
                <div class="row">
                  <div class="col-md-12">
                    <br><button type="button" class="btn mb-2 btn-danger btn-sm" style="float:right;" id="btn_proses_service">Simpan Data</button>
                  </div>
                  </div>                
                </div>                
              </div> <!-- / .card -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      $('.drgpicker').daterangepicker(
      {
        singleDatePicker: true,
        timePicker: false,
        showDropdowns: true,
        locale:
        {
          format: 'YYYY-MM-DD'
        }
      });
      $('.time-input').timepicker(
      {
        'scrollDefault': 'now',
        'zindex': '9999' /* fix modal open */
      });

      $('.select2').select2(
      {
        theme: 'bootstrap4',
      });

      $('#id_po').change(function(){
        $.ajax({
          url:"<?php echo site_url('c_po/cek_po_service/')?>"+$('#id_po').val(),
          success : function(o) {
            console.log(o)         
              if(o.status=='ok'){
                var data = o.data
                $('#id_po_2').val(data.id_po);
                $('#tanggal_po').val(data.tanggal_po);
                $('#id_supplier').val(data.id_supplier);
                $('#nama_supplier').val(data.nama_supplier);
                $('#phone').val(data.phone);
                $('#keperluan').val(data.keperluan);
              }else{
                alert(o.msg);
                location.reload();              
              }
          },
          error : function(data) {
          // do something
          console.log(data)
        }
        });
      });
      
      $('#id_stok_s').change(function(){
        $.ajax({
          url:"<?php echo site_url('c_aset/cek_data_bv/')?>"+$('#id_stok_s').val()+"/"+$('#id_supplier').val(),
          success : function(o) {
            console.log(o)         
              if(o.status=='ok'){
                var data = o.data
                $('#id_barang').val(data.id_barang);
                $('#nama_model').val(data.nama_model);
                $('#sn').val(data.sn);
              }else{
                alert(o.msg);
                $('#id_stok_s').val('');
                $('#nama_model').val('');
                $('#id_barang').val('');
                $('#sn').val('');
                $('#id_stok_s').focus();
                $('#nama_model').focus();
                $('#id_barang').focus();
                $('#sn').focus();                              
              }
          },
          error : function(data) {
          // do something
          console.log(data)
        }
        });
      });

      $('#tambah_barang_service').on('click',function(){       
        var id_stok = $('#id_stok_s').val();
        var id_barang = $('#id_barang').val();
        var id_po = $('#id_po').val();
        var id_supplier = $('#id_supplier').val();
        var tanggal_po = $('#tanggal_po').val();
        var harga_material = $('#harga_material').val();
        var harga_jasa = $('#harga_jasa').val();
        var sn = $('#sn').val();
        var keterangan = $('#keterangan').val();
        var ip = $('#ip').val();
        $.ajax({
            type : "POST",
            url  : "<?php echo base_url('index.php/c_aset/tambah_barang_service')?>",
            dataType : "JSON",
            data : {id_stok:id_stok,id_barang:id_barang,id_po:id_po,id_supplier:id_supplier,tanggal_po:tanggal_po,harga_material:harga_material,harga_jasa:harga_jasa,sn:sn,keterangan:keterangan,ip:ip},
            success : function(data){
                console.log(data)
                if(data.status=='ok'){
                    $('#id_stok_s').val('');
                    $('#nama_model').val('');
                    $('#id_barang').val('');
                    $('#sn').val('');
                    $('#id_stok_s').focus();
                    $('#nama_model').focus();
                    $('#id_barang').focus();
                    $('#sn').focus();
                    tampil_data_service();
                }else{
                    alert(data.msg);
                    $('#id_stok_s').val('');
                    $('#nama_model').val('');
                    $('#id_barang').val('');
                    $('#sn').val('');
                    $('#id_stok_s').focus();
                    $('#nama_model').focus();
                    $('#id_barang').focus();
                    $('#sn').focus();                    
                }
            },
            error : function(data){
                console.log(data)
            }
        });
      });

      tampil_data_service();
      function tampil_data_service(){
        $.ajax({
          type : 'ajax',
          url  : '<?php echo base_url()?>index.php/c_aset/datatabel_service',
          async : false,
          dataType : 'json',
          success : function(data){
            var html = '';
            var i;
            for(i=0; i<data.length; i++){
              html +='<tr>'+
                        '<td style="text-align:center;">'+data[i].id_stok+'</td>'+
                        '<td>'+data[i].nama_model+'</td>'+
                        '<td style="text-align:center;">'+data[i].sn+'</td>'+
                        '<td style="text-align:center;">'+data[i].harga+'</td>'+                        
                        '<td style="text-align:center;">'+data[i].harga_jasa+'</td>'+
                        '<td style="text-align:center;">'+data[i].keterangan+'</td>'+
                        '<td style="text-align:center;">'+
                          '<a href="javascript:;" class="btn mb-1 btn-danger btn-sm hapus_barang_service" id_stok="'+data[i].id_stok+'"><span class="fe fe-trash fe-16"></span></a>'+
                        '</td>'+
                      '</tr>';
            }
            $('#tampil_data_service').html(html);
          }
        });
      }

      $('#tampil_data_service').on('click','.hapus_barang_service',function(){
        var id_stok = $(this).attr('id_stok');
        $('#ModalHapus').modal('show');
        $('[name="id_stok_2"]').val(id_stok);
      });

      function btn_hapus_service(){
        $.ajax({
            url : "<?php echo base_url('index.php/c_aset/hapus_barang_service');?>",
            type: "POST",
            data: $('#form_hapus').serialize(),
            dataType: "JSON",
            success: function(data){     
              $('#ModalHapus').modal('hide');
              tampil_data_service();
            }
        });
      }

      $('#btn_proses_service').on('click',function(){
        var id_po_2 = $('#id_po_2').val();
        if(id_po_2 == ""){
          alert("PO belum dipilih");
        }else{
          $('#ModalSimpan').modal('show');
          $('[name="id_po_2"]').val(id_po_2);
        }
      });

      function btn_simpan_service(){
        var id_po_proses = $('#id_po_proses').val();
        var ip_proses =  $('#ip_proses').val();
        $.ajax({
          url : "<?php echo base_url('index.php/c_aset/simpan_transaksi_service');?>",
          type : "POST",
          dataType : "JSON",
          data: $('#form_simpan_service').serialize(),
          success : function(data){
            $('#ModalSimpan').modal('hide');
            hapus_tb_bantu_service(id_po_proses,ip_proses);
            window.location.reload();
          }
        });
      }

      function hapus_tb_bantu_service(id_po,ip){
        $.ajax({
          type : 'ajax',
          url  : '<?php echo base_url()?>index.php/c_aset/hapus_tb_bantu_aset/'+id_po+'/'+ip,
          async: false,
          dataType : 'JSON',
          success : function(data){
          }
        });
      }
    
    </script>
  </body>
  
  <div class="modal fade" id="ModalHapus" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel">Hapus Barang</h5>
      </div>
      <div class="modal-body">
        <form id="form_hapus">
          Apakah anda yakin ingin menghapus barang ini ?
          <input type="hidden" name="id_stok_2" id="id_stok_2">
        </form>
      </div>      
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" class="btn mb-2 btn-danger" onclick="btn_hapus_service()">Hapus</button>
    </div>
    </div>
  </div>
</div>

<div class="modal fade" id="ModalSimpan" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel">Konfirmasi Barang Service</h5>
      </div>
      <div class="modal-body">       
          Apakah anda yakin ingin menyimpan data ini ?
          <form id="form_simpan_service">
          <input type="hidden" name="id_po_2" id="id_po_proses">
          <input type="hidden" name="ip_2" id="ip_proses" value="<?php echo $_SERVER['REMOTE_ADDR'];?>">
          </form> 
      </div>      
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" class="btn mb-2 btn-danger" onclick="btn_simpan_service()">Simpan</button>
      </div>
   
    </div>
  </div>
</div>
</html>

