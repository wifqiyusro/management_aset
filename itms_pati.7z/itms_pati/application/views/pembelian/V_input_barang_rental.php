      <main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Input Barang Rental</h2>
              <div class="card shadow mb-4">
                <?php if($this->session->flashdata('status') != null){
                  echo '<div class="alert alert-'.$this->session->flashdata('status').'" role="alert">
                        <span class="fe fe-alert-circle fe-16 mr-2"></span>'.$this->session->flashdata('msg').'</div>';
                }?>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>No Rental</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="no_rental" id="no_rental" placeholder="No Rental" required>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Supplier</b></label>
                        <div class="col-sm-9">
                        <select class="form-control select2" style="width: 100%" name="id_supplier" id="id_supplier">
                          <option value="">-- Pilih Salah Satu --</option>
                          <?php foreach($supplier as $data){
                              echo"<option value=".$data->id_supplier.">".$data->nama_supplier."</option>";
                          }?>
                        </select>
                        </div>
                      </div>
                      <input type="hidden" name="id_supplier_2" id="id_supplier_2">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Alamat Supplier</b></label>
                        <div class="col-sm-9">
                            <textarea class="form-control" name="alamat_supplier" id="alamat_supplier" placeholder="Alamat Supplier" readonly></textarea>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>No Surat Jalan</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="no_surat_jalan" id="no_surat_jalan" placeholder="No Surat Jalan" required>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Tanggal Rental</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control drgpicker" name="tanggal_rental" id="tanggal_rental" placeholder="Tanggal Rental" required>
                        </div>
                      </div>
                      <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Jenis Barang</b></label>
                            <div class="col-sm-9">
                                <select class="form-control select2" style="width: 100%" name="id_jenis_barang" id="id_jenis_barang">
                                    <option value="">-- Pilih Salah Satu --</option>
                                    <?php foreach($jenis_barang as $data){
                                        echo"<option value=".$data->id_jenis_barang.">".$data->nama_jenis_barang."</option>";
                                    }?>
                                </select>
                            </div>
                        </div>      
                    </div> <!-- /.col -->
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Barang</b></label>
                            <div class="col-sm-9">
                                <select class="form-control select2" style="width: 100%" name="id_barang" id="id_barang">
                                </select>
                            </div>
                        </div>                
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Total Barang</b></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="jumlah" id="jumlah" placeholder="Total barang" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Kurs</b></label>
                            <div class="col-sm-9">
                                <select class="form-control select2" style="width: 100%" name="kurs" id="kurs">
                                    <option value="IDR">IDR</option>
                                    <option value="USD">USD</option>
                                    <option value="KRW">KRW</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Harga Satuan</b></label>
                            <div class="col-sm-9">
                                <input type="number" class="form-control" name="harga" id="harga" placeholder="Harga Satuan" required>
                            </div>
                        </div>
                        <div class="form-group row" id="id_ppn">
                            <label class="col-sm-3 col-form-label"><b>PPN</b></label>
                            <div class="col-sm-9">
                              <div class="row">
                                <div class="col-sm-3">
                                  <input type="radio" name="ppn" id="ppn1" value="yes">
                                  <label>Ya</label>
                                </div>
                                <div class="col-sm-3">
                                  <input type="radio" name="ppn" id="ppn2" value="no">
                                  <label>Tidak</label>
                                </div>                    
                              </div>
                            </div>
                        </div>
                        <div class="form-group row" id="id_pph">
                            <label class="col-sm-3 col-form-label"><b>PPh</b></label>
                            <div class="col-sm-9">
                              <div class="row">
                                <div class="col-sm-3">
                                  <input type="radio" name="pph" id="pph1" value="yes">
                                  <label>Ya</label>
                                </div>
                                <div class="col-sm-3">
                                  <input type="radio" name="pph" id="pph2" value="no">
                                  <label>Tidak</label>
                                </div> 
                              </div> 
                            </div>
                        </div>
                        <input type="hidden" name="ip" id="ip" value="<?php echo $_SERVER['REMOTE_ADDR'];?>">                      
                      <div class="form-group mb-3">
                        <button class="btn mb-2 btn-info btn-sm" style="float:right;" id="tambah_barang_rental">Tambah Barang</button>
                      </div>
                    </div>
                  </div>
                <table class="table table-bordered table-hover mb-0" cellspacing="0" width="100%">
                    <thead class="thead-dark" style="text-align: center;">
                        <tr>
                        <th>Nama Barang</th>
                        <th>Total Barang</th>
                        <th>Kurs</th>
                        <th>Total Harga</th>
                        <th>PPN</th>
                        <th>PPh</th>
                        <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="tampil_data_rental">
                    </tbody>
                </table>
                <div class="row">
                  <div class="col-md-12">
                    <br><button type="button" class="btn mb-2 btn-danger btn-sm" style="float:right;" id="btn_proses_rental">Simpan Data</button>
                  </div>
                  </div>                
                </div>                
              </div> <!-- / .card -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">

      $("#kurs").change(function(){
            if($("#kurs").val() == 'USD' || $("#kurs").val() == 'KRW'){
              $("#id_ppn").hide();
              $("#id_pph").hide();
            }else{
              $("#id_ppn").show();
              $("#id_pph").show();
            }
      });

      $('.drgpicker').daterangepicker(
      {
        singleDatePicker: true,
        timePicker: false,
        showDropdowns: true,
        locale:
        {
          format: 'YYYY-MM-DD'
        }
      });
      $('.time-input').timepicker(
      {
        'scrollDefault': 'now',
        'zindex': '9999' /* fix modal open */
      });

      $('.select2').select2(
      {
        theme: 'bootstrap4',
      });

      $('#id_supplier').change(function(){
        $.ajax({
          url:"<?php echo site_url('c_supplier/cek_supplier/')?>"+$('#id_supplier').val(),
          success : function(o) {
            console.log(o)         
              if(o.status=='ok'){
                var data = o.data
                $('#id_supplier_2').val(data.id_supplier);
                $('#alamat_supplier').val(data.alamat_supplier);
              }else{
                alert(o.msg);
                location.reload();              
              }
          },
          error : function(data) {
          // do something
          console.log(data)
        }
        });
      });

      $("#id_jenis_barang").change(function(){
          var value=$(this).val();
          $.ajax({
              data:{id:value},
              success: function(respond){
                  console.log(value);
                  $("#id_barang").html(respond);
              }
          })
      });

      $.ajaxSetup({
          type: "POST",
          url: "<?php echo base_url('index.php/c_aset/cari_barang');?>",
          cache: false,
      });

      $('#tambah_barang_rental').on('click',function(){
        var yes = document.getElementById("ppn1").checked;
        var no = document.getElementById("ppn2").checked;
        var ppnYes = $('#ppn1').val();
        var ppnNo = $('#ppn2').val();
        var ppn;
        if(yes == true){
          ppn = ppnYes;
        }else{
          ppn = ppnNo;
        }

        var yes = document.getElementById("pph1").checked;
        var no = document.getElementById("pph2").checked;
        var pphYes = $('#pph1').val();
        var pphNo = $('#pph2').val();
        var pph;
        if(yes == true){
          pph = pphYes;
        }else{
          pph = pphNo;
        }

        var no_rental = $('#no_rental').val();
        var id_barang = $('#id_barang').val();
        var id_supplier = $('#id_supplier').val();
        var jumlah = $('#jumlah').val();
        var kurs = $('#kurs').val();
        var harga = $('#harga').val();
        var ip = $('#ip').val();
        $.ajax({
            type : "POST",
            url  : "<?php echo base_url('index.php/c_aset/tambah_barang_rental')?>",
            dataType : "JSON",
            data : {no_rental:no_rental,id_barang:id_barang,id_supplier:id_supplier,jumlah:jumlah,kurs:kurs,ppn:ppn,pph:pph,harga:harga,ip:ip},
            success : function(data){
                console.log(data)
                if(data.status=='ok'){
                    tampil_data_rental();
                }else{
                    alert(data.msg)
                }
            },
            error : function(data){
                console.log(data)
            }
        });
      });

      tampil_data_rental();
      function tampil_data_rental(){
        $.ajax({
          type : 'ajax',
          url  : '<?php echo base_url()?>index.php/c_aset/datatabel_rental',
          async : false,
          dataType : 'json',
          success : function(data){
            var html = '';
            var i;
            for(i=0; i<data.length; i++){
              html +='<tr>'+
                        '<td>'+data[i].nama_model+'</td>'+
                        '<td style="text-align:center;">'+data[i].jumlah+'</td>'+
                        '<td style="text-align:center;">'+data[i].kurs+'</td>'+
                        '<td style="text-align:center;">'+data[i].harga+'</td>'+
                        '<td style="text-align:center;">'+data[i].ppn+'</td>'+
                        '<td style="text-align:center;">'+data[i].pph+'</td>'+
                        '<td style="text-align:center;">'+
                          '<a href="javascript:;" class="btn mb-1 btn-danger btn-sm hapus_barang" no_rental="'+data[i].no_po+'" id_barang="'+data[i].id_barang+'"><span class="fe fe-trash fe-16"></span></a>'+
                        '</td>'+
                      '</tr>';
            }
            $('#tampil_data_rental').html(html);
          }
        });
      }

      $('#tampil_data_rental').on('click','.hapus_barang',function(){
        var no_rental = $(this).attr('no_rental');
        var id_barang = $(this).attr('id_barang');
        $('#ModalHapus').modal('show');
        $('[name="no_rental"]').val(no_rental);
        $('[name="id_barang"]').val(id_barang);
      });

      function btn_hapus_rental(){
        $.ajax({
            url : "<?php echo base_url('index.php/c_aset/hapus_barang_rental');?>",
            type: "POST",
            data: $('#form_hapus').serialize(),
            dataType: "JSON",
            success: function(data){     
              $('#ModalHapus').modal('hide');
              tampil_data_rental();
            }
        });
      }

      $('#btn_proses_rental').on('click',function(){
        var no_rental = $('#no_rental').val();
        var id_supplier = $('#id_supplier_2').val();
        var id_jenis_barang = $('#id_jenis_barang').val();
        var tanggal_rental =  $('#tanggal_rental').val();
        var no_surat_jalan =  $('#no_surat_jalan').val();
        if(no_rental == "" || id_supplier == "" || id_jenis_barang == ""){
          alert("Data belum lengkap");
        }else{
          $('#ModalSimpan').modal('show');
          $('[name="no_rental"]').val(no_rental);
          $('[name="tanggal_rental"]').val(tanggal_rental);
          $('[name="no_surat_jalan"]').val(no_surat_jalan);
        }
      });
      
      function btn_simpan_rental(){
        var ip = $('#ip_proses').val();
        var tanggal_po = $('#tanggal_rental_proses').val();
        var no_rental = $('#no_rental_proses').val();
        var no_surat_jalan = $('#no_surat_jalan_proses').val();
        var jenis_aset = $('#jenis_aset_proses').val();
        $.ajax({
          url : "<?php echo base_url('index.php/c_aset/simpan_transaksi_rental');?>",
          type : "POST",
          dataType : "JSON",
          data: $('#form_simpan_rental').serialize(),
          success : function(data){
            $('#ModalSimpan').modal('hide');
            update_tb_bantu(data.id_trs,no_rental,ip);
            generate_data_rental(no_rental,jenis_aset,tanggal_po,ip);
            hapus_tb_bantu_rental(data.id_trs,no_rental,ip);
            window.location.reload();
          }
        });
      }

      function update_tb_bantu(id,no_rental,ip){
        $.ajax({
          type : 'ajax',
          url  : '<?php echo base_url()?>index.php/c_aset/update_tb_bantu_rental/'+id+'/'+no_rental+'/'+ip,
          async : false,
          dataType : 'JSON',
          success : function(data){

          }
        });
      }

      function generate_data_rental(no_rental,jenis_aset,tanggal_po,ip){
        $.ajax({
          type : 'ajax',
          url  : '<?php echo base_url()?>index.php/c_aset/proses_simpan_rental/'+no_rental+'/'+jenis_aset+'/'+tanggal_po+'/'+ip,
          async: false,
          dataType : 'JSON',
          success : function(data){
          }
        });
      }

      function hapus_tb_bantu_rental(id,no_rental,ip){
        $.ajax({
          type : 'ajax',
          url  : '<?php echo base_url()?>index.php/c_aset/hapus_tb_bantu_rental/'+id+'/'+no_rental+'/'+ip,
          async: false,
          dataType : 'JSON',
          success : function(data){
          }
        });
      }
    
    </script>
  </body>
  
  <div class="modal fade" id="ModalHapus" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel">Hapus Barang</h5>
      </div>
      <div class="modal-body">
        <form id="form_hapus">
          Apakah anda yakin ingin menghapus barang ini ?
          <input type="hidden" name="no_rental" id="no_rental_1">  
          <input type="hidden" name="id_barang" id="id_barang_1">
        </form>
      </div>      
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" class="btn mb-2 btn-danger" onclick="btn_hapus_rental()">Hapus</button>
    </div>
    </div>
  </div>
</div>

<div class="modal fade" id="ModalSimpan" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel">Konfirmasi Barang Rental</h5>
      </div>
      
      <div class="modal-body">      
          Apakah anda yakin ingin menyimpan data ini ? 
          <form id="form_simpan_rental">         
          <input type="hidden" name="no_rental" id="no_rental_proses">
          <input type="hidden" name="tanggal_rental" id="tanggal_rental_proses">
          <input type="hidden" name="no_surat_jalan" id="no_surat_jalan_proses">
          <input type="hidden" name="jenis_aset" id="jenis_aset_proses" value="1">
          <input type="hidden" name="ip" id="ip_proses" value="<?php echo $_SERVER['REMOTE_ADDR'];?>">
          </form> 
      </div>      
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" class="btn mb-2 btn-danger" onclick="btn_simpan_rental()">Simpan</button>
      </div>
    </div>
  </div>
</div>
</html>

