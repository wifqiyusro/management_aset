<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Master Proyek</h2>
              <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                  <?php if($this->session->userdata('level_a')=='1' || $this->session->userdata('level_a')=='2'){?>
                  <button type="button" class="btn mb-2 btn-success" onclick="add_proyek()">Tambah proyek</button>
                  <?php } ?>
                  <div class="card shadow">
                    <div class="card-body">
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="table_proyek" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th>No</th>
                            <th>Nama Proyek</th>
                            <th>No PO</th>
                            <th>Nama Supplier</th>
                            <th>Tanggal Proyek</th>                            
                            <th>Kurs</th>
                            <th>Biaya Proyek</th>
                            <th>Keterangan</th>
                            <th>Created at</th>
                            <th>Updated at</th>
                            <th>Aksi</th>
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        $("#konfirm_po").change(function(){
            if($("#konfirm_po").val() == 'Y'){
              $("#no_po").show();
            }else{
              $("#no_po").hide();
            }
        });
        
        table = $('#table_proyek').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_proyek/get_master_po')?>",
            "type": "POST"
          },
        });
      });

      function reload_table(){
        table.ajax.reload(null,false);
      }

      $("#no_po").show();

      //JS add user
    function add_proyek(){
        save_method = 'add_proyek';
        $('#form_proyek')[0].reset();
        $('.select2').select2({
          placeholder:'--- Pilih Salah Satu ---',
          theme: 'bootstrap4'
        });
        $('#id_supplier').val(null).trigger('change');
        $('#kurs').val(null).trigger('change');
        $('.form-group').removeClass('has-error'); // clear error class
        $('#proyek_form').modal('show'); // show bootstrap modal
        $('#konfirm_po').html('<option value="Y" selected>Ada PO</option> <option value="N">Tidak ada PO</option>');
        $('.modal-title').text('Form Tambah Master Proyek'); // Set Title to Bootstrap modal title
    }

    function edit_proyek(id_proyek){
        save_method = 'edit_proyek';
        $('#form_proyek')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class
        $.ajax({
            url : "<?php echo site_url('c_proyek/edit_proyek_')?>/"+id_proyek,
            type: "GET",
            dataType: "JSON",
            success: function(data){     
                $('[name="id_proyek"]').val(data.id_proyek);
                $('[name="nama_proyek"]').val(data.nama_proyek);
                if(data.no_po == null || data.no_po == ''){
                  $('#konfirm_po').html('<option value="Y">Ada PO</option> <option value="N" selected>Tidak ada PO</option>');
                  $("#no_po").hide();
                  $('[name="no_po"]').val('');
                }else{
                  $('#konfirm_po').html('<option value="Y" selected>Ada PO</option> <option value="N">Tidak ada PO</option>');
                  $("#no_po").show();
                  $('[name="no_po"]').val(data.no_po);
                }
                $('#id_supplier').val(data.id_supplier).select2({theme: 'bootstrap4'});
                $('[name="nama_supplier"]').val(data.nama_supplier);
                $('[name="tanggal"]').val(data.tanggal);
                $('#kurs').val(data.kurs).select2({theme: 'bootstrap4'});
                $('[name="total_harga"]').val(data.total_harga);
                $('[name="remark"]').val(data.remark);                 
                $('#proyek_form').modal('show'); // show bootstrap modal when complete loaded
                $('.modal-title').text('Form Edit Master Proyek'); // Set title to Bootstrap modal title     
            },
            error: function (jqXHR, textStatus, errorThrown){
                alert('Gagal menampilkan data master proyek');
            }
        });
    }

    //JS save user
    function saveproyek(){
        $('#saveproyek').text('saving...'); //change button text
        $('#saveproyek').attr('disabled',true); //set button disable 
        var url;
     
        if(save_method == 'add_proyek') {
            url = "<?php echo site_url('c_proyek/add_proyek_process')?>";
        } else {
            url = "<?php echo site_url('c_proyek/update_proyek_process')?>";
        }
     
        // ajax adding data to database
        $.ajax({
            url : url,
            type: "POST",
            data: $('#form_proyek').serialize(),
            dataType: "JSON",
            success: function(data){     
                if(data.status) //if success close modal and reload ajax table
                {
                    $('#proyek_form').modal('hide');
                    $('#form_proyek')[0].reset();
                    reload_table();
                }     
                $('#saveproyek').text('simpan'); //change button text
                $('#saveproyek').attr('disabled',false); //set button enable
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Gagal edit / tambah data master proyek');
                $('#saveproyek').text('simpan'); //change button text
                $('#saveproyek').attr('disabled',false); //set button enable
            }
        });
    }
    </script>
  </body>
</html>

<div class="modal fade" id="proyek_form" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel"></h5>
      </div>
      <div class="modal-body">
        <form action="#" id="form_proyek">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label class="col-form-label"><b>Nama Proyek</b></label>
              <input type="text" class="form-control" name="nama_proyek" placeholder="Nama Proyek" required>
              <input type="hidden" name="id_proyek" id="id_proyek">
            </div>
            <div class="form-group">
              <label class="col-form-label"><b>Konfirmasi PO</b></label>
              <select class="form-control select2" name="konfirm_po" id="konfirm_po">
              </select>
            </div>
            <div class="form-group" id="no_po">
              <label class="col-form-label"><b>No PO</b></label>
              <input type="text" class="form-control" name="no_po" placeholder="No PO">
            </div>
            <div class="form-group">
              <label class="col-form-label"><b>Nama Supplier</b></label>
              <select class="form-control select2" name="id_supplier" id="id_supplier">
                  <option value=""></option>
                  <?php
                      foreach($supplier as $data){
                          echo '<option value='.$data->id_supplier.'>'.$data->nama_supplier.'</option>';
                      }
                  ?>
              </select>
            </div>
            <div class="form-group">
              <label class="col-form-label"><b>Tanggal Proyek</b></label>
              <input type="date" class="form-control" name="tanggal" placeholder="Tanggal Proyek" required>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label class="col-form-label"><b>Kurs</b></label>
              <select class="form-control select2" name="kurs" id="kurs">
                  <option value=""></option>
                  <option value="IDR">IDR (Rp)</option>
                  <option value="USD">USD ($)</option>
                  <option value="KRW">KRW (₩)</option>
              </select>
            </div>
            <div class="form-group">
              <label class="col-form-label"><b>Biaya Proyek</b></label>
              <input type="number" class="form-control" name="total_harga" placeholder="Biaya Proyek" required>
            </div>
            <div class="form-group">
              <label class="col-form-label"><b>Keterangan</b></label>
              <textarea class="form-control" name="remark" placeholder="Keterangan" required></textarea>
            </div>
          </div>
        </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" id="saveproyek" onclick="saveproyek()" class="btn mb-2 btn-primary">Simpan</button>
      </div>
    </div>
  </div>
</div>