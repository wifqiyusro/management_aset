      <main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Input Barang Projek</h2>
              <div class="card shadow mb-4">
                <?php if($this->session->flashdata('status') != null){
                  echo '<div class="alert alert-'.$this->session->flashdata('status').'" role="alert">
                        <span class="fe fe-alert-circle fe-16 mr-2"></span>'.$this->session->flashdata('msg').'</div>';
                }?>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Projek</b></label>
                        <div class="col-sm-9">
                        <select class="form-control select2" name="id_proyek" id="id_proyek">
                          <option value="">-- Pilih Salah Satu --</option>
                          <?php foreach($proyek as $data){
                              echo"<option value=".$data->id_proyek.">".$data->nama_proyek."</option>";
                          }?>
                        </select>
                        </div>
                      </div>
                      <input type="hidden" name="id_proyek_2" id="id_proyek_2">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Tanggal Projek</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="tanggal" id="tanggal" placeholder="Tanggal projek" readonly>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Supplier</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="nama_supplier" id="nama_supplier" placeholder="Nama supplier" readonly>
                            <input type="hidden" name="id_supplier" id="id_supplier">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Kurs</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="kurs" id="kurs" placeholder="Kurs" readonly>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Total Harga</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="total_harga" id="total_harga" placeholder="Total harga" readonly>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label"><b>Keterangan</b></label>
                        <div class="col-sm-9">
                        <input type="text" class="form-control" name="remark" id="remark" placeholder="Keterangan" readonly>
                        </div>
                      </div>
                    </div> <!-- /.col -->
                    <div class="col-md-6">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Jenis Barang</b></label>
                            <div class="col-sm-9">
                                <select class="form-control select2" name="id_jenis_barang" id="id_jenis_barang">
                                    <option value="0">-- Pilih Salah Satu --</option>
                                    <?php foreach($jenis_barang as $data){
                                        echo"<option value=".$data->id_jenis_barang.">".$data->nama_jenis_barang."</option>";
                                    }?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Barang</b></label>
                            <div class="col-sm-9">
                                <select class="form-control select2" name="id_barang" id="id_barang">
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label"><b>Kode EPTE</b></label>
                          <div class="col-sm-5">
                            <select class="form-control select2" style="width: 100%" name="epte" id="epte">
                              <option value="">-- Pilih --</option>
                              <option value="Y">Yes</option>
                              <option value="N">No</option>
                            </select>
                          </div>
                          <div class="col-sm-4" id="form_epte">
                              <input type="text" class="form-control"  name="epte_code" id="epte_code" placeholder="Kode Epte">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label"><b>Kode FA</b></label>
                          <div class="col-sm-5">
                            <select class="form-control select2" style="width: 100%" name="fa" id="fa">
                              <option value="">-- Pilih --</option>
                              <option value="Y">Yes</option>
                              <option value="N">No</option>
                            </select>
                          </div>
                          <div class="col-sm-4" id="form_fa">
                              <input type="text" class="form-control" name="fa_code" id="fa_code" placeholder="Kode FA">
                          </div>
                        </div>                      
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Jumlah</b></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="jumlah" id="jumlah" placeholder="Total barang" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Alokasi</b></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="alokasi" id="alokasi" placeholder="Alokasi" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label"><b>Remark</b></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan" required>
                            </div>
                        </div>
                        <input type="hidden" name="ip" id="ip" value="<?php echo $_SERVER['REMOTE_ADDR'];?>">                      
                      <div class="form-group mb-3">
                        <button class="btn mb-2 btn-info btn-sm" style="float:right;" id="tambah_barang_proyek">Tambah Barang</button>
                      </div>
                    </div>
                  </div>
                <table class="table table-bordered table-hover mb-0" cellspacing="0" width="100%">
                    <thead class="thead-dark" style="text-align: center;">
                        <tr>
                        <th>Jenis Barang</th>
                        <th>Nama Barang</th>
                        <th>Kode EPTE</th>
                        <th>Kode FA</th>
                        <th>Total Barang</th>
                        <th>Alokasi</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="tampil_data_proyek">
                    </tbody>
                </table>
                <div class="row">
                  <div class="col-md-12">
                    <br><button type="button" class="btn mb-2 btn-danger btn-sm" style="float:right;" id="btn_proses_proyek">Simpan Data</button>
                  </div>
                  </div>                
                </div>                
              </div> <!-- / .card -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      $('.drgpicker').daterangepicker(
      {
        singleDatePicker: true,
        timePicker: false,
        showDropdowns: true,
        locale:
        {
          format: 'YYYY-MM-DD'
        }
      });
      $('.time-input').timepicker(
      {
        'scrollDefault': 'now',
        'zindex': '9999' /* fix modal open */
      });

      $("#form_epte").hide();
      $("#form_fa").hide();

      $("#epte").change(function(){
        if($("#epte").val() == 'Y'){
          $("#form_epte").show();
        }else{
          $("#epte_code").val("-");
          $("#form_epte").hide();
        }
      });

      $("#fa").change(function(){
        if($("#fa").val() == 'Y'){
          $("#form_fa").show();
        }else{
          $("#fa_code").val("-");
          $("#form_fa").hide();
        }
      });

      $('.select2').select2(
      {
        theme: 'bootstrap4',
      });

      $('#id_proyek').change(function(){
        $.ajax({
          url:"<?php echo site_url('c_aset/cek_proyek/')?>"+$('#id_proyek').val(),
          success : function(o) {
            console.log(o)         
              if(o.status=='ok'){
                var data = o.data
                $('#id_proyek_2').val(data.id_proyek);
                $('#tanggal').val(data.tanggal);
                $('#id_supplier').val(data.id_supplier);
                $('#nama_supplier').val(data.nama_supplier);
                $('#kurs').val(data.kurs);
                $('#total_harga').val(data.total_harga);
                $('#remark').val(data.remark);
              }else{
                alert(o.msg);
                location.reload();              
              }
          },
          error : function(data) {
          // do something
          console.log(data)
        }
        });
      });

      $("#id_jenis_barang").change(function(){
          var value=$(this).val();
          $.ajax({
              data:{id:value},
              success: function(respond){
                  console.log(value);
                  $("#id_barang").html(respond);
              }
          })
      });

      $.ajaxSetup({
          type: "POST",
          url: "<?php echo base_url('index.php/c_aset/cari_barang');?>",
          cache: false,
      });

      $('#tambah_barang_proyek').on('click',function(){
        var id_proyek = $('#id_proyek').val();
        var id_jenis_barang = $('id_jenis_barang').val();
        var id_barang = $('#id_barang').val();
        var epte_code = $('#epte_code').val();
        var fa_code = $('#fa_code').val();
        var id_supplier = $('#id_supplier').val();
        var jumlah = $('#jumlah').val();
        var alokasi = $('#alokasi').val();
        var keterangan = $('#keterangan').val();
        var ip = $('#ip').val();
        if(id_proyek == "" || id_jenis_barang == "" || id_barang == "" || jumlah == ""){
          alert("Data belum lengkap !");
        }else{
          $.ajax({
              type : "POST",
              url  : "<?php echo base_url('index.php/c_aset/tambah_barang_proyek')?>",
              dataType : "JSON",
              data : {id_barang:id_barang,epte_code:epte_code,fa_code:fa_code,id_supplier:id_supplier,jumlah:jumlah,alokasi:alokasi,keterangan:keterangan,ip:ip},
              success : function(data){
                  console.log(data)
                  if(data.status=='ok'){
                      tampil_data_proyek();
                  }else{
                      alert(data.msg)
                  }
              },
              error : function(data){
                  console.log(data)
              }
          });
        }
      });

      tampil_data_proyek();
      function tampil_data_proyek(){
        $.ajax({
          type : 'ajax',
          url  : '<?php echo base_url()?>index.php/c_aset/datatabel_proyek',
          async : false,
          dataType : 'json',
          success : function(data){
            var html = '';
            var i;
            for(i=0; i<data.length; i++){
              html +='<tr>'+
                        '<td>'+data[i].nama_jenis_barang+'</td>'+
                        '<td>'+data[i].nama_model+'</td>'+
                        '<td style="text-align:center;">'+data[i].epte_code+'</td>'+
                        '<td style="text-align:center;">'+data[i].FA_code+'</td>'+
                        '<td style="text-align:center;">'+data[i].jumlah+'</td>'+
                        '<td style="text-align:center;">'+data[i].alokasi+'</td>'+
                        '<td style="text-align:center;">'+data[i].keterangan+'</td>'+
                        '<td style="text-align:center;">'+
                          '<a href="javascript:;" class="btn mb-1 btn-danger btn-sm hapus_barang" id_barang="'+data[i].id_barang+'" kode_epte="'+data[i].epte_code+'" kode_fa="'+data[i].FA_code+'" alokasi="'+data[i].alokasi+'"><span class="fe fe-trash fe-16"></span></a>'+
                        '</td>'+
                      '</tr>';
            }
            $('#tampil_data_proyek').html(html);
          }
        });
      }

      $('#tampil_data_proyek').on('click','.hapus_barang',function(){
        var id_barang = $(this).attr('id_barang');
        var kode_epte = $(this).attr('kode_epte');
        var kode_fa = $(this).attr('kode_fa');
        var alokasi = $(this).attr('alokasi');
        $('#ModalHapus').modal('show');
        $('[name="id_barang"]').val(id_barang);
        $('[name="alokasi"]').val(alokasi);
        $('[name="kode_epte"]').val(kode_epte);
        $('[name="kode_fa"]').val(kode_fa);
      });

      function btn_hapus_proyek(){
        $.ajax({
            url : "<?php echo base_url('index.php/c_aset/hapus_barang_proyek');?>",
            type: "POST",
            data: $('#form_hapus').serialize(),
            dataType: "JSON",
            success: function(data){     
              $('#ModalHapus').modal('hide');
              tampil_data_proyek();
            }
        });
      }

      $('#btn_proses_proyek').on('click',function(){
        var id_proyek = $('#id_proyek_2').val();
        if(id_proyek == ""){
          alert("Projek belum dipilih");
        }else{
          $('#ModalSimpan').modal('show');
          $('[name="id_proyek_proses"]').val(id_proyek);
        }
      });

      function btn_simpan_proyek(){
        var id_proyek = $('#id_proyek_proses').val();
        var ip = "<?php echo $_SERVER['REMOTE_ADDR'];?>"
        $.ajax({
            url : "<?php echo base_url('index.php/c_proyek/status_ok');?>",
            type: "POST",
            dataType: "JSON",
            success: function(data){     
              $('#ModalSimpan').modal('hide');
              generate_data_proyek(id_proyek,ip);
              hapus_tb_bantu_proyek(ip);
              window.location.reload();
            }
        });
      }

      function generate_data_proyek(id_proyek,ip){
        $.ajax({
          type : 'ajax',
          url  : '<?php echo base_url()?>index.php/c_proyek/proses_simpan/'+id_proyek+'/'+ip,
          async: false,
          dataType : 'JSON',
          success : function(data){
          }
        });
      }

      function hapus_tb_bantu_proyek(ip){
        $.ajax({
          type : 'ajax',
          url  : '<?php echo base_url()?>index.php/c_proyek/hapus_tb_bantu_proyek/'+ip,
          async: false,
          dataType : 'JSON',
          success : function(data){
          }
        });
      }
    
    </script>
  </body>
  
  <div class="modal fade" id="ModalHapus" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel">Hapus Barang</h5>
      </div>
      <div class="modal-body">
        <form id="form_hapus">
          Apakah anda yakin ingin menghapus barang ini ?
          <input type="hidden" name="id_barang" id="id_barang_1">  
          <input type="hidden" name="alokasi" id="alokasi_1">
          <input type="hidden" name="kode_epte" id="kode_epte_1">  
          <input type="hidden" name="kode_fa" id="kode_fa_1">
        </form>
      </div>      
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" class="btn mb-2 btn-danger" onclick="btn_hapus_proyek()">Hapus</button>
    </div>
    </div>
  </div>
</div>

<div class="modal fade" id="ModalSimpan" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel">Konfirmasi Barang Projek</h5>
      </div>
      <div class="modal-body">       
          Apakah anda yakin ingin menyimpan data ini ?
          <form id="btn_simpan_proyek">
          <input type="hidden" name="id_proyek_proses" id="id_proyek_proses"> 
          <input type="hidden" name="ip" id="ip" value="<?php echo $_SERVER['REMOTE_ADDR'];?>">
          </form> 
      </div>      
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" class="btn mb-2 btn-danger" onclick="btn_simpan_proyek()">Simpan</button>
      </div>
   
    </div>
  </div>
</div>
</html>

