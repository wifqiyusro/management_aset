<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Master Barang</h2>
              <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                  <?php if($this->session->userdata('level_a')=='1' || $this->session->userdata('level_a')=='2'){?>
                  <button type="button" class="btn mb-2 btn-success" onclick="add_barang()">Tambah Barang</button>
                  <?php } ?>
                  <div class="card shadow">
                    <div class="card-body">
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="table_barang" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th>No</th>
                            <!-- <th>Kode EPTE</th> -->
                            <th>Nama Model</th>
                            <th>Jenis Barang</th>
                            <th>Label Jenis Barang</th>
                            <th>Created at</th>
                            <th>Updated at</th>
                            <th>Aksi</th>
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        table = $('#table_barang').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_barang/get_master_barang')?>",
            "type": "POST"
          },
        });
      });
 
      function reload_table(){
        table.ajax.reload(null,false);
      }

      //JS add user
    function add_barang(){
        save_method = 'add_barang';
        $('#form_barang')[0].reset();
        $('.select2').select2({
          placeholder:'--- Pilih Jenis Barang ---',
          theme: 'bootstrap4'
        });
        $('#id_jenis_barang').val(null).trigger('change');
        $('.form-group').removeClass('has-error'); // clear error class
        $('#barang_form').modal('show'); // show bootstrap modal
        $('.modal-title').text('Form Tambah Master Barang'); // Set Title to Bootstrap modal title
    }

    function edit_barang(id_barang){
        save_method = 'edit_barang';
        $('#form_barang')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class

        $.ajax({
            url : "<?php echo site_url('c_barang/edit_barang_')?>/"+id_barang,
            type: "GET",
            dataType: "JSON",
            success: function(data){     
                $('[name="id_barang"]').val(data.id_barang);
                // $('[name="kode_sap"]').val(data.kode_sap);
                $('[name="nama_model"]').val(data.nama_model);
                $('#id_jenis_barang').val(data.id_jenis_barang).select2({theme:'bootstrap4'});
                $('[name="nama_jenis_barang"]').val(data.nama_jenis_barang);             
                $('#barang_form').modal('show'); // show bootstrap modal when complete loaded
                $('.modal-title').text('Form Edit Master Barang'); // Set title to Bootstrap modal title     
            },
            error: function (jqXHR, textStatus, errorThrown){
                alert('Gagal menampilkan data master barang');
            }
        });
    }

    //JS save user
    function savebarang(){
        $('#savebarang').text('saving...'); //change button text
        $('#savebarang').attr('disabled',true); //set button disable 
        var url;
     
        if(save_method == 'add_barang') {
            url = "<?php echo site_url('c_barang/add_barang_process')?>";
        } else {
            url = "<?php echo site_url('c_barang/update_barang_process')?>";
        }
     
        // ajax adding data to database
        $.ajax({
            url : url,
            type: "POST",
            data: $('#form_barang').serialize(),
            dataType: "JSON",
            success: function(data){     
                if(data.status) //if success close modal and reload ajax table
                {
                    $('#barang_form').modal('hide');
                    reload_table();
                }     
                $('#savebarang').text('simpan'); //change button text
                $('#savebarang').attr('disabled',false); //set button enable
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Gagal edit / tambah data master barang');
                $('#savebarang').text('simpan'); //change button text
                $('#savebarang').attr('disabled',false); //set button enable
            }
        });
    }
    </script>
  </body>
</html>

<div class="modal fade" id="barang_form" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel"></h5>
      </div>
      <div class="modal-body">
        <form action="#" id="form_barang">
          <!-- <div class="form-group">
            <label class="col-form-label"><b>Kode Material</b></label>
            <input type="text" class="form-control" name="kode_sap" placeholder="Kode Material">
          </div> -->
          <div class="form-group">
            <label class="col-form-label"><b>Nama Model</b></label>
            <input type="text" class="form-control" name="nama_model" placeholder="Nama Model" required>
            <input type="hidden" name="id_barang" id="id_barang">
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Jenis Barang</b></label>
            <select class="form-control select2" name="id_jenis_barang" id="id_jenis_barang">
                <option value=""></option>
                <?php
                    foreach($jenis_barang as $data){
                        echo '<option value='.$data->id_jenis_barang.'>'.$data->nama_jenis_barang.'</option>';
                    }
                ?>
            </select>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" id="savebarang" onclick="savebarang()" class="btn mb-2 btn-primary">Simpan</button>
      </div>
    </div>
  </div>
</div>