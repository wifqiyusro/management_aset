<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Master Surat</h2>
              <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                  <?php if($this->session->userdata('level_a')=='1' || $this->session->userdata('level_a')=='2'){?>
                    <a href="<?php echo base_url();?>index.php/c_surat/add_surat" class="btn mb-2 btn-success">Tambah Surat</a>
                  <?php }
                     if($this->session->flashdata('status') != null){
                      echo '<div class="alert alert-'.$this->session->flashdata('status').'" role="alert">
                      <span class="fe fe-alert-circle fe-16 mr-2"></span>'.$this->session->flashdata('msg').'</div>';}
                  ?>
                  <div class="card shadow">
                    <div class="card-body">
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="table_surat" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th>No</th>
                            <th>Nama User</th>
                            <th>Departemen</th>
                            <th>Detail</th>
                            <th>Posisi</th>
                            <th>Kategori</th>
                            <th>Deskripsi</th>
                            <th>Tgl Masuk</th>
                            <th>Tgl Approve</th>
                            <th>Status</th>
                            <th>File</th>
                            <th>Aksi</th>
                          </tr>
                        </thead>
                        <tbody>                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap-datepicker.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        table = $('#table_surat').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_surat/get_master_surat')?>",
            "type": "POST"
          },
        });
      });

      $('.date').datepicker({
        format: 'yyyy-mm-dd'
      });

      $('.select2').select2(
      {
        theme: 'bootstrap4',
      });

      function reload_table(){
        table.ajax.reload(null,false);
      }

      // function preview_surat(file_surat){
      //   $('#preview_surat').modal('show');
      //   $('.modal-title').text('Preview Surat');
      //   $('.modal-body').html('<embed type="application/pdf" src="<?php echo base_url();?>assets/file_surat/'+file_surat+'" style="width: 100%" height="550"></embed>');
      // }

    </script>
  </body>
</html>
<!-- Modal Preview Surat -->
<!-- <div id="preview_surat" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel"></h5>
      </div>
      <div class="modal-body">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div> -->