      <main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Update Surat</h2>
              <div class="card shadow mb-4">
                <?php echo form_open_multipart('c_surat/update_surat_process');?>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group mb-3">
                        <label><b>Nama User</b></label>
                        <input type="text" class="form-control" name="nama_user" placeholder="Nama Pemohon" value="<?php echo $data->nama_user;?>">
                        <input type="hidden" name="id_surat" value="<?php echo $data->id_surat;?>">
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Departemen</b></label>
                        <select class="form-control select2" name="departemen" style="width: 100%" >
                            <option value="<?php echo $data->departemen;?>"><?php echo $data->nama_lokasi;?></option>
                          <?php
                            foreach($departemen as $dept){
                              echo "<option value=".$dept->id_lokasi.">".$dept->nama_lokasi."</option>";
                            }
                          ?>
                        </select>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Detail Departemen</b></label>
                        <input type="text" class="form-control" name="detail_dept" placeholder="Detail Departemen" value="<?php echo $data->detail_dept;?>">
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Posisi</b></label>
                        <select class="form-control select2" name="posisi_user" style="width: 100%">
                          <option value="<?php echo $data->posisi_user;?>"><?php echo $data->nama_posisi;?></option>
                          <?php foreach($posisi as $dt){
                            echo '<option value="'.$dt->id_posisi.'">'.$dt->nama_posisi.'</option>';
                          }?>
                        </select>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Kategori</b></label>
                        <select class="form-control select2" name="kategori_surat" style="width: 100%">
                          <option value="<?php echo $data->kategori_surat;?>"><?php echo $data->nama_kategori;?></option>
                          <?php foreach($kategori as $dt){
                            echo '<option value="'.$dt->id_kategori.'">'.$dt->nama_kategori.'</option>';
                          }?>
                        </select>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Deskripsi Surat</b></label>
                        <textarea class="form-control" name="deskripsi" placeholder="Deskripsi Surat"><?php echo $data->deskripsi;?></textarea>
                      </div>
                    </div> <!-- /.col -->
                    <div class="col-md-6">
                      <div class="form-group mb-3">
                        <label><b>Tanggal Masuk</b></label>
                        <input type="text" class="form-control date" name="tanggal_masuk" placeholder="Tanggal Masuk" value="<?php echo $data->tanggal_masuk;?>">
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Status</b></label>
                        <select class="form-control select2" name="status" id="status" style="width: 100%">
                          <?php
                            if($data->status == '0'){
                              echo '
                              <option value="'.$data->status.'">Open</option>
                              <option value="1">Pending</option>
                              <option value="2">Done</option>
                              <option value="3">Cancel / Reject</option>
                              ';
                            }elseif($data->status == '1'){
                              echo '
                              <option value="'.$data->status.'">Pending</option>
                              <option value="0">Open</option>
                              <option value="2">Done</option>
                              <option value="3">Cancel / Reject</option>
                              ';
                            }elseif($data->status == '2'){
                              echo '
                              <option value="'.$data->status.'">Done</option>
                              <option value="0">Open</option>
                              <option value="1">Pending</option>
                              <option value="3">Cancel / Reject</option>
                              ';
                            }else{
                              echo '
                              <option value="'.$data->status.'">Cancel / Reject</option>
                              <option value="0">Open</option>
                              <option value="1">Pending</option>
                              <option value="2">Done</option>
                              ';
                            }
                          ?>
                        </select>
                      </div>
                      <div class="form-group mb-3" id="tanggal_approve">
                        <label><b>Tanggal Approve</b></label>
                        <input type="text" class="form-control date" name="tanggal_approve" placeholder="Tanggal Approve" value="<?php echo $data->tanggal_approve;?>">
                      </div>
                      <div class="form-group mb-3" id="keterangan">
                        <label><b>Keterangan</b></label>
                        <textarea class="form-control" name="keterangan" placeholder="Keterangan"></textarea>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Upload Surat</b></label>
                        <input type="file" class="form-control" name="file_surat">
                        <font color="red">* File hanya berekstensi pdf</font>
                      </div>
                      <div class="form-group mb-3">
                        <button class="btn mb-2 btn-info btn-sm">Simpan</button>
                      </div>
                    </div>
                  </div>
                </div>
                <?php echo form_close();?>
              </div> <!-- / .card -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      
      $('.date').datepicker({
        format: 'yyyy-mm-dd'
      });

      $('.select2').select2(
      {
        theme: 'bootstrap4',
      });

      $('#keterangan').hide();
      $('#tanggal_approve').hide();

      $('#status').change(function(){
        if($('#status').val() == '1' || $('#status').val() == '3'){
            $('#keterangan').show();
            $('#tanggal_approve').hide();
        }else if($('#status').val() == '2'){
            $('#keterangan').hide();
            $('#tanggal_approve').show();
        }else{
            $('#keterangan').hide();
            $('#tanggal_approve').hide();
        }
      })
    </script>
  </body>
</html>