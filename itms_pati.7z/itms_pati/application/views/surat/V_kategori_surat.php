<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Master Kategori Surat</h2>
              <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                  <?php if($this->session->userdata('level_a')=='1' || $this->session->userdata('level_a')=='2'){?>
                  <button type="button" class="btn mb-2 btn-success" onclick="add_kategori()">Tambah Kategori</button>
                  <?php } ?>
                  <div class="card shadow">
                    <div class="card-body">
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="table_kategori" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th>No</th>
                            <th>Kode</th>
                            <th>Kategori Surat</th>
                            <th>Created at</th>
                            <th>Updated at</th>
                            <th>Aksi</th>
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        table = $('#table_kategori').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_surat/get_kategori_surat')?>",
            "type": "POST"
          },
        });
      });

      function reload_table(){
        table.ajax.reload(null,false);
      }

      //JS add user
    function add_kategori(){
        save_method = 'add_kategori';
        $('#form_kategori')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class
        $('#kategori_form').modal('show'); // show bootstrap modal
        $('.modal-title').text('Form Tambah Master Kategori Surat'); // Set Title to Bootstrap modal title
    }

    function edit_kategori(id_kategori){
        save_method = 'edit_kategori';
        $('#form_kategori')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class

        $.ajax({
            url : "<?php echo site_url('c_surat/edit_kategori_')?>/"+id_kategori,
            type: "GET",
            dataType: "JSON",
            success: function(data){     
                $('[name="id_kategori"]').val(data.id_kategori);
                $('[name="nama_kategori"]').val(data.nama_kategori);          
                $('#kategori_form').modal('show'); // show bootstrap modal when complete loaded
                $('.modal-title').text('Form Edit Master Kategori Surat'); // Set title to Bootstrap modal title     
            },
            error: function (jqXHR, textStatus, errorThrown){
                alert('Gagal menampilkan data master kategori surat');
            }
        });
    }

    //JS save user
    function savekategori(){
        $('#savekategori').text('saving...'); //change button text
        $('#savekategori').attr('disabled',true); //set button disable 
        var url;
     
        if(save_method == 'add_kategori') {
            url = "<?php echo site_url('c_surat/add_kategori_process')?>";
        } else {
            url = "<?php echo site_url('c_surat/update_kategori_process')?>";
        }
     
        // ajax adding data to database
        $.ajax({
            url : url,
            type: "POST",
            data: $('#form_kategori').serialize(),
            dataType: "JSON",
            success: function(data){     
                if(data.status) //if success close modal and reload ajax table
                {
                    $('#kategori_form').modal('hide');
                    reload_table();
                }     
                $('#savekategori').text('simpan'); //change button text
                $('#savekategori').attr('disabled',false); //set button enable
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Gagal edit / tambah data master kategori surat');
                $('#savekategori').text('simpan'); //change button text
                $('#savekategori').attr('disabled',false); //set button enable
            }
        });
    }
    </script>
  </body>
</html>

<div class="modal fade" id="kategori_form" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel"></h5>
      </div>
      <div class="modal-body">
        <form action="#" id="form_kategori">
          <div class="form-group">
            <label class="col-form-label"><b>Nama kategori</b></label>
            <input type="text" class="form-control" name="nama_kategori" placeholder="Nama kategori" required>
            <input type="hidden" name="id_kategori" id="id_kategori">
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" id="savekategori" onclick="savekategori()" class="btn mb-2 btn-primary">Simpan</button>
      </div>
    </div>
  </div>
</div>