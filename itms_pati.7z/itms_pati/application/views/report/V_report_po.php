<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Report PO Aset</h2>
              <div class="row my-4">
                <div class="col-md-12">
                  <div class="card shadow">
                    <div class="card-body">
                      <div class="col-md-5">
                        <form class="form-horizontal" id="filter" method="post">
                        <div class="form-group row">
                          <label for="inputEmail3" class="col-sm-4 col-form-label"><b>No PO</b></label>
                          <div class="col-sm-8">
                                <select class="form-control select2" name="id_transkasi" id="id_transaksi">
                                    <option value=""></option>
                                    <?php foreach($po as $data){?>
                                    <option value="<?php echo $data->id_transaksi;?>'"><?php echo $data->no_po;?></option>
                                    <?php } ?>
                                </select>
                          </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-8 ml-sm-auto">
                                <button class="btn mb-2 btn-info btn-sm" type="button" id="btn_filter">Filter</button>
                                <button class="btn mb-2 btn-success btn-sm" type="button" onclick="getExcel()">Export</button>
                                <button class="btn mb-2 btn-secondary btn-sm" type="button" id="btn_reset">Reset</button>
                            </div>
                        </div>
                        </form>
                      </div>
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="table_po" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th>No</th>
                            <th>QR</th>
                            <th>Kode Aset</th>
                            <th>Jenis Barang</th>
                            <th>Model Barang</th>
                            <th>Jenis Aset</th>
                            <th>Status</th>
                            <th>Kurs</th>
                            <th>Harga</th>
                            <th>Lokasi</th>
                            <th>Detail Lokasi</th>
                            <th>User</th>
                            <th>SN</th>
                            <th>Ket.</th>
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.checkboxes.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        table = $('#table_po').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_report/get_data_po_aset');?>",
            "type": "POST",
            "data": function(data){
                data.id_transaksi = $('#id_transaksi').val();
            }
          },
          "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (aData[6] == 'STOCK') {
                    $('td', nRow).css('background-color', '#2BBFEE');
                    $('td', nRow).css('color', 'white');
                }
                if (aData[6] == 'BROKEN ON IT') {
                    $('td', nRow).css('background-color', '#DA2B2E');
                    $('td', nRow).css('color', 'white');
                }
                if (aData[6] == 'BROKEN ON VENDOR') {
                    $('td', nRow).css('background-color', '#EEA72B');
                    $('td', nRow).css('color', 'white');
                }
          }          
        });
      });

      $("#id_transaksi").select2({
        placeholder: "-- Semua PO --",
        theme: 'bootstrap4',
        allowClear: true
      });

      $('#btn_filter').click(function(){ //button filter event click
        table.ajax.reload();  //just reload table
      });

      $('#btn_reset').click(function(){ //button reset event click
        $('#filter')[0].reset();
        $('#id_transaksi').val('');
        $('#id_transaksi').trigger('change');
        table.ajax.reload();  //just reload table
      });
      
      function getExcel(){
        var id_transaksi = ($('#id_transaksi').val()?$('#id_transaksi').val():'-');
        var id_trs = id_transaksi.replace(/'/g,"~").replace(/,/g,"_");      
        window.open("<?php echo site_url('c_report/export_report_po_aset/');?>"+id_trs,"_blank");
      }

    </script>
  </body>
</html>
