<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Report Surat Jalan</h2>
              <div class="row my-4">
                <div class="col-md-12">
                  <div class="card shadow">
                    <div class="card-body">
                      <div class="col-md-5">
                        <form class="form-horizontal" id="filter" method="post">
                        <div class="form-group row">
                          <label for="inputEmail3" class="col-sm-4 col-form-label"><b>Surat Jalan</b></label>
                          <div class="col-sm-8">
                                <select class="form-control select2" name="id_surat_jalan" id="id_surat_jalan">
                                    <option value="">--- Pilih Surat Jalan ---</option>
                                    <?php foreach($surat_jalan as $sj){?>
                                    <option value="<?php echo $sj->id_surat_jalan;?>"><?php echo $sj->surat_jalan;?></option>
                                    <?php } ?>
                                </select>
                          </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-8 ml-sm-auto">
                                <button class="btn mb-2 btn-info btn-sm" type="button" id="btn_filter">Filter</button>
                                <button class="btn mb-2 btn-success btn-sm" type="button" onclick="getExcel()">Export</button>
                                <button class="btn mb-2 btn-secondary btn-sm" type="button" id="btn_reset">Reset</button>
                            </div>
                        </div>
                        </form>
                      </div>
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="table_sj" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th>No</th>
                            <th>Surat Jalan</th>
                            <th>Tanggal</th>
                            <th>Vendor</th>
                            <th>Kode</th>
                            <th>Jenis Barang</th>
                            <th>Model Barang</th>
                            <th>Unit</th>
                            <th>Qty</th>
                            <th>SN</th>
                            <th>No PO</th>
                            <th>Keterangan</th>
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.checkboxes.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        table = $('#table_sj').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_report/get_data_sj');?>",
            "type": "POST",
            "data": function(data){
                data.id_surat_jalan = $('#id_surat_jalan').val();
            }
          }          
        });
      });

      $("#id_surat_jalan").select2({
        placeholder: "--- Pilih Surat Jalan ---",
        theme: 'bootstrap4',
        allowClear: true
      });

      $('#btn_filter').click(function(){ //button filter event click
        table.ajax.reload();  //just reload table
      });

      $('#btn_reset').click(function(){ //button reset event click
        $('#filter')[0].reset();
        $('#id_surat_jalan').val('');
        $('#id_surat_jalan').trigger('change');
        table.ajax.reload();  //just reload table
      });
      
      function getExcel(){
        var id_surat_jalan = ($('#id_surat_jalan').val()?$('#id_surat_jalan').val():'-');
        window.open("<?php echo site_url('c_report/export_report_sj/');?>"+id_surat_jalan,"_blank");
      }
    </script>
  </body>
</html>
