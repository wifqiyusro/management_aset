<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Daftar Karyawan Resign</h2>
              <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                  <div class="card shadow">
                    <div class="card-body">
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="table_karyawan_resign" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th>No</th>
                            <th>NIK</th>
                            <th>Nama</th>
                            <th>Departement</th>
                            <th>Gedung</th>
                            <th>QR Aset</th>
                            <th>Nama Aset</th>
                            <th>SN</th>
                            <th>Lokasi Aset</th>
                            <th>Aksi</th>
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>   
    <script src="<?php echo base_url();?>assets/js/dataTables.rowsGroup.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        $('#tipe_user').select2({
          theme: 'bootstrap4'
        });

        $("#tipe_user").change(function(){
          if($("#tipe_user").val() == 'nik'){
            $("#form_nik").show();
            $("#nama_user").val('');
            $("#form_nama_user").hide();
          }else{
            $("#nik").val('');
            $("#form_nik").hide();
            $("#form_nama_user").show();
          }
        });

        table = $('#table_karyawan_resign').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "rowsGroup": [1,2,3,4],
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_karyawan/get_data_karyawan_resign')?>",
            "type": "POST"
          },
        });
      });

      function reload_table(){
        table.ajax.reload(null,false);
      }

      $(function(){
        $('#nik').select2({
        theme: 'bootstrap4',
        placeholder : '--- Pilih Karyawan ---',
        ajax: {
          dataType: 'JSON',
          url: '<?=site_url('c_aset/get_karyawan_2')?>',
          type: "POST",
          delay: 250,
          data: function(params) {
            return {
              searchTerm: params.term
            }
          },
          processResults: function (response) {
              return {
                results: response
              };
          }
        },
        cache: false
        });
      }); 

      function change_user(id_stok){
        save_method = 'change_user';
        $('#form_user')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class
        $('#modal_user').modal('show');

        $.ajax({
            url : "<?php echo site_url('c_karyawan/get_row_aset')?>/"+id_stok,
            type: "GET",
            dataType: "JSON",
            success: function(data){   
              console.log(data)               
                $('#tipe_user').html('<option value="nik" selected>NIK</option> <option value="non_nik">NON NIK</option>');
                $('#form_nik').show();
                $('#form_nama_user').hide();
                $('[name="id_stok"]').val(id_stok);
                $("#nik").html('<option value = "'+data.nik+'" selected>'+data.nik+' - '+data.NAME+'</option>');        
                $('#modal_user').modal('show'); // show bootstrap modal when complete loaded
                $('.modal-title').text('Ubah pengguna Aset'); // Set title to Bootstrap modal title     
            },
            error: function (jqXHR, textStatus, errorThrown){
                alert('Gagal menampilkan data pengguna aset');
            }
        });
      }

      function saveuser(){
        $('#saveuser').text('mengganti...'); //change button text
        $('#saveuser').attr('disabled',true); //set button disable

        $.ajax({
          url : "<?php echo site_url('c_karyawan/change_user_proses');?>",
          type: "POST",
          data: $('#form_user').serialize(),
          dataType: "JSON",
          success: function(data){
            if(data.status){
              $('#modal_user').modal('hide');
              reload_table();
            }
            $('#saveuser').text('simpan'); //change button text
            $('#saveuser').attr('disabled',false); //set button enable
          },
          error: function (jqXHR, textStatus, errorThrown){
            alert('Gagal ubah pengguna');
            $('#saveuser').text('simpan'); //change button text
            $('#saveuser').attr('disabled',false); //set button enable
          }
        });
      }
    </script>
  </body>
</html>

<div class="modal fade" id="modal_user" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel"></h5>
      </div>
      <div class="modal-body">
        <form action="#" id="form_user">
          <input type="hidden" name="id_stok" id="id_stok">
          <div class="form-group">
            <label class="col-form-label"><b>Tipe User</b></label>
              <select class="form-control select2" name="tipe_user" id="tipe_user">
            </select>
          </div>
          <div class="form-group" id="form_nik">            
            <label class="col-form-label"><b>NIK</b></label>
            <select class="form-control select2" name="nik" id="nik">
            </select>
          </div>
          <div class="form-group" id="form_nama_user">            
            <label class="col-form-label"><b>Pengguna</b></label>
            <input type="text" class="form-control" name="nama_user" placeholder="Nama User">
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" id="savebarang" onclick="saveuser()" class="btn mb-2 btn-primary">Simpan</button>
      </div>
    </div>
  </div>
</div>