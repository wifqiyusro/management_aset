<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Master PO Consumable</h2>
              <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                  <?php if($this->session->userdata('level_a')=='1' || $this->session->userdata('level_a')=='2'){?>
                    <button type="button" class="btn mb-2 btn-success" onclick="add_po_cms()">Tambah PO</button>
                  <?php } ?>
                  <div class="card shadow">
                    <div class="card-body">
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="table_po_cms" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th>No</th>
                            <th>No PO</th>
                            <th>Tanggal PO</th>
                            <th>Supplier</th>
                            <th>Keterangan</th>
                            <th>Created at</th>
                            <th>Updated at</th>
                            <th>Aksi</th>
                          </tr>
                        </thead>
                        <tbody>                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        table = $('#table_po_cms').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_po/get_master_po_cms')?>",
            "type": "POST"
          },
        });
      });
      
      function reload_table(){
        table.ajax.reload(null,false);
      }

      function add_po_cms(){
        save_method = 'add_po_cms';
        $('#form_po_cms')[0].reset();
        $('.select2').select2({
          placeholder: '--- Pilih Supplier ---',
          theme: 'bootstrap4'
        });
        $('#id_supplier').val(null).trigger('change');
        $('.form-group').removeClass('has-error'); // clear error class
        $('#po_cms_form').modal('show'); // show bootstrap modal
        $('.modal-title').text('Form Tambah Master PO Consumable'); // Set Title to Bootstrap modal title
    }

      function edit_po_cms(id_po){
        save_method = 'edit_po_cms';
        $('#form_po_cms')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class

        $.ajax({
            url : "<?php echo site_url('c_po/edit_po_cms_')?>/"+id_po,
            type: "GET",
            dataType: "JSON",
            success: function(data){     
                $('[name="id_po"]').val(data.id_po);
                $('[name="no_po"]').val(data.no_po);
                $('[name="tanggal_po"]').val(data.tanggal_po);
                $('#id_supplier').val(data.id_supplier).select2({theme: 'bootstrap4'});               
                $('[name="keperluan"]').val(data.keperluan);             
                $('#po_cms_form').modal('show'); // show bootstrap modal when complete loaded
                $('.modal-title').text('Form Edit PO Consumable'); // Set title to Bootstrap modal title     
            },
            error: function (jqXHR, textStatus, errorThrown){
                alert('Gagal menampilkan data po consumable');
            }
        });
      }

      function savepocms(){
        $('#savepocms').text('saving...'); //change button text
        $('#savepocms').attr('disabled',true); //set button disable 
        var url;
     
        if(save_method == 'add_po_cms') {
            url = "<?php echo site_url('c_po/add_po_cms_process')?>";
        } else {
            url = "<?php echo site_url('c_po/update_po_cms_process')?>";
        }

        // ajax adding data to database
        $.ajax({
            url : url,
            type: "POST",
            data: $('#form_po_cms').serialize(),
            dataType: "JSON",
            success: function(data){     
                if(data.status) //if success close modal and reload ajax table
                {
                    $('#po_cms_form').modal('hide');
                    reload_table();
                }     
                $('#savepocms').text('simpan'); //change button text
                $('#savepocms').attr('disabled',false); //set button enable
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Gagal edit data master PO consumable');
                $('#savepocms').text('simpan'); //change button text
                $('#savepocms').attr('disabled',false); //set button enable
            }
        });
       }
    </script>
    <div class="modal fade" id="po_cms_form" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="varyModalLabel"></h5>
          </div>
          <div class="modal-body">
            <form action="#" id="form_po_cms">
              <div class="form-group">
                <label class="col-form-label"><b>No PO</b></label>
                <input type="text" class="form-control" name="no_po" placeholder="No PO" required>
                <input type="hidden" name="id_po" id="id_po">
              </div>
              <div class="form-group">
                <label class="col-form-label"><b>Tanggal PO</b></label>
                <input type="date" class="form-control" name="tanggal_po" placeholder="Tanggal PO" required>
              </div>
              <div class="form-group">
                <label class="col-form-label"><b>Supplier</b></label>
                <select class="form-control select2" name="id_supplier" id="id_supplier">
                    <option value=""></option>
                    <?php
                        foreach($supplier as $data){
                            echo '<option value='.$data->id_supplier.'>'.$data->nama_supplier.'</option>';
                        }
                    ?>
                </select>
              </div>
              <div class="form-group">
                <label class="col-form-label"><b>Keterangan</b></label>
                <textarea name="keperluan" class="form-control" placeholder="Keterangan" required></textarea>
              </div>
              <input type="hidden" name="jenis_po" value="2">
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
            <button type="button" id="savepocms" onclick="savepocms()" class="btn mb-2 btn-primary">Simpan</button>
          </div>
        </div>
      </div>
    </div>
</body>
</html>



