      <main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Tambah PO Aset</h2>
              <div class="card shadow mb-4">
                <?php echo form_open('c_po/add_po_aset_proses');?>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group mb-3">
                        <label><b>No PO</b></label>
                        <input type="text" class="form-control" name="no_po" id="no_po" placeholder="No PO" required>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Tanggal PO</b></label>
                        <input type="text" class="form-control drgpicker" name="tanggal_po" id="tanggal_po" placeholder="Tanggal PO" required>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Supplier</b></label>
                        <select class="form-control select2" name="id_supplier" id="id_supplier_po" style="width: 100%" required>
                          <option value="">-- Pilih Salah Satu --</option>
                          <?php foreach($supplier as $data){
                            echo '<option value="'.$data->id_supplier.'">'.$data->nama_supplier.'</option>';
                          }?>
                        </select>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Alamat Supplier</b></label>
                        <textarea class="form-control" name="alamat_supplier" id="alamat_supplier" placeholder="Alamat Supplier" readonly></textarea>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>No Telp</b></label>
                        <input type="text" class="form-control" name="phone" id="phone" placeholder="No Telp" readonly>
                      </div>
                    </div> <!-- /.col -->
                    <div class="col-md-6">
                      <div class="form-group mb-3">
                        <label><b>Departemen Request</b></label>
                        <select class="form-control select2" multiple="multiple" name="dept[]" id="dept" style="width: 100%" placeholder="Departemen Request">
                          <?php foreach($departemen as $data){
                            echo '<option value="'.$data->nama_lokasi.'">'.$data->nama_lokasi.'</option>';
                          }?>
                        </select>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Tanggal Approval</b></label>
                        <input type="text" class="form-control date" name="tgl_approval" id="tgl_approval" placeholder="Tanggal Approval" required>
                      </div>
                      <div class="form-group mb-3">
                        <label><b>Keterangan</b></label>
                        <textarea class="form-control" name="keperluan" id="keperluan" placeholder="Keterangan" required></textarea>
                      </div>
                      <div class="form-group mb-3">
                        <button class="btn mb-2 btn-info btn-sm">Simpan</button>
                      </div>
                    </div>
                  </div>
                </div>
                <?php echo form_close();?>
              </div> <!-- / .card -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      $('.drgpicker').daterangepicker(
      {
        singleDatePicker: true,
        timePicker: false,
        showDropdowns: true,
        locale:
        {
          format: 'YYYY-MM-DD'
        }
      });
      $('.date').datepicker({
        multidate: true,
        format: 'yyyy-mm-dd'
      });
      $('.time-input').timepicker(
      {
        'scrollDefault': 'now',
        'zindex': '9999' /* fix modal open */
      });

      $('.select2').select2(
      {
        theme: 'bootstrap4',
      });
      $('.select2-multi').select2(
      {
        multiple: true,
        theme: 'bootstrap4',
      });
      $('#id_supplier_po').change(function(){
        $.ajax({
          url:"<?php echo site_url('c_supplier/cek_supplier/')?>"+$('#id_supplier_po').val(),
          success : function(o) {
            console.log(o)         
              if(o.status=='ok'){
                var data = o.data
                $('#alamat_supplier').val(data.alamat_supplier);
                $('#phone').val(data.phone);
              }else{
                alert(o.msg);
                location.reload();              
              }
          },
          error : function(data){
          console.log(data)
        }
        });
      });
    </script>
  </body>
</html>