<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Konfirmasi Consumable</h2>
              <div class="row my-4">
                <div class="col-md-12">
                  <!-- <button type="button" class="btn mb-2 btn-info" onclick="terima_rental()">Terima Rental</button> -->
                  <div class="card shadow">
                    <div class="card-body">
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" cellspacing="0" width="100%" id="dataTable-1">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th style="position: sticky; top: 0;">No</th>
                            <th style="position: sticky; top: 0;">PO</th>
                            <th style="position: sticky; top: 0;">Tanggal PO</th>
                            <th style="position: sticky; top: 0;">Supplier</th>
                            <th style="position: sticky; top: 0;">Nama Barang</th>
                            <th style="position: sticky; top: 0;">...</th>
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">
                          <?php
                            $no = 1;
                            foreach($data as $dt){
                              echo '
                              <tr>
                                <td>'.$no.'</td>
                                <td>'.$dt->no_po.'</td>
                                <td>'.$dt->tanggal_po.'</td>
                                <td>'.$dt->nama_supplier.'</td>
                                <td>'.$dt->nama_barang.'</td>
                                <td><a href="'.base_url().'index.php/c_cms/konfirmasi_cms_detail/'.$dt->id_po.'">Detail..</a></td>
                              </tr>
                              ';
                            }
                          ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.checkboxes.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script>
        $('#dataTable-1').DataTable({
            autoWidth: true,
            ordering: false
        });
    </script>
  </body>
</html>
