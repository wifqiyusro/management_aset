<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Master Barang Consumable</h2>
              <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                  <?php if($this->session->userdata('level_a')=='1' || $this->session->userdata('level_a')=='2'){?>
                  <button type="button" class="btn mb-2 btn-success" onclick="add_barang_cms()">Tambah Barang</button>
                  <?php } ?>
                  <div class="card shadow">
                    <div class="card-body">
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="table_cms" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th style="position: sticky; top: 0;">No</th>
                            <th style="position: sticky; top: 0;">Kode Barang</th>                            
                            <th style="position: sticky; top: 0;">Nama Barang</th>
                            <th style="position: sticky; top: 0;">Kategori</th>
                            <th style="position: sticky; top: 0;">Satuan</th>
                            <th style="position: sticky; top: 0;">Isi Perpack</th>
                            <th style="position: sticky; top: 0;">Stok (Pack)</th>
                            <th style="position: sticky; top: 0;">Stok (Pcs/Meter)</th>
                            <th style="position: sticky; top: 0;">Total Stok</th>
                            <th style="position: sticky; top: 0;">Min Stok</th>
                            <th style="position: sticky; top: 0;">Created at</th>
                            <th style="position: sticky; top: 0;">Updated at</th>
                            <th style="position: sticky; top: 0;">Aksi</th>
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        table = $('#table_cms').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_cms/get_barang_cms')?>",
            "type": "POST"
          },
          "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (aData[8] == '0') {
                    $('td', nRow).css('background-color', '#DA2B2E');
                    $('td', nRow).css('color', 'white');
                }
                if (aData[8] < aData[9] && aData[8] > '0') {
                    $('td', nRow).css('background-color', '#EEA72B');
                    $('td', nRow).css('color', 'white');
                }
          }  
        });
      });

      function reload_table(){
        table.ajax.reload(null,false);
      }
    
      function add_barang_cms(){
        save_method = 'add_barang_cms';
        $('#form_barang')[0].reset();
        $('.select2').select2({
          placeholder: '--- Pilih Salah Satu ---',
          theme: 'bootstrap4'
        });
        $('#id_kategori').val(null).trigger('change');
        $('#satuan').val(null).trigger('change');
        $('.form-group').removeClass('has-error'); // clear error class
        $('#barang_form').modal('show'); // show bootstrap modal
        $('.modal-title').text('Form Tambah Barang Consumable'); // Set Title to Bootstrap modal title
      }

      function edit_barang(kode_barang){
          save_method = 'edit_barang';
          $('#form_barang')[0].reset();
          $('.form-group').removeClass('has-error'); // clear error class

          $.ajax({
              url : "<?php echo site_url('c_cms/edit_barang_')?>/"+kode_barang,
              type: "GET",
              dataType: "JSON",
              success: function(data){     
                  $('[name="kode_barang"]').val(data.kode_barang);
                  $('[name="nama_barang"]').val(data.nama_barang);
                  $('#id_kategori').val(data.id_kategori).select2({theme: 'bootstrap4'});
                  $('#satuan').val(data.satuan).select2({theme: 'bootstrap4'});
                  $('[name="isi_per_pack"]').val(data.isi_per_pack);
                  $('[name="min_stok"]').val(data.min_stok);                 
                  $('#barang_form').modal('show'); // show bootstrap modal when complete loaded
                  $('.modal-title').text('Form Edit Barang Consumable'); // Set title to Bootstrap modal title     
              },
              error: function (jqXHR, textStatus, errorThrown){
                  alert('Gagal menampilkan data barang consumable');
              }
          });
      }

    //JS save user
    function savebarang(){
        $('#savebarang').text('saving...'); //change button text
        $('#savebarang').attr('disabled',true); //set button disable 
        var url;

        if(save_method == 'add_barang_cms') {
            url = "<?php echo site_url('c_cms/add_barang_process')?>";
        } else {
            url = "<?php echo site_url('c_cms/update_barang_process')?>";
        }

        // ajax adding data to database
        $.ajax({
            url : url,
            type: "POST",
            data: $('#form_barang').serialize(),
            dataType: "JSON",
            success: function(data){     
                if(data.status) //if success close modal and reload ajax table
                {
                    $('#barang_form').modal('hide');
                    reload_table();
                }     
                $('#savebarang').text('simpan'); //change button text
                $('#savebarang').attr('disabled',false); //set button enable
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Gagal edit / tambah data barang');
                $('#savebarang').text('simpan'); //change button text
                $('#savebarang').attr('disabled',false); //set button enable
            }
        });
    }

    </script>
  </body>
</html>

<div class="modal fade" id="barang_form" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel"></h5>
      </div>
      <div class="modal-body">
        <form action="#" id="form_barang">
          <div class="form-group">
            <label class="col-form-label"><b>Nama Barang</b></label>
            <input type="text" class="form-control" name="nama_barang" placeholder="Nama Barang" required>
            <input type="hidden" name="kode_barang" id="kode_barang">
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Kategori</b></label>
            <select class="form-control select2" name="id_kategori" id="id_kategori">
                <option value=""></option>
                <?php
                    foreach($kategori as $data){
                        echo '<option value='.$data->id_kategori.'>'.$data->nama_kategori.'</option>';
                    }
                ?>
            </select>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Satuan</b></label>
            <select class="form-control select2" name="satuan" id="satuan">
                <option value=""></option>
                <option value="Box">Box</option>
                <option value="EA">EA</option>
                <option value="Meter">Meter</option>
                <option value="Pack">Pack</option>
                <option value="Pcs">Pcs</option>
                <option value="Roll">Roll</option>
            </select>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Isi Perpack</b></label>
            <input type="number" class="form-control" name="isi_per_pack" placeholder="Isi Per Pack" required>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Minimal Stok</b></label>
            <input type="number" class="form-control" name="min_stok" placeholder="Minimal Stok" required>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" id="savebarang" onclick="savebarang()" class="btn mb-2 btn-primary">Simpan</button>
      </div>
    </div>
  </div>
</div>