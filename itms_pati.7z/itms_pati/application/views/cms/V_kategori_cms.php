<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Master Kategori Consumable</h2>
              <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                <?php if($this->session->userdata('level_a')=='1' || $this->session->userdata('level_a')=='2'){?>
                <button type="button" class="btn mb-2 btn-success" onclick="add_kategori_cms()">Tambah Kategori</button>
                <?php } ?>
                  <div class="card shadow">
                    <div class="card-body">
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="table_kategori_cms" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th>No</th>
                            <th>Kode Kategori</th>                            
                            <th>Nama Kategori</th>
                            <th>Created at</th>
                            <th>Updated at</th>
                            <th>Aksi</th>
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        table = $('#table_kategori_cms').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_cms/get_kategori_cms')?>",
            "type": "POST"
          },
        });
      });

    function reload_table(){
        table.ajax.reload(null,false);
    }

    function add_kategori_cms(){
        save_method = 'add_kategori_cms';
        $('#form_kategori_cms')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class
        $('#kategori_cms_form').modal('show'); // show bootstrap modal
        $('.modal-title').text('Form Tambah Kategori Consumable'); // Set Title to Bootstrap modal title
    }

    function edit_kategori_cms(id_kategori){
        save_method = 'edit_kategori_cms';
        $('#form_kategori_cms')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class

        $.ajax({
            url : "<?php echo site_url('c_cms/edit_kategori_cms_')?>/"+id_kategori,
            type: "GET",
            dataType: "JSON",
            success: function(data){     
                $('[name="id_kategori"]').val(data.id_kategori);
                $('[name="nama_kategori"]').val(data.nama_kategori);     
                $('#kategori_cms_form').modal('show'); // show bootstrap modal when complete loaded
                $('.modal-title').text('Form Edit Kategori Consumable'); // Set title to Bootstrap modal title     
            },
            error: function (jqXHR, textStatus, errorThrown){
                alert('Gagal menampilkan data kategori consumable');
            }
        });
    }

    function savekategoricms(){
        $('#savekategoricms').text('saving...'); //change button text
        $('#savekategoricms').attr('disabled',true); //set button disable 
        var url;
     
        if(save_method == 'add_kategori_cms') {
            url = "<?php echo site_url('c_cms/add_kategori_cms_process')?>";
        } else {
            url = "<?php echo site_url('c_cms/update_kategori_cms_process')?>";
        }
     
        // ajax adding data to database
        $.ajax({
            url : url,
            type: "POST",
            data: $('#form_kategori_cms').serialize(),
            dataType: "JSON",
            success: function(data){     
                if(data.status) //if success close modal and reload ajax table
                {
                    $('#kategori_cms_form').modal('hide');
                    reload_table();
                }     
                $('#savekategoricms').text('simpan'); //change button text
                $('#savekategoricms').attr('disabled',false); //set button enable
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Gagal edit / tambah data kategori consumable');
                $('#savekategoricms').text('simpan'); //change button text
                $('#savekategoricms').attr('disabled',false); //set button enable
            }
        });
    }

    </script>
  </body>
</html>

<div class="modal fade" id="kategori_cms_form" tabindex="-1" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel"></h5>
      </div>
      <div class="modal-body">
        <form action="#" id="form_kategori_cms">
          <div class="form-group">
            <label class="col-form-label"><b>Nama Kategori</b></label>
            <input type="text" class="form-control" name="nama_kategori" placeholder="Nama Kategori" required>
            <input type="hidden" name="id_kategori" id="id_kategori">
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" id="savekategoricms" onclick="savekategoricms()" class="btn mb-2 btn-primary">Simpan</button>
      </div>
    </div>
  </div>
</div>