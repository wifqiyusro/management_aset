<main role="main" class="main-content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="mb-2 page-title">Master Jenis Barang</h2>
              <div class="row my-4">
                <!-- Small table -->
                <div class="col-md-12">
                  <?php if($this->session->userdata('level_a')=='1' || $this->session->userdata('level_a')=='2'){?>
                  <button type="button" class="btn mb-2 btn-success" onclick="add_jenis_barang()">Tambah Jenis Barang</button>
                  <?php } ?>
                  <div class="card shadow">
                    <div class="card-body">
                      <!-- table -->
                      <table class="table table-bordered table-hover mb-0 datatables" id="table_jenis_barang" cellspacing="0" width="100%">
                        <thead class="thead-dark" style="text-align: center;">
                          <tr>
                            <th>No</th>
                            <th>Nama Jenis Barang</th>
                            <th>Jenis Aset</th>
                            <th>Label Jenis Barang</th>
                            <th>Created at</th>
                            <th>Updated at</th>
                            <th>Aksi</th>
                          </tr>
                        </thead>
                        <tbody style="text-align: center;">                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div> <!-- simple table -->
              </div> <!-- end section -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
      </main> <!-- main -->
    </div> <!-- .wrapper -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/simplebar.min.js"></script>
    <script src='<?php echo base_url();?>assets/js/daterangepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.stickOnScroll.js'></script>
    <script src="<?php echo base_url();?>assets/js/tinycolor-min.js"></script>
    <script src="<?php echo base_url();?>assets/js/config.js"></script>
    <script src="<?php echo base_url();?>assets/js/apps.js"></script>
    <script src='<?php echo base_url();?>assets/js/jquery.dataTables.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/jquery.timepicker.js'></script>
    <script src='<?php echo base_url();?>assets/js/dataTables.bootstrap4.min.js'></script>
    <script src='<?php echo base_url();?>assets/js/select2.min.js'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script type="text/javascript">
      var table;
      $(document).ready(function(){
        table = $('#table_jenis_barang').DataTable({
          "processing": true,
          "language": { "processing": '<div class="spinner-border mr-3 text-primary" role="status"><span class="sr-only">Loading...</span></div>' },
          "serverSide": true,
          "ordering": false,
          "order": [],
          "ajax":{
            "url": "<?php echo site_url('c_jenis_barang/get_master_jenis_barang')?>",
            "type": "POST"
          },
        });
      });

      function reload_table(){
        table.ajax.reload(null,false);
      }

      //JS add user
    function add_jenis_barang(){
        save_method = 'add_jenis_barang';
        $('#form_jenis_barang')[0].reset();
        $('.select2').select2({
          placeholder:'--- Pilih Salah Satu ---',
          theme: 'bootstrap4'
        });       
        $('#jenis_aset').val(null).trigger('change');
        $('#kel_aset').val(null).trigger('change');
        $('.form-group').removeClass('has-error'); // clear error class
        $('#jenis_barang_form').modal('show'); // show bootstrap modal
        $('.modal-title').text('Form Tambah Master Jenis Barang'); // Set Title to Bootstrap modal title
    }
  
    function edit_jenis_barang(id_jenis_barang){
        save_method = 'edit_jenis_barang';
        $('#form_jenis_barang')[0].reset();
        $('.form-group').removeClass('has-error'); // clear error class

        $.ajax({
            url : "<?php echo site_url('c_jenis_barang/edit_jenis_barang_')?>/"+id_jenis_barang,
            type: "GET",
            dataType: "JSON",
            success: function(data){   
                $('[name="id_jenis_barang"]').val(data.id_jenis_barang);
                $('[name="nama_jenis_barang"]').val(data.nama_jenis_barang);
                $('#jenis_aset').val(data.jenis_aset).select2({theme: 'bootstrap4'});
                $('[name="label_jns_barang"]').val(data.label_jns_barang);  
                $('#kel_aset').val(data.kel_asset).select2({theme: 'bootstrap4'});               
                $('#jenis_barang_form').modal('show'); // show bootstrap modal when complete loaded
                $('.modal-title').text('Form Edit Master Jenis Barang'); // Set title to Bootstrap modal title     
            },
            error: function (jqXHR, textStatus, errorThrown){
                alert('Gagal menampilkan data master jenis barang');
            }
        });
    }

    //JS save user
    function savejenisbarang(){
        $('#savejenisbarang').text('saving...'); //change button text
        $('#savejenisbarang').attr('disabled',true); //set button disable 
        var url;
     
        if(save_method == 'add_jenis_barang') {
            url = "<?php echo site_url('c_jenis_barang/add_jenis_barang_process')?>";
        } else {
            url = "<?php echo site_url('c_jenis_barang/update_jenis_barang_process')?>";
        }
     
        // ajax adding data to database
        $.ajax({
            url : url,
            type: "POST",
            data: $('#form_jenis_barang').serialize(),
            dataType: "JSON",
            success: function(data){     
                if(data.status) //if success close modal and reload ajax table
                {
                    $('#jenis_barang_form').modal('hide');
                    reload_table();
                }     
                $('#savejenisbarang').text('simpan'); //change button text
                $('#savejenisbarang').attr('disabled',false); //set button enable
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Gagal edit / tambah data master jenis barang');
                $('#savejenisbarang').text('simpan'); //change button text
                $('#savejenisbarang').attr('disabled',false); //set button enable
            }
        });
    }
    </script>
  </body>
</html>

<div class="modal fade" id="jenis_barang_form" role="dialog" aria-labelledby="varyModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="varyModalLabel"></h5>
      </div>
      <div class="modal-body">
        <form action="#" id="form_jenis_barang">
          <div class="form-group">
            <label class="col-form-label"><b>Nama Jenis Barang</b></label>
            <input type="text" class="form-control" name="nama_jenis_barang" placeholder="Nama Jenis Barang" required>
            <input type="hidden" name="id_jenis_barang" id="id_jenis_barang">
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Jenis Aset</b></label>
            <select class="form-control select2" name="jenis_aset" id="jenis_aset">
                <option value=""></option>
                <option value="0">Po</option>
                <option value="1">Rental</option>
                <option value="2">Projek</option>
            </select>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Label Jenis Barang</b></label>
            <input type="text" class="form-control" name="label_jns_barang" placeholder="Label Jenis Barang" required>
          </div>
          <div class="form-group">
            <label class="col-form-label"><b>Kelompok Aset</b></label>
            <select class="form-control select2" name="kel_aset" id="kel_aset">
                <option value=""></option>
                <?php foreach($kel_aset as $data){
                  echo '<option value='.$data->kode.'>'.$data->nama_aset.'</option>';
                }?>
            </select>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn mb-2 btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="button" id="savejenisbarang" onclick="savejenisbarang()" class="btn mb-2 btn-primary">Simpan</button>
      </div>
    </div>
  </div>
</div>